#include<stdio.h>
int countDuplicate(int a[],int );
int main(){
	int n;
	printf("Enter the size of Array");
	scanf("%d",&n);
	int a[n];
	printf("Enter the element of Array");
	
	for(int i=0; i<n ;i++){
	
		scanf("%d",&a[i]);
	}
	
	int res= countDuplicate(a,n);
	printf("There are %d non-unique elements:", res);
	
	return 0;
}

int countDuplicate(int a[],int n){
	int count=0;
	for(int i=0 ;i<n;i++){
		int found=0;
		for(int k=0;k<i;k++){
			if(a[i]==a[k]){
				found=1;
				break;
			}
		}
		if(found){
			continue;
		}
		
		int freq=0;		
	 	for(int j=0;j<n;j++){
	 		if(a[j]==a[i]){
	 			freq++;
	 		}
	 	}
	 	if(freq>1){
	 		count++;
	 	}
	 	
	 }
	
	return count;
}
			
			
			

	
