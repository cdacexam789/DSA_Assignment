/*Q1. Write a C/C++ program to implement Linear Search. We need to check for duplicate inputs. If the
duplicate element is allowed then a linear search algo needs to implement accordingly. An
appropriate condition check needs to apply for element not found scenario.
(a) Search Element ( iterative approach )
(b) Search Element ( recursion approach )
(c) Print Input array ( iterative approach )
(d) Print Input array ( recursion approach )
(e) Print Input array reverse order ( iterative approach )
(f) Print Input array reverse order ( recursion approach )
 */


#include<stdio.h>
void search_it(int ptr[],int key,int len);
int max_val(int *ptr ,int len);
void print_it(int ptr[],int len);
void print_rev_it(int *ptr,int len);
void print_rev_rec(int ptr[],int i,int len);
void print_rec(int ptr[],int i,int len);
void search_rec(int ptr[],int key,int len,int i,int* flag);
int is_present(int a[],int idx,int ele);
int main(){
	int n;
	printf("Enter the size of array\n");
	scanf("%d",&n);
	int a[n];
	int is_dup;
	printf("Enter 1 to allow duplicates in array\nEnter 2 to not allow duplicates in array\n");
	scanf("%d",&is_dup);
	if(is_dup==1){
		printf("Enter each element in an array\n");
		for(int i=0 ;i<n ;i++){
			scanf("%d",&a[i]);
		}
	}
	if(is_dup==2){
		printf("Enter each element in an array\n");
		int x,idx=0;
                while(idx<n){
                        scanf("%d",&x);
			if(idx==0){
				a[idx++]=x;
			}
			else{
				if(is_present(a,idx,x)){
					printf("Element already present in array.Please enter other element\n");
				}
				else{
					a[idx++]=x;
				}
			}


                }

	}
	int choice;
	while(1){
		
	printf("\n============Menu Driven===========\n");
	printf("1. Search the element in iterative way\n");
	printf("2. Search the element in recursive way\n");
	printf("3. Print the element in iterative way\n");
        printf("4. Print the element in recursive  way\n");
	printf("5. Print the element in reverse order in iterative way\n");
        printf("6. Print the element in reverse order in recursive way\n");
	printf("7. Exit\n ");

	scanf("%d",&choice);
	int key,flag=0;
	switch(choice){
		case 1:
			
			printf("Enter key to search in array\n");
			scanf("%d",&key);
			search_it(a,key,n); 
			break;
		case 2:
                        printf("Enter key to search in array\n");
                        scanf("%d",&key);
			search_rec(a,key,n,0,&flag);
			if(flag==0){
				printf("Element not found\n");
			}
			break;
		case 3: 
			print_it(a,n);
			break;
		case 4:
			print_rec(a,0,n);
			break;
		case 5:
			print_rev_it(a,n);
			break;
		case 6:
			print_rev_rec(a,n-1,n);
			break;
		default:
			return -1;
	
		}
	}
}
int is_present(int a[],int idx,int ele){
	for(int i=0;i<idx;i++){
		if(a[i]==ele){
			return 1;
		}
		else{
			return 0;
		}
	}
}
void search_it(int ptr[],int key,int len){
	
	int flag=0;
	for(int i=0;i<len;i++){
		if(ptr[i]==key){
			printf("Element found at %d index\n",i);
			flag=1;
		}
	}
	if(flag==0){
		printf("Element not found\n");
	}
}
void search_rec(int ptr[],int key,int len,int i,int* flag){
	if(i==len){
		return;
	}
	if(ptr[i]==key){
		*flag=1;
		printf("Element found at %d index\n",i);
	}
	search_rec(ptr,key,len,i+1,flag);

}

	
int max_val(int *ptr ,int len){
	int max;
	for(int i=0;i<len-1;i++){

		if(ptr[i]<ptr[i+1]){
			max=ptr[i+1];
		}
	}
	return max;

}

void print_it(int ptr[],int len){
	for(int i=0;i<len;i++){
		printf("ptr[%d]=%d\n", i ,ptr[i]);
	}
}
void print_rev_it(int *ptr,int len){
        for(int i=len-1;i>=0;i--){
                printf("ptr[%d]=%d\n", i ,ptr[i]);
        }
}
void print_rec(int ptr[],int i,int len){
	if(i==len){
		return;
	}
	printf("ptr[%d]=%d\n",i,ptr[i]);
	print_rec(ptr,i+1,len);
}
void print_rev_rec(int ptr[],int i,int len){
        if(i<0){
                return;
        }
        printf("ptr[%d]=%d\n",i,ptr[i]);
        print_rev_rec(ptr,i-1,len);
}
	
