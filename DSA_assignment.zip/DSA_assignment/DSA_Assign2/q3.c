/*Q3. Find the Factor
Determine the factors of a number (i.e., all positive integer values that evenly divide into a number) and then
return the p

th element of the list, sorted ascending. If there is no p

th element, return 0.

Example: n = 20 and p = 3
The factors of 20 in ascending order are {1, 2, 4, 5, 10, 20}. Using 1-based indexing, if p = 3, then 4 is
returned. If p > 6, 0 would be returned.
Function Description
Complete the function pthFactor in the editor below.
pthFactor has the following parameter(s):
int n: the integer whose factors are to be found
int p: the index of the factor to be returned
Returns:
int: the long integer value of the p

th integer factor of n or, if there is no factor at that index, then 0 is returned*/




#include<stdio.h>
int pthFactor(int n,int p);
int main(){
	int n,p;
	printf("Enter number\n");
	scanf("%d",&n);
	printf("Enter the p(pth factor) \n");
	scanf("%d",&p);

	int ans=pthFactor(n,p);
	printf("pth factor of number %d is %d",n,ans);
	return 0;
}

int pthFactor(int n,int p){
	int factor[10];
	for(int i=0;i<10;i++){
		factor[i]=-1;
	}
	int idx=1;
	for(int i=1;i<=n;i++){
		if(n%i==0){
			factor[idx++]=i;
		}
	}
	if(factor[p]==-1){
		return 0;
	}
	else{
		return factor[p];
	}
}



