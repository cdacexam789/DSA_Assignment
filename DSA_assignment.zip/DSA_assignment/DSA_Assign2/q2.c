/*Q2. Write a C/C++ program to implement Binary Search. We need to check for duplicate element
inputs, if found any should not insert into the input array. The array should manage in sorted order.
Apply a duplicacy check on the element while inserting the element, if found duplicate then discards
the input. The input element should insert in the array at the right position( index). Appropriate
shifting can be applied in the array in order to insert the input element at the right position. An
appropriate condition check needs to apply for element not found scenario.
(a) Binary Search ( iterative approach)
(b) Binary Search ( recursion approach )*/

#include<stdio.h>

void binary_search_it(int a[],int key,int len);
int binary_search_rec(int a[],int key,int st,int end);
void Display(int a[],int len);
int main(){
	int n;
	printf("Enter size of array\n");
	scanf("%d",&n);

	int a[n];
	printf("Enter array elements\n");
	int x,idx=0;
	while(idx<n){
		scanf("%d",&x);
		if(idx==0){
			a[idx++]=x;
		}
		else{
			if(binary_search_rec(a,x,0,idx-1)!=-1){
				printf("Element already present in array.Please enter other element\n");
                	}
	      	 	else{                                        
			       if(a[idx-1]<x){
				   a[idx++]=x;
			       }
		    		else{
			 		int i=idx;
					while(i>=1 && a[i-1]>x){
						a[i]=a[i-1];
						i--;
					}
					idx++;
					a[i]=x;
				}		
			}
		}
	}
	int choice;
	while(1){
	printf("=============Menu===========\n");
	printf("1.Binary search using iteration\n2.Binary search using recursion\n3.Display array\n4.Exit\n");
	scanf("%d",&choice);
	switch(choice){
		case 1:
			int key;
			printf("Enter key to search\n");
			scanf("%d",&key);
			binary_search_it(a,key,n);
			break;
		case 2:
			printf("Enter key to search\n");
                        scanf("%d",&key);
			int st=0,end=n-1;
                        int ans=binary_search_rec(a,key,st,end);
			if(ans==-1){
				printf("Element not present in an array\n");
			}
			else{
				printf("Element found at %d index\n",ans);
			}
			break;
		case 3:
			Display(a,n);
			break;
		case 4:
			return -1;
		default:
			return -1;
	}
	}

	return 0;
}
void Display(int a[],int len){
	for(int i=0;i<len;i++){
		printf("%d ",a[i]);
	}
	printf("\n");
}
void binary_search_it(int a[],int key,int len){
	int st=0;
	int end=len-1;
	while(st<=end){
		int mid=st+ (end-st)/2;
		if(a[mid]==key){
			printf("Element found at %d index\n",mid);
			return;
		}
		else if(a[mid]<key){
			st=mid+1;
		}
		else{
			end=mid-1;
		}
	}
	printf("Element not found\n");

}
int  binary_search_rec(int a[],int key,int st,int end){
	if(st<=end){
		int mid=st+(end-st)/2;
		if(a[mid]==key){
			//printf("Element found at %d index\n",mid);
			return mid;
		}
		else if(a[mid]<key){
			binary_search_rec(a,key,mid+1,end);
		}
		else{
			binary_search_rec(a,key,st,mid-1);
		}
	}
	else{

		return -1;
	}
}

