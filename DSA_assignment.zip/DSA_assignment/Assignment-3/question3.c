#include<stdio.h>
#include <stdlib.h>

struct node
{
	int val;
	struct node *next;
};

struct node *head=NULL;

/* Insert element in sorted order */
void insert(int x)
{
	struct node *temp,*curr,*prev;
	temp=(struct node*)malloc(sizeof(struct node));
	curr=head, prev=NULL;
	temp->val=x;
	temp->next=NULL;
	if(head == NULL)
	{
		head=temp;
	}
	else
	{
		while(curr !=NULL && x > curr->val)
		{
			prev=curr;
			curr=curr->next;
		}
		prev->next=temp;
		temp->next=curr;
	}
}

/* Display the elements */
void display()
{
	if(head == NULL)
		return;
	struct node *t1=head;
	while(t1 != NULL)
	{
		printf("->%d",t1->val);
		t1=t1->next;
	}
	printf("\n");
}

/* Count the nodes of linked list */
void listnodecount()
{
	if(head == NULL)
		return;
	int count=0;
	struct node *t1=head;
	while(t1 != NULL)
	{
		count++;
		t1=t1->next;
	}
	printf("Count=%d\n",count);
}

/* Delete the node from the end */
void deletefromend()
{
	if(head==NULL)
	{
		printf("List is Empty nothing to delete\n");
		return;
	}
	struct node *t1,*t2;
	t1=head;
	t2=NULL;
	while(t1->next != NULL)
	{
		t2=t1;
		t1=t1->next;
	}
	free(t1);
	t2->next=NULL;
	display();
}

/* Delete the node from the beginning */
void deletefrombegin()
{
	struct node *t1=head;
	head=t1->next;
	free(t1);
	display();
}

/* Delete the node at position */
void deletefrompos(int pos)
{
	struct node *t1,*t2;
	t1=head,t2=NULL;
	int count=1;
	if(pos==1)
	{
		deletefrombegin();
		return;
	}

	while(count < pos)
	{
		t2=t1;
		t1=t1->next;
		count++;
	}
	t2->next=t1->next;
	free(t1);
	display();
}

/* Reverse Display Of a Linked List */
void reversedisplay(struct node *head)
{
	if(head == NULL)
		return;
	reversedisplay(head->next);
	printf("->%d",head->val);
}

int main()
{
	int choice,ele,pos;
	while(1)
	{
		printf("1. insert\n");
		printf("2. displayList\n");
		printf("3. listNodeCount\n");
		printf("4. deleteFromEnd\n");
		printf("5. deleteFromBeg\n");
		printf("6. deleteFromPos\n");
		printf("7.reverseDisplay\n");
		printf("8. Exit\n");
		printf("Enter your choice:");
		scanf("%d", &choice);

		switch (choice) {
			case 1:
				printf("===========================================\n");
				printf("Enter ele:");
				scanf("%d", &ele);
				insert(ele);
				printf("===========================================\n");
				break;
			case 2:
				printf("===========================================\n");
				display();
				printf("===========================================\n");
				break;
			case 3:
				printf("===========================================\n");
				listnodecount();
				printf("===========================================\n");
				break;
			case 4:
				printf("===========================================\n");
				deletefromend();
				printf("===========================================\n");
				break;
			case 5:
				printf("===========================================\n");
				deletefrombegin();
				printf("===========================================\n");
				break;
			case 6:
				printf("===========================================\n");
				printf("Enter pos:");
				scanf("%d",&pos);
				deletefrompos(pos);
				printf("===========================================\n");
				break;
			case 7:
				printf("===========================================\n");
				reversedisplay(head);
				printf("\n");
				printf("===========================================\n");
				break;
			case 8:
				printf("===========================================\n");
				printf("Exiting...\n");
				printf("===========================================\n");
				exit(0);
			default:
				printf("===========================================\n");
				printf("Invalid choice! Please try again.\n");
				printf("===========================================\n");
		}
	}
}
