#include<stdio.h>
#include<stdlib.h>

/* Swapping Function */
void swap(int *a, int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

/* Bubble Sort Function */
void bubble(int arr[], int n)
{
	printf("Enter elements of array:");
	for(int i=0 ; i<n; i++)
	{
		scanf("%d",&arr[i]);
	}
	
	for(int i=0; i<n; i++)
	{
		for(int j=0; j<n-i-1; j++)
		{
			if(arr[j] > arr[j+1])
			{
				swap(&arr[j], &arr[j+1]);
			}
		}
	}
	printf("Bubble Sort done successfully\n");
}

/* Selection Sort Function */
void selection(int arr[], int n)
{
	printf("Enter elements of array:");
	for(int i=0 ; i<n; i++)
	{
		scanf("%d",&arr[i]);
	}
	
	int i,j,min_idx;
	for(int i=0; i<n; i++)
	{
		min_idx=i;
		for(int j=i+1; j<n; j++)
		{
			if(arr[j] < arr[min_idx])
				min_idx=j;
		}
		if(min_idx != i)
			swap(&arr[min_idx], &arr[i]);
	}
	printf("Selection Sort done successfully\n");
}

/* Insertion Sort Function */
void insertion(int arr[], int n)
{
	printf("Enter elements of array:");
	for(int i=0 ; i<n; i++)
	{
		scanf("%d",&arr[i]);
	}
	
	int i,j,key;
	for(int i=1; i<n; i++)
	{
		key=arr[i];
		j=i-1;
		while(j>=0 && arr[j]>key)
		{
			arr[j+1]=arr[j];
			j=j-1;
		}
		arr[j+1]=key;
	}
	printf("Insertion Sort done successfully\n");
}

/* Display the elements */
void display(int arr[], int n)
{
	for(int i=0; i<n; i++)
	{
		printf("%d ",arr[i]);
	}
	printf("\n");
}

int main()
{
	int n,choice;
	printf("Enter size of array:");
	scanf("%d",&n);
	int arr[n];

	while(1)
	{
		printf("1. Bubble Sort\n2. Selection Sort\n3. Insertion Sort\n4. Display\n5.Exit\n");
		printf("Enter Choice:");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				printf("===========================================\n");
				bubble(arr,n);		// Call Bubble Sort
				printf("===========================================\n");
				break;
			case 2:
				printf("===========================================\n");
				selection(arr,n);	// Call Selection Sort
				printf("===========================================\n");
				break;
			case 3:	
				printf("===========================================\n");
				insertion(arr,n);	// Call Insertion Sort
				printf("===========================================\n");
				break;
			case 4:
				printf("===========================================\n");
				display(arr,n);		// Call Display 
				printf("===========================================\n");
				break;
			case 5:
				printf("===========================================\n");
				printf("Exiting...\n");
				printf("===========================================\n");
				exit(0);		// Exit Program
			default:
				printf("===========================================\n");
				printf("Invalid choice! Please try again.\n");
				printf("===========================================\n");
		}
	}
}	
