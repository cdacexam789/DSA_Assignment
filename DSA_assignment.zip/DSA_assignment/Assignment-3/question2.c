#include<stdio.h>
#include <stdlib.h>

struct node
{
	int val;
	struct node *next;
};

struct node *head=NULL;

/* Insert element at the end */
void insertatend(int x)
{
	struct node *temp,*t1;
	temp=(struct node*)malloc(sizeof(struct node));
	t1=head;
	temp->val=x;
	temp->next=NULL;
	if(head == NULL)
	{
		head = temp;
	}
	else
	{
		while(t1->next != NULL)
		{
			t1=t1->next;
		}
		t1->next=temp;
	}
}

/* Insert element at the beginning */
void insertatbegin(int x)
{
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->val=x;
	temp->next=NULL;
	temp->next=head;
	head=temp;
}

/* Insert element at particular position */
void insertatpos(int ele,int pos)
{
	if(pos < 1)
	{
		printf("Invalid position\n");
		return;
	}
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	struct node *t1=head;
	temp->val=ele;
	temp->next=NULL;
	int count=1;
	if(pos==1)
	{
		insertatbegin(ele);
		return;
	}

	while(count < pos-1)
	{
		t1=t1->next;
		count++;
	}
	temp->next=t1->next;
	t1->next=temp;
}

/* Display the elements */
void display()
{
	if(head == NULL)
		return;
	struct node *t1=head;
	while(t1 != NULL)
	{
		printf("->%d",t1->val);
		t1=t1->next;
	}
	printf("\n");
}

/* Count the nodes of linked list */
void listnodecount()
{
	if(head == NULL)
		return;
	int count=0;
	struct node *t1=head;
	while(t1 != NULL)
	{
		count++;
		t1=t1->next;
	}
	printf("Count=%d\n",count);
}

/* Delete the node from the end */
void deletefromend()
{
	if(head==NULL)
	{
		printf("List is Empty nothing to delete\n");
		return;
	}
	struct node *t1,*t2;
	t1=head;
	t2=NULL;
	while(t1->next != NULL)
	{
		t2=t1;
		t1=t1->next;
	}
	free(t1);
	t2->next=NULL;
	display();
}

/* Delete the node from the beginning */
void deletefrombegin()
{
	struct node *t1=head;
	head=t1->next;
	free(t1);
	display();
}

/* Delete the node at position */
void deletefrompos(int pos)
{
	struct node *t1,*t2;
	t1=head,t2=NULL;
	int count=1;
	if(pos==1)
	{
		deletefrombegin();
		return;
	}

	while(count < pos)
	{
		t2=t1;
		t1=t1->next;
		count++;
	}
	t2->next=t1->next;
	free(t1);
	display();
}

/* Delete By the element */
void deleteByElement(int ele)
{
	struct node *t1,*t2;
	t1=head, t2=NULL;
	if(t1 != NULL && t1->val == ele)
	{
		head=t1->next;
		free(t1);
		return;
	}
	while(t1 != NULL && t1->val != ele)
	{
		t2=t1;
		t1=t1->next;
	}
	t2->next=t1->next;
	free(t1);
	display();
}

/* Reverse Display Of a Linked List */
void reversedisplay(struct node *head)
{
	if(head == NULL)
		return;
	reversedisplay(head->next);
	printf("->%d",head->val);
}

/* Free the Node */
void freeallnode()
{
	struct node *temp;
	while(head != NULL)
	{
		temp=head;
		head=head->next;
		free(temp);
	}
	printf("All Nodes are freed\n");
}

/* Reverse of a Linked List */
void reverselist()
{
	if(head == NULL)
		return;
	struct node *curr=head;	 
	struct node *prev=NULL;	 
	struct node *next=head;  
	while(curr != NULL) 
	{
		next=curr->next;	// Save the next node
		curr->next=prev;	// Reverse the current node's pointer 
		prev=curr;		// Move `prev` one step forward
		curr=next;		// Move `curr` one step forward
	}
	head=prev;	// Update the head to the new head of the reversed list
	display();
}

int main()
{
	int choice,ele,pos;
	while(1)
	{
		printf("1. insertAtEnd\n");
		printf("2. insertAtBeg\n");
		printf("3. insertAtPos\n");
		printf("4. displayList\n");
		printf("5. listNodeCount\n");
		printf("6. deleteFromEnd\n");
		printf("7. deleteFromBeg\n");
		printf("8. deleteFromPos\n");
		printf("9. deleteByElement\n");
		printf("10.reverseDisplay\n");
		printf("11. freeAllNode\n");
		printf("12. reverseList\n");
		printf("13. sortedList\n");
		printf("14. Exit\n");
		printf("Enter your choice:");
		scanf("%d", &choice);

		switch (choice) {
			case 1:
				printf("===========================================\n");
				printf("Enter ele:");
				scanf("%d", &ele);
				insertatend(ele);
				printf("===========================================\n");
				break;
			case 2:
				printf("===========================================\n");
				printf("Enter ele:");
				scanf("%d", &ele);
				insertatbegin(ele);
				printf("===========================================\n");
				break;
			case 3:
				printf("===========================================\n");
				printf("Enter ele& pos:");
				scanf("%d %d", &ele,&pos);
				insertatpos(ele,pos);
				printf("===========================================\n");
				break;
			case 4:
				printf("===========================================\n");
				display();
				printf("===========================================\n");
				break;
			case 5:
				printf("===========================================\n");
				listnodecount();
				printf("===========================================\n");
				break;
			case 6:
				printf("===========================================\n");
				deletefromend();
				printf("===========================================\n");
				break;
			case 7:
				printf("===========================================\n");
				deletefrombegin();
				printf("===========================================\n");
				break;
			case 8:
				printf("===========================================\n");
				printf("Enter pos:");
				scanf("%d",&pos);
				deletefrompos(pos);
				printf("===========================================\n");
				break;
			case 9:
				printf("===========================================\n");
				printf("Enter ele:");
				scanf("%d", &ele);
				deleteByElement(ele);
				printf("===========================================\n");
				break;
			case 10:
				printf("===========================================\n");
				reversedisplay(head);
				printf("\n");
				printf("===========================================\n");
				break;
			case 11:
				printf("===========================================\n");
				freeallnode();
				printf("===========================================\n");
				break;
			case 12:
				printf("===========================================\n");
				reverselist();
				printf("===========================================\n");
				break;
			case 14:
				printf("===========================================\n");
				printf("Exiting...\n");
				printf("===========================================\n");
				exit(0);
			default:
				printf("===========================================\n");
				printf("Invalid choice! Please try again.\n");
				printf("===========================================\n");
		}
	}
}
