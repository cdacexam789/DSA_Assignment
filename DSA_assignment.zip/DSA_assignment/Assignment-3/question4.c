#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct student
{
	char name[20];
	int prn;
};

struct node
{
	struct student val;
	struct node* next;
};

struct node* head=NULL;

void insertatend(struct student x)
{
	struct node *temp;
	struct node* t1=head;
	//creation of node
	temp=(struct node*)malloc(sizeof(struct node));
	strcpy(temp->val.name,x.name);
	temp->val.prn=x.prn;
	temp->next=NULL;

	//check if malloc is successfully done or not
	if(temp==NULL)
	{
		printf("Memory Allocation failed");
		return;
	}

	//check if linked list exist or not
	if(t1==NULL)
	{
		//if not exist means it is first node of linked list
		head=temp;
		return;
	}

	//traverse to last node 
	while(t1->next!=NULL)
	{
		t1=t1->next;
	}

	//link the last node of linked list to new temp node
	t1->next=temp;
}

void insertatbegin(struct student x)
{
	struct node *temp;
	struct node* t1=head;
	//creation of node
	temp=(struct node*)malloc(sizeof(struct node));
	strcpy(temp->val.name,x.name);
	temp->val.prn=x.prn;
	temp->next=NULL;
	//check if malloc is successfully done or not
	if(temp==NULL)
	{
		printf("Memory Allocation failed");
		return;
	}
	//check if linked list exist or not
	if(t1==NULL)
	{
		//if not exist means it is first node of linked list
		head=temp;
		return;
	}
	//link new temp to first node and head
	temp->next = head;
	head = temp;
}

void insertatpos(struct student ele,int pos)
{
	int n=listNodeCount();
	struct node *temp;
	struct node* t1=head;
	temp=(struct node*)malloc(sizeof(struct node));
	strcpy(temp->val.name,ele.name);
	temp->val.prn=ele.prn;
	temp->next=NULL;
	//check if position enter by user is valid or not 
	if(pos<=0 || pos> n)
	{
		printf("Invalid position\n");
		return;
	}
	//check if malloc is successfully done or not
	if(temp==NULL)
	{
		printf("Memory Allocation failed\n");
		return;
	}
	//check if linked list exist or not
	if(t1==NULL)
	{
		head=temp;
		return;
	}	
	int count=1;
	//check while count is less than position-1
	while(count<pos-1)
	{
		t1=t1->next;
		count++;
	}
	temp->next=t1->next;
	t1->next=temp;
}

//Display the linked list
void displayList()
{
	struct node *t1;
	t1=head;
	while(t1!=NULL)	
	{
		printf("-->[%s %d] ",t1->val.name,t1->val.prn);
		t1=t1->next;
	}
	printf("\n");
}

//Count the number of nodes
int listNodeCount()
{
	int n=0;
	struct node* t=head;
	//traverse till node is not equal to null
	while(t!=NULL)
	{
		t=t->next;
		n++;
	}
	return n;
}

//delete at the end
void deletefromend()
{
	struct node* prev,*curr;
	prev=NULL;
	curr=head;
	if(curr==NULL)
	{
		printf("No node to be deleted\n");
		return;
	}	
	while(curr->next!=NULL)
	{
		prev=curr;
		curr=curr->next;
	}
	if(curr==head)
	{
		head=NULL;
	}
	else
	{
		prev->next=NULL;
	}
	free(curr);
}	

//delete at the beginning
void deletefrombeg(){
	if(head==NULL){
		printf("No node to delete\n");
		return;
	}
	struct node* t=head;
	head= t->next;
	free(t);
}

void deletefrompos(int pos){
	// for deletion, make sure list exist
	if(head==NULL)
	{
		printf("No node to delete\n");
		return;
	}

	//get count of list to check if position enter by user is valid or not 
	int p=listNodeCount();
	if(pos>p || pos<=0)
	{
		printf("Invalid position\n");
		return;
	}

	if(pos==1 && p==1)
	{
		deletefrombeg();
		return;
	}

	struct node* prev , *curr;
	prev=NULL;
	curr=head;
	int count=1;
	if(count<pos)
	{
		prev=curr;
		curr=curr->next;
		count++;
	}
	prev->next=curr->next;
	free(curr);
}

//delete by element
void deletebyelement(int prn)
{
	struct node*prev,*curr;
	curr=head;
	prev=NULL;
	while(curr->next!=NULL && curr->val.prn!=prn)
	{
		prev=curr;
		curr=curr->next;
	}
	if(curr==head && curr->val.prn==prn)
	{
		deletefrombeg();
		return;
	}
	if(curr->val.prn!=prn &&curr->next==NULL)
	{
		printf("Element not found\n");
		return;
	}

	prev->next=curr->next;
	free(curr);
}

void reverseDisplay(struct node* temp)
{		
	if(temp==NULL)
	{
		return;
	}
	reverseDisplay(temp->next);
	printf("-->[%s %d] ",temp->val.name,temp->val.prn);
}

void freenode()
{
	struct node *t1=head;
	if(head==NULL)
	{
		return;
	}
	while(t1!=NULL)
	{
		head=t1->next;
		free(t1);
		t1=head;
	}
	head=NULL;
}


int main()
{
	int choice,count;
	printf("Enter your choice");
	struct student x;
	while(1)
	{

		printf("=====Menu========\n");                // menu for user
		printf("1.Insert at the end\n");
		printf("2.Insert at the beginning\n");
		printf("3.Insert at the position\n");
		printf("4.Display\n");
		printf("5.list node count\n");
		printf("6.Delete at the end\n");
		printf("7.Delete at the beginning\n");
		printf("8.Delete from position\n");
		printf("9.Delete by element\n");
		printf("10.Reverse displayList\n");
		printf("11.free all node\n");
		printf("12.Exit\n");
		scanf("%d",&choice);

		switch(choice)
		{
			case 1:
				printf("Enter val to be insert at end in linked list\n");
				printf("Name:");
				getchar();
				scanf("%[^\n]s",x.name);
				printf("PRN:");
				scanf("%d",&x.prn);
				insertatend(x);     //insert element at end in linked list
				break;
			case 2: 
				printf("Enter val to be insert at beg in linked list\n");
				printf("Name");
				getchar();
				scanf("%[^\n]s",x.name);
				printf("PRN:");
				scanf("%d",&x.prn);
				insertatbegin(x);    //insert element at beginning in linked list
				break;
			case 3:
				printf("Enter the studentent val\n");
				printf("Name:");
				getchar();
				scanf("%[^\n]s",x.name);
				printf("PRN:");
				scanf("%d",&x.prn);
				int pos;
				printf("Position:");
				scanf("%d",&pos);  
				insertatpos(x,pos);      //insert element at given position in linked list
				break;
			case 4:
				displayList();
				break;
			case 5:
				count=listNodeCount();     // return the number of nodes in a linked list
				printf("Count of nodes in linked list is %d\n",count);
				break;
			case 6:
				deletefromend();         //delete a node from end 
				break;
			case 7: 
				deletefrombeg();         //delete first node from linked list 
				break;
			case 8:
				printf("Enter the position to delete\n");
				scanf("%d",&pos);
				deletefrompos(pos);     //delete element at specified position from linked list
				break;
			case 9:
				printf("Enter prn to be deleted\n");
				int prn;
				scanf("%d",&prn);
				deletebyelement(prn);     //delete the given element from linked list 
				break;
			case 10:
				reverseDisplay(head);   //displayList linked list in reverse order
				printf("\n");
				break;
			case 11:
				freenode();         //free all node in a linked list
				break;
			case 12: 
				freenode();
				return -1;
			default :
				freenode();
				return -1;
		}
	}
}
