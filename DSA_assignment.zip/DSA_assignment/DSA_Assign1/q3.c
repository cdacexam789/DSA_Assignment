/* Q3. Write C/C++ prgram which allocate and deallocate memory 
dynamically. 
(a) Allocating 1D array dynamically and access the elements
 (b) Allocating 2D array dynamically
 (1) contiguous rows with fixed no.of cols,
 (2) Non contiguous rows with variable no.of columns
 (c) Allocate memory for array of structure variables dynamically and 
access members of each element
*/

#include<stdio.h>
#include<stdlib.h>

typedef struct {
    char name[20];
    int age;
}student;

void array1d(int *ptr ,int n);
student* struct_student();
void array2d_a_ptr(int**,int,int);
void array2d_cont(int (*ptr)[],int row,int col);
int main(){
    int n;
    int row,col;
    //1
    printf("Enter the size of array");
    scanf("%d",&n);
    int *ptr = (int*)malloc(n*sizeof(int));
    if (ptr == NULL) {
        printf("Memory allocation failed!\n");
        return 1;
    }
    array1d(ptr,n);
    
    // 2-a
    int row2d,col2d=3;
    printf("Enter number rows for contigous\n");
    scanf("%d",&row2d); 
    int (*ptr1)[3]=(int (*)[3])malloc(row2d*3*sizeof(int));
    if(ptr1==NULL){
        printf("Memory Allocation Failed\n");
    }
    array2d_cont(ptr1,row2d,3);
    
    // 2-b   
    printf("Enter the number of rows and column");
    scanf("%d %d",&row ,&col);
    int **ptr2=(int**)malloc(row*sizeof(int*));// int* ptr2[row];
    for(int i=0;i<row;i++){
   	 *(ptr2+i)=(int*)malloc(col*sizeof(int));
    }
    
   
    array2d_a_ptr(ptr2,row,col);
    
    //3
    student * stu=struct_student();
    free(stu);
    free(ptr1);
    
    for(int i=0;i<row;i++){
    	free(ptr2[i]);
    }  
    free(ptr2);
   	
    free(ptr);


    return 0;
    
}

//contiguous rows with fixed no.of cols,
void array2d_cont(int (*ptr)[3],int row,int col){
	printf("Enter 2D cont array element\n");
	for(int i=0; i<row;i++){
        	for(int j=0;j<col;j++){
        		
 			scanf("%d",(*(ptr+i)+j));       
        	}
        }
        for(int i=0; i<row;i++){
        	for(int j=0;j<col;j++){
        		printf("%d ",*(*(ptr+i)+j));
        	}
        	printf("\n");
        }
        	
}

// 2d array implementation using dynamic memory allocation - Non contiguous rows with variable no.of columns
void array2d_a_ptr(int**ptr,int row,int col){
	printf("Enter 2D array element\n");
	for(int i=0; i<row;i++){
        	for(int j=0;j<col;j++){
        		
 			scanf("%d",(*(ptr+i)+j));
        	}
        }
        for(int i=0; i<row;i++){
        	for(int j=0;j<col;j++){
        		printf("%d ",*(*(ptr+i)+j));
        	}
        	printf("\n");
        }
        	
        	
}

//(a) Allocating 1D array dynamically and access the elements
void array1d(int *ptr ,int n){
    printf("Enter the element of array");
    for(int i=0; i<n;i++){
    
    scanf("%d",&ptr[i]);
    }
    for(int i=0; i<n;i++){
        printf("%d\n", ptr[i]);
    }
   

}

//(c) Allocate memory for array of structure variables dynamically and 
//access members of each element
student *struct_student(){
    int n;
    printf("Enter the number of students");
    scanf("%d",&n);

    student *stu = (student*)malloc(n*sizeof(student));
    if(stu==NULL){
        printf("Memory Allocation fail");
        return NULL;
    }
    for(int i=0;i<n;i++){
        printf("Enter Student name");
        scanf("%s",stu[i].name);

        printf("Enter Student age");
        scanf("%d",&stu[i].age);
    }

    printf("Student details\n");
    for(int i=0;i<n;i++){
    	printf("Student Name :%s\n Student age=%d \n",stu[i].name,stu[i].age);

    } 
    return stu;
}
