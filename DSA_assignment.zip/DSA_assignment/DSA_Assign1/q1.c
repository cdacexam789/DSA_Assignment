/*Q1. Write a C/C++ program that declares an array of length N
containing integers between 1 and N. Implement menu driven
program using switch case for below mentioned functionalities.
(a) insert element at index
(b) delete element at index
(c) find min val
(d) find max val
(e) display array element
(f) reverse display array element
(g) search element in array
(h) array element count
(i) avg of all array element
(j) determine if array contains any duplicates.
(k) reverse array element

*/


#include<stdio.h>
#include<stdlib.h>

void insert(int *ptr,int num,int idx,int len);
void delete(int *ptr,int idx,int len);
void display(int *ptr,int len);
int max_val(int *ptr ,int len);
int min_val(int *ptr ,int len);
void reverse_display(int *ptr,int len);
void search_ele(int *ptr,int len,int ele);
float average(int *ptr ,int len );
 int array_cnt(int *ptr,int len);
 void reverse(int* ptr ,int len);
 int duplicate(int *ptr,int len);


int main(){
	int n;
	printf("Enter the size of array: ");
	scanf("%d",&n);

	int* ptr= (int*)malloc(sizeof(int)*n);
	for(int i=0;i<n;i++){
		ptr[i]=-67;
	}
	int choice;
	//printf("Enter your choice\n");
        //scanf("%d",&choice);

	while(1){
		printf("Menu Driven Program\n");
		printf("1.Insert Element at the index\n");
		printf("2.Delete Element at the index\n");
		printf("3.Find the minimum value\n");
                printf("4.Find the maximum value\n");
		printf("5.Display array of element\n");
                printf("6.Reverse display array element\n");
		printf("7.Search element in an array\n");
                printf("8.Array element count\n");
		printf("9.Average of all array element\n");
                printf("10.Determine if array contains any duplicates\n");
                printf("11.Reverse array element\n");
		printf("12.Exit\n");
		 printf("Enter your choice: ");
                scanf("%d",&choice);
	
		switch(choice){
			case 1: {
					int num, idx;
			       	printf("Enter the number you want to insert and in which index: ");
			        scanf("%d %d",&num , &idx);
					if(num>n || num<1){
					printf("Invalid entry\n");
					}
					else{
					insert(ptr,num,idx,n);
					}
			
				break;
			}
			case 2:{

					int idx;
				 printf("Enter the index you want to delete \n");
                                scanf("%d",&idx);
				delete(ptr,idx,n);
				break;
			}
			case 3:{
				int min=min_val(ptr,n);
				printf("Minimum value of array is %d \n", min);
				break;}
			case 4:{
				int max=max_val(ptr,n);
				printf("Maximum value of array is %d \n", max);
				break;}
			case 5:{
				display(ptr,n);
				break;}
			case 6:{
				reverse_display(ptr,n);
				break;}
			case 7:{
				int search;
				printf("Enter your element to search\n");
				scanf("%d",&search);
                                search_ele(ptr ,n,search);
                                break;}
            case 8:{
    	            int cnt=array_cnt(ptr,n);
						printf("Count of array is %d \n",cnt);
                                break;}
            case 9:{
                                float avg=average(ptr,n);
				printf("Average of array is %f\n",avg);
                                break;}
			case 10:{int flag;
                     flag=duplicate(ptr,n);
					 if(flag==1){
						printf("Duplicate found");
					 }else{
						printf("Duplicate not found");
					 }
                	  break;}
            case 11:{
                    reverse(ptr ,n);
                   break;
			}
                       
       
			default:
				return -1;

		}
		
		}

	
	free(ptr);
	return 0;

}
void insert(int *ptr,int num,int idx,int len){
	int flag=1;// flag to check empty space -initializes to 1 means non empty array
	if(idx<1 || idx>len){
		printf("Invalid index!\n");
		return;
	}
	if(ptr[idx-1]==-67){
		ptr[idx-1]=num;
	}
	else{
		if(idx==len){
			for(int i=0;i<len;i++){
				if(ptr[i]==-67){
					flag=0;
					ptr[i]=num;
					break;
				}
			}
		}
		else{
			for(int i=idx;i<len;i++){
				if(ptr[i]==-67){
					flag=0;
					ptr[i]=num;
					break;
				}
			}
		}
		if(flag){
			printf("Array is full! cant't insert element\n");
			return;
		}

	}
}

	
void delete(int *ptr,int idx,int len){
	if(idx<1 || idx>len){
                printf("Invalid index!\n");
                return;
        }
	if(ptr[idx-1]==-67){
		printf("Data is not there");
		return ;
	}
	else{
		printf("Element deleted is %d\n",ptr[idx-1]);
		ptr[idx-1]=-67;

	}
}

int max_val(int *ptr ,int len){
	int max;
	for(int i=0;i<len-1;i++){

		if(ptr[i]<ptr[i+1]){
			max=ptr[i+1];
		} 
	}
	return max;

}
int min_val(int *ptr ,int len){
        int min=ptr[0];
        for(int i=1;i<len;i++){
                if(min>ptr[i] && ptr[i]!=-67){
                        min=ptr[i];
                }
        }
        return min;

}

void display(int *ptr,int len){
	for(int i=0;i<len;i++){
		printf("ptr[%d]=%d\n", i ,ptr[i]);
	}
}
void reverse_display(int *ptr,int len){
        for(int i=len-1;i>=0;i--){
                printf("ptr[%d]=%d\n", i ,ptr[i]);
        }
}
void search_ele(int *ptr,int len,int ele){
	int i;
	for(i=0;i<len;i++){
		if(ptr[i]==ele){
			printf("Element found at %d\n", i+1);
			return;
		}
		
	}
	printf("Element not found\n");

}
int array_cnt(int *ptr,int len){
	int count=0;
	for(int i=0;i<len;i++){
		if(ptr[i]!=-67){
			count++;
		}

	}
	return count;
}

float average(int *ptr ,int len ){
	int sum=0;
	int i;
	float avg;
	 for(i=0;i<len;i++){
                if(ptr[i]!=-67){
			sum=sum+ptr[i];
		}
	 } 
	 avg=sum/len;
	return avg;
}

int duplicate(int *ptr,int len){
	int flag=0;
	int visit[len+1];
	for(int i=1;i<=len;i++){
		visit[i]=0;
	}
	for(int i=0;i<len;i++){
		visit[ptr[i]]++;
	}
	for(int i=0;i<len;i++){
		if(visit[ptr[i]]>1){
			flag=1;
			
			printf("%d have count  %d\n",ptr[i],visit[ptr[i]]);
			visit[ptr[i]]=-1;
		}
	}

	return flag;
}
void reverse(int* ptr ,int len){
	int i , j , temp;
	for(i=0,j=len-1;i<j;i++,j--){
		temp=ptr[i];
		ptr[i]=ptr[j];
		ptr[j]=temp;
		
	}
	printf("Reversed array");
    for (i = 0; i < len; i++) {
        printf("%d ", ptr[i]);
    }
}


