/* Q2. Create an employee structure with the following members
empid, employee name, salary, year of joining. 
Accept the data for certain no. of employees (Using array of structures) and find their total,
average, max, min salary. Also find out the employees with maximum, minimum service,
use a function to find service for each employee element in the array.
Year of service is the number of years a given person has worked from joining year to
current year. */

#include<stdio.h>
#include<stdlib.h>
#define curr_yr 2025
typedef struct Employee{
	int empid:10;
	char empname[20];
	double salary;
	int yr;
}emp;

void sal_emp(emp a[],int n);
void service_emp(emp a[],int n);

int main(){
	int n;
	printf("Enter the number of Employees\n");
	scanf("%d",&n);

	emp a[n];
	for(int i=0;i<n;i++){
	printf("==== Employee %d data input =====\n", i+1);
	printf("Enter your emp id");
	int b;
    scanf("%d",&b);
	a[i].empid=b;

	printf("Enter your employee name ");
	getchar();
	scanf("%[^\n]s",a[i].empname);
	
	printf("Enter your joining year");
        scanf("%d",&a[i].yr);
	if(a[i].yr>curr_yr){
		printf("Invalid joining year\n");
		exit(1);
	}
	printf("Enter the Annual Salary");
	scanf("%lf",&a[i].salary);
	}

	sal_emp(a,n);
	service_emp(a,n);
	return 0;

}

void sal_emp(emp a[],int n){
	double min_sal=a[0].salary;
	double max_sal=a[0].salary;
	double avg_sal,sum=0;
	for(int i=0;i<n;i++){
		if(a[i].salary<min_sal){
			min_sal=a[i].salary;
		}
		if(a[i].salary>max_sal){
			max_sal=a[i].salary;
		}
		sum+=a[i].salary;
	}
	printf("Minimum salary is %lf\nMaximum salary is %lf\nAverage salary is %lf\n",min_sal,max_sal,sum/n);
}

void service_emp(emp a[],int n){
	int max_ser=0,min_ser=50;
	int i_max,i_min;
	for(int i=0;i<n;i++){
                if( curr_yr-a[i].yr<min_ser){
                        min_ser= curr_yr-a[i].yr;
			i_min=i;
                }
                if( curr_yr-a[i].yr>max_ser){
                        max_ser= curr_yr-a[i].yr;
			i_max=i;
                }
          
        }
	printf("Maximum serviced employee is %s with employee id is %d\n",a[i_max].empname,a[i_max].empid);
	printf("Minimum serviced employee is %s with employee id is %d\n",a[i_min].empname,a[i_min].empid);
}


