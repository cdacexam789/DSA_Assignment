#include<stdio.h>
#include<stdlib.h>

struct node
{
	int val;
	struct node *next;
};


void insertatend(struct node **head, int x)
{
	struct node *temp,*t1;
	temp=(struct node*)malloc(sizeof(struct node));
	if(temp == NULL)
	{
		printf("Memory Allocation Failed\n");
		return;
	}
	temp->val=x;
	temp->next=NULL;	
	if(*head == NULL)
	{
		*head=temp;
		temp->next=*head;
	}
	else
	{
		t1=*head;
		while(t1->next != *head)
		{
			t1=t1->next;
		}
		t1->next=temp;
		temp->next=*head;
	}
}

void insertatbegin(struct node **head, int x)
{
	struct node *temp,*t1;
	temp=(struct node*)malloc(sizeof(struct node));
	if(temp == NULL)
	{
		printf("Memory Allocation Failed\n");
		return;
	}
	temp->val=x;
	temp->next=NULL;
	if(*head == NULL)
	{
		*head=temp;
		temp->next=*head;
	}
	else
	{
		t1=*head;
		while(t1->next != *head)
		{
			t1=t1->next;
		}
		temp->next=*head;
		*head=temp;
		t1->next=temp;
	}
}

void insertatpos(struct node **head, int x,int pos)
{
	struct node *temp=(struct node *)malloc(sizeof(struct node));
	if(temp == NULL)
	{
		printf("Memory Allocation Failed\n");
		return;
	}
	struct node *t1=*head;
	if(pos == 1)
	{
		insertatbegin(head,x);
		return;
	}

	temp->val=x;
	temp->next=NULL;
	int count=1;
	while(count < pos -1)
	{
		t1=t1->next;
		count++;
	}
	temp->next=t1->next;
	t1->next=temp;
}

void display(struct node *head)
{
	if(head == NULL)
	{
		printf("List is Empty\n");
		return;
	}
	struct node *t1=head;
	do
	{
		printf("->%d",t1->val);
		t1=t1->next;
	} while(t1 != head);
	printf("\n");
}

void listnodecount(struct node *head)
{
	if(head == NULL)
	{
		printf("List is Empty\n");
		return;
	}
	int count =0;
	struct node *t1=head;
	do
	{
		count++;
		t1=t1->next;
	} while(t1 != head);
	printf("No of Nodes=%d\n",count);
}

void deletefromend(struct node **head)
{
	struct node *t1,*t2;
	t1=*head,t2=NULL;
	while(t1->next != *head)
	{
		t2=t1;
		t1=t1->next;
	}
	free(t1);
	t2->next=*head;
}

void deletefrombegin(struct node **head)
{
	struct node *t1,*t2;
	t1=t2=*head;
	while(t2->next != *head)
	{
		t2=t2->next;
	}
	*head=t1->next;
	free(t1);
	t2->next=*head;
}

void deletefrompos(struct node **head, int pos)
{
	struct node *t1,*t2;
	t1=*head,t2=NULL;
	int count=1;
	if(pos==1)
	{
		deletefrombegin(head);
		return;
	}

	while(count < pos)
	{
		t2=t1;
		t1=t1->next;
		count++;
	}
	t2->next=t1->next;
	free(t1);
}

void freeallnode(struct node **head)
{
        struct node *temp,*t1=*head;
        while(t1->next != *head)
        {
                t1=t1->next;
        }
        t1->next=NULL;
        t1=*head;
        while(t1 != NULL)
        {
                temp=t1;
                t1=t1->next;
                free(temp);
        }
        printf("All Nodes are freed\n");
}

int main()
{
	struct node *head=NULL;
	int choice,ele,pos;
	while(1)
	{
		printf("1. insertAtEnd\n");
		printf("2. insertAtBeg\n");
		printf("3. insertAtPos\n");
		printf("4. displayList\n");
		printf("5. listNodeCount\n");
		printf("6. deleteFromEnd\n");
		printf("7. deleteFromBeg\n");
		printf("8. deleteFromPos\n");
		printf("9. Free\n");
		printf("10. Exit\n");
		printf("Enter your choice:");
		scanf("%d", &choice);
		switch(choice)
		{
			case 1:
				printf("===========================================\n");
				printf("Enter ele:");
				scanf("%d", &ele);
				insertatend(&head,ele);
				printf("===========================================\n");
				break;
			case 2:
				printf("===========================================\n");
				printf("Enter ele:");
				scanf("%d", &ele);
				insertatbegin(&head,ele);
				printf("===========================================\n");
				break;
			case 3:
				printf("===========================================\n");
				printf("Enter ele& pos:");
				scanf("%d %d", &ele,&pos);
				insertatpos(&head,ele,pos);
				printf("===========================================\n");
				break;
			case 4:
				printf("===========================================\n");
				display(head);
				printf("===========================================\n");
				break;
			case 5:
				printf("===========================================\n");
				listnodecount(head);
				printf("===========================================\n");
				break;
			case 6:
				printf("===========================================\n");
				deletefromend(&head);
				printf("===========================================\n");
				break;
			case 7:
				printf("===========================================\n");
				deletefrombegin(&head);
				printf("===========================================\n");
				break;
			case 8:
				printf("===========================================\n");
				printf("Enter pos:");
				scanf("%d",&pos);
				deletefrompos(&head,pos);
				printf("===========================================\n");
				break;
			case 9:
				printf("===========================================\n");
				freeallnode(&head);
				printf("===========================================\n");
				break;
			case 10:
				printf("===========================================\n");
				printf("Exiting...\n");
				printf("===========================================\n");
				exit(0);
			default:
				printf("===========================================\n");
				printf("Invalid choice! Please try again.\n");
				printf("===========================================\n");
		}
	}
}
