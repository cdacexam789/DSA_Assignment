#include <stdio.h>
#include <stdlib.h>

// Structure for Priority Queue
typedef struct {
    int arr[100];
    int size;
} PriorityQueue;

// Function to insert an element based on priority
void insert(PriorityQueue *pq, int element) {
    if (pq->size == 100) {
        printf("Queue Overflow! Cannot insert.\n");
        return;
    }

    int i = pq->size - 1;
    while (i >= 0 && pq->arr[i] < element) {
        pq->arr[i + 1] = pq->arr[i];  // Shifting elements to maintain priority order
        i--;
    }
    pq->arr[i + 1] = element;
    pq->size++;
    printf("%d inserted into Priority Queue.\n", element);
}

// Function to delete the highest priority element
void deleteHighestPriority(PriorityQueue *pq) {
    if (pq->size == 0) {
        printf("Queue Underflow! Nothing to delete.\n");
        return;
    }

    printf("Deleted element: %d\n", pq->arr[0]);
    for (int i = 0; i < pq->size - 1; i++)
        pq->arr[i] = pq->arr[i + 1];  // Shift elements after deletion

    pq->size--;
}

// Function to display the priority queue
void display(PriorityQueue *pq) {
    if (pq->size == 0) {
        printf("Priority Queue is empty.\n");
        return;
    }

    printf("Priority Queue: ");
    for (int i = 0; i < pq->size; i++)
        printf("%d ", pq->arr[i]);
    printf("\n");
}

// Main function with menu-driven operations
int main() {
    PriorityQueue pq;
    pq.size = 0;

    int choice, element;

    while (1) {
        printf("\nPriority Queue Menu:\n");
        printf("1. Insert Element\n");
        printf("2. Delete Highest Priority Element\n");
        printf("3. Display Queue\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter element to insert: ");
                scanf("%d", &element);
                insert(&pq, element);
                break;
            case 2:
                deleteHighestPriority(&pq);
                break;
            case 3:
                display(&pq);
                break;
            case 4:
                printf("Exiting...\n");
                exit(0);
            default:
                printf("Invalid choice! Try again.\n");
        }
    }

    return 0;
}

