#include <stdio.h>
#include <stdlib.h>

void merge(int arr[], int low, int mid, int up) {
    int *temp = (int *)malloc((up - low + 1) * sizeof(int));
    int i = low, j = mid + 1, k = 0;

    while (i <= mid && j <= up)
        temp[k++] = (arr[i] <= arr[j]) ? arr[i++] : arr[j++];

    while (i <= mid) temp[k++] = arr[i++];
    while (j <= up) temp[k++] = arr[j++];

    for (int p = 0; p < k; ++p)
        arr[low + p] = temp[p];

    free(temp);
}

void mergeSort(int arr[], int low, int up) {
    if (low < up) {
        int mid = (low + up) / 2;
        mergeSort(arr, low, mid);
        mergeSort(arr, mid + 1, up);
        merge(arr, low, mid, up);
    }
}

int partition(int arr[], int low, int up) {
    int pivot = arr[low], i = low + 1, j = up, temp;
    while (i <= j) {
        while (i <= up && arr[i] < pivot) i++;
        while (arr[j] > pivot) j--;
        if (i < j) {
            temp = arr[i];
            arr[i++] = arr[j];
            arr[j--] = temp;
        }
    }
    arr[low] = arr[j];
    arr[j] = pivot;
    return j;
}

void quickSort(int arr[], int low, int up) {
    if (low < up) {
        int pivloc = partition(arr, low, up);
        quickSort(arr, low, pivloc - 1);
        quickSort(arr, pivloc + 1, up);
    }
}

void heapify(int arr[], int size, int i) {
    int largest = i, left = 2 * i + 1, right = 2 * i + 2, temp;
    if (left < size && arr[left] > arr[largest]) largest = left;
    if (right < size && arr[right] > arr[largest]) largest = right;
    if (largest != i) {
        temp = arr[i];
        arr[i] = arr[largest];
        arr[largest] = temp;
        heapify(arr, size, largest);
    }
}

void heapSort(int arr[], int size) {
    for (int i = size / 2 - 1; i >= 0; i--)
        heapify(arr, size, i);

    for (int i = size - 1; i > 0; i--) {
        int temp = arr[0];
        arr[0] = arr[i];
        arr[i] = temp;
        heapify(arr, i, 0);
    }
}

void display(int arr[], int n) {
    for (int i = 0; i < n; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

int main() {
    int n, choice;
    
    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int *arr = (int *)malloc(n * sizeof(int)); 

    printf("Enter elements:\n");
    for (int i = 0; i < n; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr[i]);
    }

    printf("\nChoose sorting method:\n1. Merge Sort\n2. Quick Sort\n3. Heap Sort\nChoice: ");
    scanf("%d", &choice);

    switch (choice) {
        case 1:
            mergeSort(arr, 0, n - 1);
            break;
        case 2:
            quickSort(arr, 0, n - 1);
            break;
        case 3:
            heapSort(arr, n);
            break;
        default:
            printf("Invalid choice!\n");
            free(arr);
            return 1;
    }

    printf("Sorted array: ");
    display(arr, n);

    free(arr); // Free allocated memory
    return 0;
}

