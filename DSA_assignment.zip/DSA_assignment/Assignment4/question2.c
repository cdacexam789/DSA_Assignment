#include<stdio.h>
#include <stdlib.h>

#define SIZE 5  // Max size

/* Function to push an element contains arr, top, element */
void push(int *arr, int *top, int x)
{
    if(*top == SIZE-1)  // Check if the stack is full
    {
        printf("Stack is full\n");
        return;
    }
    (*top)++;  // Increment top index
    arr[*top] = x;  // Insert element at new top position
}

// Function to pop an element contains arr, top
int pop(int *arr, int *top)
{
    if(*top == -1)  // Check if the stack is empty
    {
        printf("Stack is Empty\n");
        return -1;
    }
    int temp = arr[*top];  // Store the top element
    arr[*top] = 0;  // Reset the popped position
    (*top)--;  // Move top index down
    return temp;  // Return popped element
}

// Function to get the top element (peep)
int peep(int *arr, int *top)
{
    if(*top == -1)  // Check if the stack is empty
    {
        printf("Stack is Empty\n");
        return -1;
    }
    return arr[*top];  // Return the top element
}

// Function to display stack elements
void display(int *arr, int *top)
{
    if(*top == -1)  // Check if the stack is empty
    {
        printf("Stack is Empty\n");
        return;
    }

    for(int i = 0; i <= *top; i++)  // Loop through the array
    {
        printf("[%d]", arr[i]);  // Print each element
    }
    printf("    top=(%d)\n", *top);  // Print the top index
}

// Function to check if the stack is full
void isStackFull(int *arr, int *top)
{
    if(*top == SIZE-1)
    {
        printf("Stack is full\n");
        return;
    }
}

// Function to check if the stack is empty
int isStackEmpty(int *arr, int *top)
{
    if(*top == -1)
    {
        printf("Stack is Empty\n");
        return -1;
    }
    return 0;
}

int main()
{
    int arr[SIZE], top = -1, choice, ele, ret, first;
    while(1)
    {
        // Print the menu
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. Peep\n");
        printf("4. Display Stack\n");
        printf("5. isStackFull\n");
        printf("6. isStackEmpty\n");
        printf("7. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        // Process user input using a switch statement
        switch (choice) 
        {
            case 1:
                printf("===========================================\n");
                printf("Enter element: ");
                scanf("%d", &ele);
                push(arr, &top, ele);
                printf("===========================================\n");
                break;
            case 2:
                printf("===========================================\n");
                ret = pop(arr, &top);
                if(ret != -1)
                {
                    printf("Popped Item = %d\n", ret);
                }
                printf("===========================================\n");
                break;
            case 3:
                printf("===========================================\n");
                first = peep(arr, &top);
                printf("Top Element = %d\n", first);
                printf("===========================================\n");
                break;
            case 4:
                printf("===========================================\n");
                printf("Stack items:\n");
                display(arr, &top);
                printf("===========================================\n");
                break;
            case 5:
                printf("===========================================\n");
                isStackFull(arr, &top);
                printf("===========================================\n");
                break;
            case 6:
                printf("===========================================\n");
                ret = isStackEmpty(arr, &top);
                if(ret == -1)
                {
                    printf("Stack is empty\n");
                }
                else
                {
                    printf("Stack is not empty\n");
                }
                printf("===========================================\n");
                break;
            case 7:
                printf("===========================================\n");
                printf("Exiting...\n");
                printf("===========================================\n");
                exit(0);
            default:
                printf("===========================================\n");
                printf("Invalid choice! Please try again.\n");
                printf("===========================================\n");
        }
    }
}
