#include<stdio.h>
#include <stdlib.h>

#define SIZE 5  // Maximum size of the queue

/* Function to add an element to the queue (enqueue) */
void enqueue(int *arr, int *front, int *rear, int x)
{
    if (*rear == SIZE - 1)  // Check if queue is full
    {
        printf("Queue is full\n");
        return;
    }

    if (*front == -1)  // queue is empty, set front to 0
        *front = 0;

    (*rear)++;  // Increment rear pointer
    arr[*rear] = x;  // Insert the element at the rear position
}

/* Function to remove an element from the queue (dequeue) */
int dequeue(int *arr, int *front, int *rear)
{
    if (*front == -1)  // Check if queue is empty
    {
        printf("Queue is Empty\n");
        return -1;
    }

    int temp = arr[*front];  // Store the front element to return it
    arr[*front] = 0;  

    // If only one element is present, reset front and rear pointers
    if (*front == *rear)
        *front = *rear = -1;
    else
        (*front)++;  // Move the front pointer to the next element

    return temp;  // Return the dequeued element
}

// Function to return the front element (peep)
int peep(int *arr, int *front)
{
    if (*front == -1)  // Check if queue is empty
    {
        printf("Queue is Empty\n");
        return -1;
    }
    return arr[*front];  // Return the front element
}

// Function to display the queue contents
void display(int *arr, int *front, int *rear)
{
    if (*front == -1)  // Check if queue is empty
    {
        printf("Queue is Empty\n");
        return;
    }

    for (int i = *front; i <= *rear; i++)  // Iterate from front to rear
    {
        printf("[%d]", arr[i]);  // Print each element
    }
    printf("    front=(%d) rear=(%d)\n", *front, *rear);  // Show front and rear indices
}

// Function to check if the queue is full
void isQueueFull(int *arr, int *rear)
{
    if (*rear == SIZE - 1)
    {
        printf("Queue is full\n");
        return;
    }
}

// Function to check if the queue is empty
int isQueueEmpty(int *arr, int *front)
{
    if (*front == -1)
    {
        printf("Queue is Empty\n");
        return -1;
    }
    return 0;
}

int main()
{
    int arr[SIZE], front = -1, rear = -1, choice, ele, ret, first;

    while (1)
    {
        // Print menu options
        printf("1. Enqueue\n");
        printf("2. Dequeue\n");
        printf("3. Peep\n");
        printf("4. Display Queue\n");
        printf("5. isQueueFull\n");
        printf("6. isQueueEmpty\n");
        printf("7. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        // Process user input based on menu choice
        switch (choice) 
        {
            case 1:
                printf("===========================================\n");
                printf("Enter element: ");
                scanf("%d", &ele);
                enqueue(arr, &front, &rear, ele);
                printf("===========================================\n");
                break;
            case 2:
                printf("===========================================\n");
                ret = dequeue(arr, &front, &rear);
                if (ret != -1)
                {
                    printf("Dequeued Item = %d\n", ret);
                }
                printf("===========================================\n");
                break;
            case 3:
                printf("===========================================\n");
                first = peep(arr, &front);
                printf("Front Element = %d\n", first);
                printf("===========================================\n");
                break;
            case 4:
                printf("===========================================\n");
                printf("Queue items:\n");
                display(arr, &front, &rear);
                printf("===========================================\n");
                break;
            case 5:
                printf("===========================================\n");
                isQueueFull(arr, &rear);
                printf("===========================================\n");
                break;
            case 6:
                printf("===========================================\n");
                ret = isQueueEmpty(arr, &front);
                if (ret == -1)
                {
                    printf("Queue is empty\n");
                }
                else
                {
                    printf("Queue is not empty\n");
                }
                printf("===========================================\n");
                break;
            case 7:
                printf("===========================================\n");
                printf("Exiting...\n");
                printf("===========================================\n");
                exit(0);
            default:
                printf("===========================================\n");
                printf("Invalid choice! Please try again.\n");
                printf("===========================================\n");
        }
    }
}
