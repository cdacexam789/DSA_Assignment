#include<stdio.h>
#include <stdlib.h>

#define SIZE 5  // Maximum size of the circular queue

// Function to add an element to the circular queue (enqueue)
void enqueue(int *arr, int *front, int *rear, int x)
{
    // Check if the queue is full
    if((*front == 0 && *rear == SIZE-1) || (*rear+1 == *front))
    {
        printf("Queue is full\n");
        return;
    }

    // Wrap around when rear reaches the end
    if(*rear == SIZE-1)
        *rear = 0;
    else
        (*rear)++;

    // If the queue was empty, set front to 0
    if(*front == -1)
        *front = 0;

    arr[*rear] = x;  // Insert element at the rear position
}

// Function to remove an element from the circular queue (dequeue)
int dequeue(int *arr, int *front, int *rear)
{
    // Check if the queue is empty
    if(*front == -1)
    {
        printf("Queue is Empty\n");
        return -1;
    }

    int temp = arr[*front];  // Store the front element to return it
    arr[*front] = 0;  // Clear the dequeued position (optional)

    // If only one element exists, reset front and rear
    if(*front == *rear)
        *front = *rear = -1;
    else if(*front == SIZE-1)  // Wrap around when front reaches the end
        *front = 0;
    else
        (*front)++;

    return temp;  // Return the dequeued element
}

// Function to return the front element (peek)
int peep(int *arr, int *front)
{
    if(*front == -1)  // Check if queue is empty
    {
        printf("Queue is Empty\n");
        return -1;
    }
    return arr[*front];  // Return the front element
}

// Function to display queue contents
void display(int *arr, int *front, int *rear)
{
    if (*front == -1)  // Check if queue is empty
    {
        printf("Queue is Empty\n");
        return;
    }

    int i = *front;
    printf("Queue contents: ");
    while (1)
    {
        printf("[%d] ", arr[i]);

        if (i == *rear)  // Stop when we reach the rear
            break;

        i = (i + 1) % SIZE;  // Move forward in circular manner
    }
    printf("\nFront = (%d), Rear = (%d)\n", *front, *rear);
}

// Function to check if the queue is full
void isQueueFull(int *arr, int *front, int *rear)
{
    if((*front == 0 && *rear == SIZE-1) || (*rear+1 == *front))
    {
        printf("Queue is full\n");
        return;
    }
}

// Function to check if the queue is empty
int isQueueEmpty(int *arr, int *front)
{
    if(*front == -1)
    {
        printf("Queue is Empty\n");
        return -1;
    }
    return 0;
}

int main()
{
    int arr[SIZE], front = -1, rear = -1, choice, ele, ret, first;

    while (1)
    {
        // Display menu options
        printf("1. Enqueue\n");
        printf("2. Dequeue\n");
        printf("3. Peep\n");
        printf("4. Display Queue\n");
        printf("5. isQueueFull\n");
        printf("6. isQueueEmpty\n");
        printf("7. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        // Process user input
        switch (choice) 
        {
            case 1:
                printf("===========================================\n");
                printf("Enter element: ");
                scanf("%d", &ele);
                enqueue(arr, &front, &rear, ele);
                printf("===========================================\n");
                break;
            case 2:
                printf("===========================================\n");
                ret = dequeue(arr, &front, &rear);
                if (ret != -1)
                {
                    printf("Dequeued Item = %d\n", ret);
                }
                printf("===========================================\n");
                break;
            case 3:
                printf("===========================================\n");
                first = peep(arr, &front);
                printf("Front Element = %d\n", first);
                printf("===========================================\n");
                break;
            case 4:
                printf("===========================================\n");
                display(arr, &front, &rear);
                printf("===========================================\n");
                break;
            case 5:
                printf("===========================================\n");
                isQueueFull(arr, &front, &rear);
                printf("===========================================\n");
                break;
            case 6:
                printf("===========================================\n");
                ret = isQueueEmpty(arr, &front);
                if (ret == -1)
                {
                    printf("Queue is empty\n");
                }
                else
                {
                    printf("Queue is not empty\n");
                }
                printf("===========================================\n");
                break;
            case 7:
                printf("===========================================\n");
                printf("Exiting...\n");
                printf("===========================================\n");
                exit(0);
            default:
                printf("===========================================\n");
                printf("Invalid choice! Please try again.\n");
                printf("===========================================\n");
        }
    }
}
