/*connect a 4 LED ladder circuit to the BB
write an LKM to create an LED runner circuit

create an IOCTL RUN_FORWORD where the LEDs glow on after the other in FORWORD direction.
Create an IOCTL RUN_BACKWORD where the LEDs glow on after the other in BACKWORD direction
Create an IOCTL STOP_RUNNING to put all LEDs to OFF state.

The time period between subsequent LEDs should be default 1 second.
Make this  time-delay changeable from user space using a module parameter(integer).*/

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/ioctl.h>
#include <linux/gpio.h>
#include <linux/kthread.h>
#include <linux/delay.h>

#define DEVICE_NAME "numdev_runner"
#define CLASS_NAME  "numdev_runner_class"
#define NUM_LEDS 4

#define IOCTL_RUN_FORWARD   _IO('r', 1)
#define IOCTL_RUN_BACKWARD  _IO('r', 2)
#define IOCTL_STOP_RUNNING  _IO('r', 3)
#define IOCTL_SET_DELAY     _IOW('r', 4, int)

static int led_gpios[NUM_LEDS] = {47, 48, 49, 60};

static int major;
static struct class *numdev_runner_class = NULL;
static struct cdev numdev_runner_cdev;

static struct task_struct *runner_thread = NULL;
static int running = 0; 

static int delay_msec = 1000; // Default: 1000 ms = 1 second
module_param(delay_msec, int, 0644);
MODULE_PARM_DESC(delay_msec, "Delay in milliseconds");

static void leds_off(void)
{
    int i;
    for (i = 0; i < NUM_LEDS; i++)
        gpio_set_value(led_gpios[i], 0);
}

static int runner_fn(void *data)
{
    int i;
    while (!kthread_should_stop()) {
        int mode = running;
        int local_delay = delay_msec;

        if (mode == 1) { // forward
            for (i = 0; i < NUM_LEDS && running == 1 && !kthread_should_stop(); i++) {
                leds_off();
                gpio_set_value(led_gpios[i], 1);
                msleep(local_delay); // Delay in ms[6][7]
            }
        } else if (mode == 2) { // backward
            for (i = NUM_LEDS - 1; i >= 0 && running == 2 && !kthread_should_stop(); i--) {
                leds_off();
                gpio_set_value(led_gpios[i], 1);
                msleep(local_delay); // Delay in ms[6][7]
            }
        } else {
            leds_off();
            msleep(100);
        }
    }
    leds_off();
    return 0;
}

static long numdev_runner_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    int user_delay;
    switch (cmd) {
        case IOCTL_RUN_FORWARD:
            running = 1;
            break;
        case IOCTL_RUN_BACKWARD:
            running = 2;
            break;
        case IOCTL_STOP_RUNNING:
            running = 0;
            leds_off();
            break;
        case IOCTL_SET_DELAY:
            if (copy_from_user(&user_delay, (int __user *)arg, sizeof(int)))
                return -EFAULT;
            if (user_delay < 0)
                return -EINVAL;
            delay_msec = user_delay;
            printk(KERN_INFO "numdev_runner: delay changed to %d ms\n", delay_msec);
            break;
        default:
            return -EINVAL;
    }
    return 0;
}

static ssize_t numdev_runner_write(struct file *file, const char __user *buf, size_t count, loff_t *ppos)
{
    char kbuf[16];
    int new_delay;

    if (count > sizeof(kbuf) - 1)
        return -EINVAL;

    if (copy_from_user(kbuf, buf, count))
        return -EFAULT;
    kbuf[count] = '\0';

    if (kstrtoint(kbuf, 10, &new_delay))
        return -EINVAL;
    if (new_delay < 0)
        return -EINVAL;

    delay_msec = new_delay;
    printk(KERN_INFO "numdev_runner: delay changed to %d ms (via write)\n", delay_msec);

    return count;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = numdev_runner_ioctl,
    .write = numdev_runner_write,
};

static int __init numdev_runner_init(void)
{
    dev_t dev;
    int ret, i;

    ret = alloc_chrdev_region(&dev, 0, 1, DEVICE_NAME);
    if (ret < 0) return ret;
    major = MAJOR(dev);

    cdev_init(&numdev_runner_cdev, &fops);
    ret = cdev_add(&numdev_runner_cdev, dev, 1);
    if (ret < 0) goto unregister_region;

    numdev_runner_class = class_create(THIS_MODULE, CLASS_NAME);
    if (IS_ERR(numdev_runner_class)) {
        ret = PTR_ERR(numdev_runner_class);
        goto del_cdev;
    }

    device_create(numdev_runner_class, NULL, dev, NULL, DEVICE_NAME);

    for (i = 0; i < NUM_LEDS; i++) {
        if (gpio_request(led_gpios[i], "led_gpio")) {
            printk(KERN_ERR "numdev_runner: Failed to request GPIO %d\n", led_gpios[i]);
            while (--i >= 0) gpio_free(led_gpios[i]);
            goto destroy_device;
        }
        gpio_direction_output(led_gpios[i], 0);
    }

    runner_thread = kthread_run(runner_fn, NULL, "led_runner_thread");
    if (IS_ERR(runner_thread)) {
        printk(KERN_ERR "numdev_runner: Failed to create kernel thread\n");
        ret = PTR_ERR(runner_thread);
        runner_thread = NULL;
        goto free_gpios;
    }

    printk(KERN_INFO "numdev_runner: device created\n");
    return 0;

free_gpios:
    for (i = 0; i < NUM_LEDS; i++)
        gpio_free(led_gpios[i]);
destroy_device:
    device_destroy(numdev_runner_class, dev);
    class_destroy(numdev_runner_class);
del_cdev:
    cdev_del(&numdev_runner_cdev);
unregister_region:
    unregister_chrdev_region(dev, 1);
    return ret;
}

static void __exit numdev_runner_exit(void)
{
    int i;
    dev_t dev = MKDEV(major, 0);

    if (runner_thread)
        kthread_stop(runner_thread);

    leds_off();

    for (i = 0; i < NUM_LEDS; i++)
        gpio_free(led_gpios[i]);
    device_destroy(numdev_runner_class, dev);
    class_destroy(numdev_runner_class);
    cdev_del(&numdev_runner_cdev);
    unregister_chrdev_region(dev, 1);
    printk(KERN_INFO "numdev_runner: device removed\n");
}

module_init(numdev_runner_init);
module_exit(numdev_runner_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("Kernel linked list - dynamic nodes!");

