#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define DEVICE "/dev/numdev_runner"
#define IOCTL_RUN_FORWARD   _IO('r', 1)
#define IOCTL_RUN_BACKWARD  _IO('r', 2)
#define IOCTL_STOP_RUNNING  _IO('r', 3)
#define IOCTL_SET_DELAY     _IOW('r', 4, int)

void usage(const char *prog)
{
    printf("Usage: %s f|b|s|d \n", prog);
  
}

int main(int argc, char *argv[])
{
    int fd, cmd = 0, delay;

    if (argc < 2) {
        usage(argv[0]);
        return EXIT_FAILURE;
    }

    if (strcmp(argv[1], "f") == 0)
        cmd = IOCTL_RUN_FORWARD;
        
    else if (strcmp(argv[1], "b") == 0)
        cmd = IOCTL_RUN_BACKWARD;
        
    else if (strcmp(argv[1], "s") == 0)
        cmd = IOCTL_STOP_RUNNING;                                                      
        
    else if (strcmp(argv[1], "d") == 0) {
        if (argc != 3) {
            usage(argv[0]);
            
            return EXIT_FAILURE;
        }
        delay = atoi(argv[2]);
        if (delay < 0) {
            printf("Delay must be >= 0\n");
            return EXIT_FAILURE;
        }
        fd = open(DEVICE, O_RDWR);
        if (fd < 0) {
            perror("open");
            return EXIT_FAILURE;
        }
        if (ioctl(fd, IOCTL_SET_DELAY, &delay) < 0) {
            perror("ioctl-set-delay");
            close(fd);
            return EXIT_FAILURE;
        }
        printf("Delay set to %d ms (via ioctl)\n", delay);
        close(fd);
        return EXIT_SUCCESS;
    } else if (strcmp(argv[1], "w") == 0) {
  
        if (argc != 3) {
            usage(argv[0]);
            return EXIT_FAILURE;
        }
        delay = atoi(argv[2]);
        if (delay < 0) {
            printf("Delay must be >= 0\n");
            return EXIT_FAILURE;
        }
        fd = open(DEVICE, O_WRONLY);
        if (fd < 0) {
            perror("open");
            return EXIT_FAILURE;
        }
        char buf[16];
        snprintf(buf, sizeof(buf), "%d", delay);
        if (write(fd, buf, strlen(buf)) < 0) {
            perror("write");
            close(fd);
            return EXIT_FAILURE;
        }
        printf("Delay set to %d ms \n", delay);
        close(fd);
        return EXIT_SUCCESS;
    } else {
        usage(argv[0]);
        return EXIT_FAILURE;
    }

    fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("open");
        return EXIT_FAILURE;
    }
    if (ioctl(fd, cmd) < 0) {
        perror("ioctl");
        close(fd);
        return EXIT_FAILURE;
    }
    printf("IOCTL sent: %s\n", argv[1]);
    close(fd);
    return EXIT_SUCCESS;
}

