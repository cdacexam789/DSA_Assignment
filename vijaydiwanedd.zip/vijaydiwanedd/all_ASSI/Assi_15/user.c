// test_numdev.c
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define DEVICE "/dev/numdev"
#define IOCTL_SEND_INT _IOW('a', 1, unsigned int)

int main()
{
    int fd;
    unsigned int num;

    printf("Enter an unsigned integer: ");
    scanf("%u", &num);

    fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    if (ioctl(fd, IOCTL_SEND_INT, &num) < 0) {
        perror("ioctl");
        close(fd);
        return 1;
    }

    printf("Sent %u to kernel module.\n", num);
    close(fd);
    return 0;
}

