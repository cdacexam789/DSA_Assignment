/*  

*/
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/ioctl.h>

#define DEVICE_NAME "numdev"
#define CLASS_NAME  "numdev_class"
#define IOCTL_SEND_INT _IOW('a', 1, unsigned int)

static int major;
static struct class *numdev_class = NULL;
static struct cdev numdev_cdev;

static void to_binary(unsigned int n, char *out)
{
    int i, started = 0, idx = 0;
    out[idx++] = '0';
    out[idx++] = 'b';
    for (i = 31; i >= 0; i--) {
        if (n & (1U << i)) started = 1;
        if (started)
            out[idx++] = (n & (1U << i)) ? '1' : '0';
    }
    if (!started) out[idx++] = '0';
    out[idx] = '\0';
}

static void to_octal(unsigned int n, char *out)
{
    char tmp[16];
    int idx = 0, j;
    if (n == 0) {
        strcpy(out, "0o0");
        return;
    }
    while (n > 0) {
        tmp[idx++] = '0' + (n & 7);
        n >>= 3;
    }
    out[0] = '0'; out[1] = 'o';
    for (j = 0; j < idx; j++)
        out[2 + j] = tmp[idx - 1 - j];
    out[2 + idx] = '\0';
}

static void to_hexadecimal(unsigned int n, char *out)
{
    char tmp[16];
    int idx = 0, j;
    const char *digits = "0123456789ABCDEF";
    if (n == 0) {
        strcpy(out, "0X0");
        return;
    }
    while (n > 0) {
        tmp[idx++] = digits[n & 0xF];
        n >>= 4;
    }
    out[0] = '0'; out[1] = 'X';
    for (j = 0; j < idx; j++)
        out[2 + j] = tmp[idx - 1 - j];
    out[2 + idx] = '\0';
}

static long numdev_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    unsigned int value;
    char binary[40], octal[20], hex[20];

    if (cmd == IOCTL_SEND_INT) {
        if (copy_from_user(&value, (unsigned int __user *)arg, sizeof(unsigned int)))
            return -EFAULT;

        to_binary(value, binary);
        to_octal(value, octal);
        to_hexadecimal(value, hex);

        printk(KERN_INFO "decimal: %u, binary: %s, octal: %s, hexadecimal: %s\n",
               value, binary, octal, hex);

        return 0;
    }
    return -EINVAL;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = numdev_ioctl,
};

static int __init numdev_init(void)
{
    dev_t dev;
    int ret;

    ret = alloc_chrdev_region(&dev, 0, 1, DEVICE_NAME);
    if (ret < 0) return ret;
    major = MAJOR(dev);

    cdev_init(&numdev_cdev, &fops);
    ret = cdev_add(&numdev_cdev, dev, 1);
    if (ret < 0) goto unregister_region;

    numdev_class = class_create(THIS_MODULE, CLASS_NAME);
    if (IS_ERR(numdev_class)) {
        ret = PTR_ERR(numdev_class);
        goto del_cdev;
    }

    device_create(numdev_class, NULL, dev, NULL, DEVICE_NAME);

    printk(KERN_INFO "numdev: device created\n");
    return 0;

del_cdev:
    cdev_del(&numdev_cdev);
unregister_region:
    unregister_chrdev_region(dev, 1);
    return ret;
}

static void __exit numdev_exit(void)
{
    device_destroy(numdev_class, MKDEV(major, 0));
    class_destroy(numdev_class);
    cdev_del(&numdev_cdev);
    unregister_chrdev_region(MKDEV(major, 0), 1);
    printk(KERN_INFO "numdev: device removed\n");
}

module_init(numdev_init);
module_exit(numdev_exit);


