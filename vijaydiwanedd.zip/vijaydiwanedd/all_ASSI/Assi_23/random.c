

/*

learn how to create random number in the kernel space. Learn about how to use get_random_bytes()
write an LKM to generate 1000 random number between 100 and -100 and print them is dmesg.


*/

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/random.h>

#define RANDOM_COUNT 1000
#define RANDOM_MAX   100
#define RANDOM_MIN  -100

static int __init random_lkm_init(void)
{
    int i, rand, mapped;

    printk(KERN_INFO "Rando Generating %d random numbers between %d and %d\n", RANDOM_COUNT, RANDOM_MIN, RANDOM_MAX);

    for (i = 0; i < RANDOM_COUNT; i++) {
        get_random_bytes(&rand, sizeof(rand));
        mapped = ((unsigned int)rand % (RANDOM_MAX - RANDOM_MIN + 1)) + RANDOM_MIN;
        printk(KERN_INFO "Random Number %d: %d\n", i + 1, mapped);
    }

    return 0;
}

static void __exit random_lkm_exit(void)
{
    printk(KERN_INFO "Random LKM: Module unloaded.\n");
}

module_init(random_lkm_init);
module_exit(random_lkm_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("CDAC EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("My own workqueue - dynamic example");

