/*create a LKM with support fir kernal ll 
the module should the following module params 
num_nodes -uint 
start_values -int 
step_size - int 

so thatt if the user gives the command :

the modulw  shoul create and print  the print the 10 - node LL with valueas:
0,2,4,6...\

in dmesg 

make sure all memory is cleaned up when the module exits / in unloadeds
*/

//sudo insmod module.ko num_nodes=10 start_value=0 step_size=2


#define pr_fmt(fmt)	KBUILD_MODNAME ": " fmt

#include <linux/module.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/list.h>



unsigned int num_nodes = 10;
module_param(num_nodes, uint, 0444);
MODULE_PARM_DESC(num_nodes, "Number of nodes in the linked list");

int start_value = 0;
module_param(start_value, int, 0444);
MODULE_PARM_DESC(start_value, "Start value for the first node");

int step_size = 2;
module_param(step_size, int, 0444);
MODULE_PARM_DESC(step_size, "Step size between node values");


/*means everyone owner Sysfs file permissions in octal 
the macro provided by the Linux kernel to allow READ ONLY
users to pass parameters to a module at load time */



struct my_node {
	int data;
	struct list_head my_list;
};


/* create list head pointer/node */
LIST_HEAD(my_head);

static int __init my_mod_init(void)
{
	unsigned int count;
	int data;
	struct my_node *node, *tmp;

	pr_info("Module loaded with num_nodes=%u, start_value=%d, step_size=%d\n",
		num_nodes, start_value, step_size);

	data = start_value;
	for (count = 0; count < num_nodes; count++) {
	
		node = kmalloc(sizeof(*node), GFP_KERNEL);
		
		if (!node) {
			pr_err("kmalloc failed at node %u\n", count);
			goto cleanup; 
			/* Free All nodes that were allocated before failure */
		}
		
		node->data = data;
		INIT_LIST_HEAD(&node->my_list);
		list_add_tail(&node->my_list, &my_head);
		data += step_size;
	}

	/* Print the linked list All Info */
	pr_info("Linked list values:\n");
	count = 0;
	list_for_each_entry(tmp, &my_head, my_list) {
		pr_info("Node %u: data=%d\n", count++, tmp->data);
	}
	return 0;

cleanup:
	/* Free All nodes that were allocated before failure */
	list_for_each_entry_safe(node, tmp, &my_head, my_list) {
	
		list_del(&node->my_list);
		kfree(node);
	}
	return -ENOMEM;
}

static void __exit my_mod_exit(void)
{
	struct my_node *node, *tmp;
	
	list_for_each_entry_safe(node, tmp, &my_head, my_list) {
	
		pr_info("Deleting node with data=%d\n", node->data);
		list_del(&node->my_list);
		/* Free All nodes that were allocated  */
		kfree(node); 
	}
	
	pr_info("Module unloaded, all memory freed.\n");
	pr_info("! Thank You !\n");
	
}

module_init(my_mod_init);
module_exit(my_mod_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("Kernel linked list - dynamic nodes!");

