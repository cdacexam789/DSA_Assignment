#ifndef MOD35_H
#define MOD35_H

#include <linux/module.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/uaccess.h>

#define MY_CLASS_NAME "cdac_clss"
#define MY_DEV_NAME "cdac_dev"
#define MY_KBUF_SZ (1024)

extern dev_t dev;
extern struct class *dev_class;
extern struct device *cdevice;
extern struct cdev my_cdev;
extern char *kbuf;




int my_open(struct inode *inode, struct file *file);
int my_release(struct inode *inode, struct file *file);
ssize_t my_read(struct file *file, char __user *buf, size_t len, loff_t *off);
ssize_t my_write(struct file *file, const char __user *buf, size_t len, loff_t *off);

#endif
