

/* 
  learn how to create random number in the kernel space. Learn about how to use get_random_bytes()
write an LKM to generate 1000 random number between 100 and -100 and print them is dmesg.


use the knwloede gained above to address this pronblem :

write an LKM that accepts 3 input from user spzce:
  1.Number  of rands (n_rands)
  2. Upper limit of rand (rand_upper)
  3. Lower limit of rand (rand_lower)
  
  and returns n_rands numberbetween rand_lower and rand_upper
  
  example 
  user space can say i want 2000 random number between -100 and +500.
  add kernal space module should be able to returen the same.
  user space will collect these number and add them to a linked list .
  
  display/print the linked list.
  
  user send the all three parameter in kernal run time then kernal loaded the parameter in run time
  
  
  */


#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/random.h>
#include <linux/slab.h>
#include <linux/list.h>
#include <linux/cdev.h>
#include <linux/device.h>



#define DEVICE_NAME "randlist"
#define CLASS_NAME  "randlist_class"

static int n_rands = 1000;
static int rand_upper = 100;
static int rand_lower = -100;

module_param(n_rands, int, S_IRUGO);
module_param(rand_upper, int, S_IRUGO);
module_param(rand_lower, int, S_IRUGO);

struct rand_node {
    int value;
    struct list_head list;
};

static LIST_HEAD(rand_list);

static int major;
static struct class* randlist_class = NULL;
static struct device* randlist_device = NULL;

static int randlist_open(struct inode *inodep, struct file *filep) {
    return 0;
}

static int randlist_release(struct inode *inodep, struct file *filep) {
    return 0;
}

static ssize_t randlist_read(struct file *filep, char *buffer, size_t len, loff_t *offset) {

    static struct list_head *pos = NULL;
    struct rand_node *node;
    int copied = 0;

    if (*offset == 0)
        pos = rand_list.next;
        
    if (pos == &rand_list)
        return 0; 

    while (pos != &rand_list && len >= sizeof(int)) {
        node = list_entry(pos, struct rand_node, list);
        if (copy_to_user(buffer, &node->value, sizeof(int)))
            return -EFAULT;
        buffer += sizeof(int);
        len -= sizeof(int);
        copied += sizeof(int);
        pos = pos->next;
        (*offset) += sizeof(int);
    }
    return copied;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .open = randlist_open,
    .release = randlist_release,
    .read = randlist_read,
};

static int __init randlist_init(void)
{
    int i, rand, mapped, range;
    
    struct rand_node *node;

    range = rand_upper - rand_lower + 1;
    
    if (range <= 0 || n_rands <= 0) {
    
        printk(KERN_ERR "Invalid range or n_rands\n");
        
        return -EINVAL;
    }

    while (!list_empty(&rand_list)) {
    
        node = list_first_entry(&rand_list, struct rand_node, list);
        
        list_del(&node->list);
        
        kfree(node);
    }

    for (i = 0; i < n_rands; i++) {
    
        /* Allocated the Memory */
        node = kmalloc(sizeof(*node), GFP_KERNEL);
        
        if (!node) {
        
            printk(KERN_ERR "Memory allocation failed at %d\n", i);
            
            break;
        }
        
        get_random_bytes(&rand, sizeof(rand));
        
        mapped = ((unsigned int)rand % range) + rand_lower;
        
        node->value = mapped;
        
        INIT_LIST_HEAD(&node->list);
        
        list_add_tail(&node->list, &rand_list);
        
        printk(KERN_INFO "randlist: Generated random number %d: %d\n", i+1, mapped); 
    }

    major = register_chrdev(0, DEVICE_NAME, &fops);
    if (major < 0) {
        printk(KERN_ALERT "Failed to register a major number\n");
        return major;
    }
    randlist_class = class_create(THIS_MODULE, CLASS_NAME);
    
    if (IS_ERR(randlist_class)) {
    
        unregister_chrdev(major, DEVICE_NAME);
        printk(KERN_ALERT "Failed to register device class\n");
        return PTR_ERR(randlist_class);
    }
    randlist_device = device_create(randlist_class, NULL, MKDEV(major, 0), NULL, DEVICE_NAME);
    if (IS_ERR(randlist_device)) {
        class_destroy(randlist_class);
        unregister_chrdev(major, DEVICE_NAME);
        printk(KERN_ALERT "Failed to create the device\n");
        return PTR_ERR(randlist_device);
    }
    printk(KERN_INFO "randlist: Device created. Use parameters n_rands, rand_upper, rand_lower.\n");
    return 0;
}

static void __exit randlist_exit(void)
{
    struct rand_node *node, *tmp;
    int count = 0;

    list_for_each_entry_safe(node, tmp, &rand_list, lisLoading kernel module: sudo insmod randlist.ko n_rands=1000 rand_upper=100 rand_lower=-100
insmod: ERROR: could not load module randlist.ko: No such file or directory
open: No such file or directory
rmmod: ERROR: Module randlist is not currently loaded
t) {
        list_del(&node->list);
        /* Free The Memory */
        kfree(node);
        count++;
    }
    device_destroy(randlist_class, MKDEV(major, 0));
    class_unregister(randlist_class);
    class_destroy(randlist_class);
    unregister_chrdev(major, DEVICE_NAME);
    printk(KERN_INFO "randlist: Freed %d random nodes. Module unloaded.\n", count);
}

module_init(randlist_init);
module_exit(randlist_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("! Random Number !");
