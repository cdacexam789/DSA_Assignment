#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>



struct node {
    int data;
    struct node *next;
};



void append(struct node **head, int value) {

    struct node *new_node = malloc(sizeof(struct node));
    
    if (!new_node) {
        perror("malloc");
        exit(1);
    }
    new_node->data = value;
    
    new_node->next = NULL;
    
    if (*head == NULL) {
        *head = new_node;
    } else {
        struct node *temp = *head;
        
        while (temp->next)
            temp = temp->next;
        temp->next = new_node;
    }
}

void print_list(struct node *head) {

    int i = 1;
    
    while (head) {
    
        printf("%d: %d\n", i++, head->data);
        
        head = head->next;
    }
}

void free_list(struct node *head) {

    struct node *tmp;
    
    while (head) {
    
        tmp = head;
        
        head = head->next;
        
        free(tmp);
    }
}

int main(int argc, char *argv[])
{
    int fd, n_rands, i, *buf;
    
    struct node *head = NULL;

    if (argc != 4) {
        printf("Usage: %s n_rands rand_upper rand_lower\n", argv[0]);
        return 1;
    }
    n_rands = atoi(argv[1]);
    int rand_upper = atoi(argv[2]);
    int rand_lower = atoi(argv[3]);


    char cmd[256];
    snprintf(cmd, sizeof(cmd), "sudo insmod randlist.ko n_rands=%d rand_upper=%d rand_lower=%d", n_rands, rand_upper, rand_lower);
    
    printf("Loading kernel module: %s\n", cmd);
    system(cmd);

    sleep(1);

    fd = open("/dev/randlist", O_RDONLY);
    if (fd < 0) {
        perror("open");
        
        system("sudo rmmod randlist");
        return 1;
    }

    buf = malloc(n_rands * sizeof(int));
    if (!buf) {
        perror("malloc");
        close(fd);
        system("sudo rmmod randlist");
        return 1;
    }

    int bytes_read = read(fd, buf, n_rands * sizeof(int));
    int nums_read = bytes_read / sizeof(int);
    printf("Read %d random numbers from kernel module:\n", nums_read);

    for (i = 0; i < nums_read; i++) {
        append(&head, buf[i]);
    }

    print_list(head);
 
    /* Free The Memory */
    free_list(head);
    free(buf);
    close(fd);

    system("sudo rmmod randlist");

    return 0;
}

