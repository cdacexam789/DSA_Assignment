#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define DEVICE "/dev/numdev"
#define IOCTL_START_TIMER_UP   _IO('a', 1)
#define IOCTL_START_TIMER_DOWN _IO('a', 2)
#define IOCTL_STOP_TIMER       _IO('a', 3)

int main()
{
    int fd, cmd;
    int running = 1;

    fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    while (running) {
        printf("\nCurrent Options:\n");
        printf("1. Start Counting UP\n");
        printf("2. Start Counting DOWN\n");
        printf("3. STOP Counting\n");
        printf("4. Exit Program\n");
        printf("Enter choice");
        
        if (scanf("%d", &cmd) != 1) {
            fprintf(stderr, "Invalid input\n");
            while (getchar() != '\n');
            continue;
        }

        switch (cmd) {
        case 1:
            ioctl(fd, IOCTL_START_TIMER_UP);
            printf("Counting UP\n");
            break;
            
        case 2:
            ioctl(fd, IOCTL_START_TIMER_DOWN);
            printf("Counting DOWN\n");
            break;
            
        case 3:
            ioctl(fd, IOCTL_STOP_TIMER);
            printf("Counting STOPPED\n");
            break;
            
        case 4:
            running = 0;
             return 0;
            break;
            
    
        }

        while (getchar() != '\n'); 
    }

    close(fd);
    
    return 0;
}
