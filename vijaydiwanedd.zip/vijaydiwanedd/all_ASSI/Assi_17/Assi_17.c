/* Implement an LKM that creates a char device with 3 IOCTL :
1.START_TIMER_UP
2.START_TIMER_DOWN
3.STOP_TIMER
 
 for this,connect a 4 LED ladder circuit to the board with the following connection:
 
 MSB : GPIO47 -HW pin P8_15
 MSB-1: GPIO48 - and so on 
 MSB-2: GPIO49
 LSB:   gpio60 
 
 
 START_TIMER_UP should start a kernel timer and display the count on the lEDs:
 0000 -> 0001 -> 0010 -> ...........-> 1111 -> 0000 -> ....and so on 
 
  START_TIMER_DOWN should start a kernel timer and display the count on the lEDs:
1111 -> 1110 -> 1100 -> ...........-> 0000 -> 1111 -> ....and so on 


keep the kernal timer period to 1 second.
Verify your LKM for Kernel Stability.

*/

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/ioctl.h>
#include <linux/gpio.h>
#include <linux/timer.h>

#define DEVICE_NAME "numdev"
#define CLASS_NAME "numdev_class"
#define NUM_LEDS 4
#define TIME_INTVL 1000

/* IOCTL commands */
#define IOCTL_START_TIMER_UP   _IO('a', 1)
#define IOCTL_START_TIMER_DOWN _IO('a', 2)
#define IOCTL_STOP_TIMER       _IO('a', 3)

/* GPIO pins for LEDs (MSB to LSB) */
static int led_gpios[NUM_LEDS] = {47, 48, 49, 60};

static int major;
static struct class *numdev_class = NULL;
static struct cdev numdev_cdev;

/* Timer and state */
static struct timer_list led_timer;
static int timer_active = 0;
static int current_count = 0;
static int count_direction = 1; 

/* Set LEDs according to 4-bit value */
static void update_leds(int value)
{
    int i;
    for (i = 0; i < NUM_LEDS; i++) {
        gpio_set_value(led_gpios[i], (value >> (NUM_LEDS - 1 - i)) & 0x1);
    }
}

/* Timer callback function */
static void timer_callback(struct timer_list *t)
{
    if (!timer_active) return;

   /* Update count based on direction */
    if (count_direction == 1)
    
    // Count up 
        current_count = (current_count + 1) & 0xF; 
    else
    
    // Count down
        current_count = (current_count - 1) & 0xF; 

    update_leds(current_count);
    mod_timer(&led_timer, jiffies + msecs_to_jiffies(TIME_INTVL));
}

/* IOCTL handler */
static long numdev_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    switch (cmd) {
    
    case IOCTL_START_TIMER_UP:
        count_direction = 1;
        if (!timer_active) {
            timer_active = 1;
            mod_timer(&led_timer, jiffies + msecs_to_jiffies(TIME_INTVL));
        }
        pr_info(KERN_INFO "Counting UP from %d\n", current_count);
        break;
        
    case IOCTL_START_TIMER_DOWN:
        count_direction = -1;
        if (!timer_active) {
            timer_active = 1;
            mod_timer(&led_timer, jiffies + msecs_to_jiffies(TIME_INTVL));
        }
        pr_info(KERN_INFO "Counting DOWN from %d\n", current_count);
        break;
        
    case IOCTL_STOP_TIMER:
        timer_active = 0;
        del_timer_sync(&led_timer);
        pr_info(KERN_INFO "Stopped at count %d\n", current_count);
        break;
        
    default:
        return -EINVAL;
    }
    
    return 0;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = numdev_ioctl,
};

static int __init numdev_init(void)
{
    dev_t dev;
    int  i;

    /* Allocate device number */
    if (alloc_chrdev_region(&dev, 0, 1, DEVICE_NAME) < 0)
        return -1;
    major = MAJOR(dev);

    /* Initialize character device */
    cdev_init(&numdev_cdev, &fops);
    if (cdev_add(&numdev_cdev, dev, 1) < 0)
        goto fail_cdev;
    
    /* Create device class */
    numdev_class = class_create(THIS_MODULE, CLASS_NAME);
    if (IS_ERR(numdev_class))
        goto fail_class;

    /* Create device node */
    device_create(numdev_class, NULL, dev, NULL, DEVICE_NAME);

    /* Initialize GPIOs */
    for (i = 0; i < NUM_LEDS; i++) {
        if (gpio_request(led_gpios[i], "led_gpio")) {
            while (--i >= 0) gpio_free(led_gpios[i]);
            goto fail_device;
        }
        gpio_direction_output(led_gpios[i], 0);
    }

    /* Initialize timer */
    timer_setup(&led_timer, timer_callback, 0);
    update_leds(0); 

    pr_info(KERN_INFO "numdev: Ready (Initial count: 0000)\n");
    return 0;

fail_device:
    device_destroy(numdev_class, dev);
fail_class:
    class_destroy(numdev_class);
    cdev_del(&numdev_cdev);
fail_cdev:
    unregister_chrdev_region(dev, 1);
    return -1;
}

static void __exit numdev_exit(void)
{
    dev_t dev = MKDEV(major, 0);
    int i;

    /* Cleanup */
    timer_active = 0;
    del_timer_sync(&led_timer);

    /* Turn off LEDs and free GPIOs */
    for (i = 0; i < NUM_LEDS; i++) {
        gpio_set_value(led_gpios[i], 0);
        gpio_free(led_gpios[i]);
    }
    
    device_destroy(numdev_class, dev);
    class_destroy(numdev_class);
    cdev_del(&numdev_cdev);
    unregister_chrdev_region(dev, 1);
    
    pr_info(KERN_INFO "numdev: Removed\n");
}

module_init(numdev_init);
module_exit(numdev_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("LED Counter with Direction Control");
