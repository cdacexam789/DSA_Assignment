/* set up an led and a switch on 2 seprate  pins 
on bbb configure GPIOS for ecah - led output , switch input   

write a LKM such that the LED glows only when the switch is pressed 
 
 /*
 
 /* Interrupt handling using GPIO */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/gpio.h>
#include <linux/interrupt.h>
#include <linux/init.h>



#define LED_GPIO      60   
#define SWITCH_GPIO   46   

static unsigned int irqNumber;

static irqreturn_t switch_irq_handler(int irq, void *dev_id)
{
    int switch_state = gpio_get_value(SWITCH_GPIO);
    
    if (switch_state) {
        gpio_set_value(LED_GPIO, 1); // LED ON
    } 
   
   /* 
    else {
        gpio_set_value(LED_GPIO, 0); // LED OFF
    }
    
    */
    return IRQ_HANDLED;
}



static int __init led_switch_init(void)
{
    int result;

    // Request LED GPIO
    result = gpio_request(LED_GPIO, "LED_GPIO");
    if (result) {
        pr_err("Failed to request LED GPIO %d\n", LED_GPIO);
        return result;
    }
    result = gpio_direction_output(LED_GPIO, 0); 
    if (result) {
        pr_err("Failed to set LED GPIO %d as output\n", LED_GPIO);
        gpio_free(LED_GPIO);
        return result;
    }

 
    result = gpio_request(SWITCH_GPIO, "SWITCH_GPIO");
    if (result) {
        pr_err("Failed to request SWITCH GPIO %d\n", SWITCH_GPIO);
        gpio_free(LED_GPIO);
        return result;
    }
    result = gpio_direction_input(SWITCH_GPIO);
    if (result) {
        pr_err("Failed to set SWITCH GPIO %d as input\n", SWITCH_GPIO);
        gpio_free(LED_GPIO);
        gpio_free(SWITCH_GPIO);
        return result;
    }


    irqNumber = gpio_to_irq(SWITCH_GPIO);
    if (irqNumber < 0) {
        pr_err("Failed to get IRQ number for GPIO %d\n", SWITCH_GPIO);
        gpio_free(LED_GPIO);
        gpio_free(SWITCH_GPIO);
        return irqNumber;
    }

    result = request_irq(irqNumber,
                         (irq_handler_t) switch_irq_handler,
                         IRQF_TRIGGER_RISING | IRQF_TRIGGER_FALLING,
                         "switch_gpio_handler",
                         NULL);
    if (result) {
        pr_err("Failed to request IRQ %d\n", irqNumber);
        gpio_free(LED_GPIO);
        gpio_free(SWITCH_GPIO);
        return result;
    }

    pr_info("LED/Switch LKM loaded: \n", LED_GPIO, SWITCH_GPIO, irqNumber);
    return 0;
}

static void __exit led_switch_exit(void)
{
    gpio_set_value(LED_GPIO, 0); // Ensure LED is OFF
    free_irq(irqNumber, NULL);
    gpio_free(LED_GPIO);
    gpio_free(SWITCH_GPIO);
    pr_info("LED/Switch LKM unloaded\n");
}

module_init(led_switch_init);
module_exit(led_switch_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("CDAC EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("A simple interrupt driver using GPIO button");
