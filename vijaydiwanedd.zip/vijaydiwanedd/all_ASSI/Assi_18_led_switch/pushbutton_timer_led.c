
/* set up an led and a switch on 2 seprate  pins 
on bbb configure GPIOS for ecah - led output , switch input   

write a LKM such that the LED glows only when the switch is pressed 
 
 /*
 
 /* Interrupt handling using GPIO */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/gpio.h>
#include <linux/interrupt.h>
#include <linux/init.h>
#include <linux/timer.h>

#define DELAY 1000

#define LED_GPIO      60   
#define SWITCH_GPIO   46   

static unsigned int irqNumber;
static struct timer_list led_timer;
static int led_flash = 0;     
static int led_state = 0;      


static void led_timer_callback(struct timer_list *t)
{
    if (led_flash) {
        led_state = !led_state;
        gpio_set_value(LED_GPIO, led_state);
        mod_timer(&led_timer, jiffies + msecs_to_jiffies(DELAY));
        
    } else {
    
        gpio_set_value(LED_GPIO, 0); 
    }
}


static irqreturn_t switch_irq_handler(int irq, void *dev_id)
{
    int switch_state = gpio_get_value(SWITCH_GPIO);

    if (switch_state) { 
    
        led_flash = !led_flash;
        
        if (led_flash) {
            led_state = 1;
            gpio_set_value(LED_GPIO, led_state);
            mod_timer(&led_timer, jiffies + msecs_to_jiffies(DELAY)); 
            
        } else {
        
            del_timer(&led_timer);
            gpio_set_value(LED_GPIO, 0); 
            led_state = 0;
        }
    }
    return IRQ_HANDLED;
}

static int __init led_switch_init(void)
{
    int result;

    result = gpio_request(LED_GPIO, "LED_GPIO");
    if (result) return result;
    result = gpio_direction_output(LED_GPIO, 0);
    if (result) { gpio_free(LED_GPIO); return result; }

    result = gpio_request(SWITCH_GPIO, "SWITCH_GPIO");
    if (result) { gpio_free(LED_GPIO); return result; }
    result = gpio_direction_input(SWITCH_GPIO);
    if (result) { gpio_free(LED_GPIO); gpio_free(SWITCH_GPIO); return result; }

    irqNumber = gpio_to_irq(SWITCH_GPIO);
    if (irqNumber < 0) { gpio_free(LED_GPIO); gpio_free(SWITCH_GPIO); return irqNumber; }

    result = request_irq(irqNumber,
                         (irq_handler_t)switch_irq_handler,
                         IRQF_TRIGGER_RISING | IRQF_TRIGGER_FALLING,
                         "switch_gpio_handler",
                         NULL);
    if (result) { gpio_free(LED_GPIO); gpio_free(SWITCH_GPIO); return result; }

    timer_setup(&led_timer, led_timer_callback, 0);

    pr_info("LED/Switch LKM loaded\n");
    return 0;
}

static void __exit led_switch_exit(void)
{
    del_timer_sync(&led_timer);
    gpio_set_value(LED_GPIO, 0);
    free_irq(irqNumber, NULL);
    gpio_free(LED_GPIO);
    gpio_free(SWITCH_GPIO);
    pr_info("LED/Switch LKM unloaded\n");
}

module_init(led_switch_init);
module_exit(led_switch_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("CDAC EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("Interrupt-driven LED flasher using GPIO button and timer");

