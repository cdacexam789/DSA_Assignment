/* write an LKM that create a directory "cdac_sys" in the /sys directory .
create  an integer/file "cdac_int" in this directory.
define show and store functions and verify if they work from user space. */

#define pr_fmt(fmt)	KBUILD_MODNAME ": " fmt

#include <linux/module.h>
#include <linux/init.h>
#include <linux/sysfs.h>
#include <linux/kobject.h>
#include <linux/string.h>

#define SYSFS_DIR   "cdac_sys"
#define SYSFS_FILE  "cdac_int"

static int cdac_int = 0;
static struct kobject *cdac_kobj;

static ssize_t cdac_int_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
    pr_info("sysfs: read cdac_int = %d\n", cdac_int);
    return sprintf(buf, "%d\n", cdac_int);
}


static ssize_t cdac_int_store(struct kobject *kobj, struct kobj_attribute *attr, const char *buf, size_t count)
{
    int temp;
    if (sscanf(buf, "%d", &temp) == 1) {
        cdac_int = temp;
        pr_info("sysfs: write cdac_int = %d\n", cdac_int);
    } else {
        pr_info("sysfs: invalid input\n");
    }
    return count;
}


static struct kobj_attribute cdac_int_attr = __ATTR(cdac_int, 0660, cdac_int_show, cdac_int_store);

static int __init cdac_sys_init(void)
{
    int retval;

    cdac_kobj = kobject_create_and_add(SYSFS_DIR, NULL); 
    if (!cdac_kobj) {
        pr_err("Cannot create /sys/%s\n", SYSFS_DIR);
        return -ENOMEM;
    }

   /* Create /sys/cdac_sys/cdac_int */
    retval = sysfs_create_file(cdac_kobj, &cdac_int_attr.attr);
    if (retval) {
        pr_err("Cannot create /sys/%s/%s\n", SYSFS_DIR, SYSFS_FILE);
        kobject_put(cdac_kobj);
        return retval;
    }

    pr_info("cdac_sys module loaded: /sys/%s/%s created\n", SYSFS_DIR, SYSFS_FILE);
    return 0;
}

static void __exit cdac_sys_exit(void)
{
    sysfs_remove_file(cdac_kobj, &cdac_int_attr.attr);
    kobject_put(cdac_kobj);
    pr_info("cdac_sys module unloaded: /sys/%s/%s removed\n", SYSFS_DIR, SYSFS_FILE);
}

module_init(cdac_sys_init);
module_exit(cdac_sys_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("Directries and file entries in /sys (sysfs)");

