/* valgrind --leak-check=full ./a.out */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>  

#define DEVICE "/dev/cdac_dev"

struct employee {
    char name[10];
    int id;
    char gender;
};


#define MAGIC_NUM 0xF0
#define SEND_EMPLOYEE_DATA _IOW(MAGIC_NUM, 1, struct employee)
#define GET_LIST_SIZE      _IOR(MAGIC_NUM, 2, int)
#define PRINT_LIST         _IO(MAGIC_NUM, 3)

void send_employee(int fd) {
    struct employee emp;

    printf("Enter name : ");
    scanf("%9s", emp.name);

    printf("Enter ID: ");
    scanf("%d", &emp.id);

    printf("Enter gender (m/f): ");
    scanf(" %c", &emp.gender);

    if (ioctl(fd, SEND_EMPLOYEE_DATA, &emp) < 0) {
        perror("SEND_EMPLOYEE_DATA ioctl failed");
    } else {
        printf("Employee sent: %s, %d, %c\n", emp.name, emp.id, emp.gender);
    }
}

int main() {
    int fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("Failed to open device");
        return 1;
    }

    int choice;
    do {
        printf("\n1. Add Employee\n2. Get List Size\n3. Print List\n4. Exit\nChoice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                send_employee(fd);
                break;
            case 2: {
                int size = 0;
                if (ioctl(fd, GET_LIST_SIZE, &size) == 0) {
                    printf("Current list size: %d\n", size);
                } else {
                    perror("GET_LIST_SIZE ioctl failed");
                }
                break;
            }
            case 3:
                if (ioctl(fd, PRINT_LIST) < 0)
                    perror("PRINT_LIST ioctl failed");
                else
                    printf("List printed in dmesg.\n");
                break;
            case 4:
                break;
            default:
                printf("Invalid choice\n");
        }
    } while (choice != 4);

    close(fd);
    return 0;
}

