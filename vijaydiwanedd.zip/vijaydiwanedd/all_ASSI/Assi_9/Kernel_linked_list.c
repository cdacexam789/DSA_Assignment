/*Create an LKM with support for creating a device (/dev/cdac_dev) and a kernal linked list and support for user_space interaction.
The user space application should create an employee record filled with:
1.Employee name -string char[10];
2.Employee ID - int
3. Employee gender - char ('m'/'f')
and send it to the kernel device through an IOCTL SEND_EMPLOYEE_DATA.
The device driver should add the record to sent to an ever increasing kernel linked list.

also implement 2 more IOCTLS:
1 . GET_LIST_SIZE that should return size of the kernel linked list
2 . PRINT_LIST that should print the contents of the kernel linked list in dmesg.

check  for kernel stability.

Start with 10 employees */


#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/uaccess.h>
#include <linux/device.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/list.h>
#include <linux/mutex.h>
#include <linux/ioctl.h>




#define DEVICE_NAME "cdac_dev"
#define CLASS_NAME  "cdac_class"


/* unique identifier */
#define MAGIC_NUM 0xF0
/* write operation */
#define SEND_EMPLOYEE_DATA _IOW(MAGIC_NUM, 1, struct employee)
/* Read operation */
#define GET_LIST_SIZE      _IOR(MAGIC_NUM, 2, int)
/* Total List operation */
#define PRINT_LIST         _IO(MAGIC_NUM, 3)


/* Struct for Employee */
struct employee {
    char name[10];
    int id;
    char gender; 
};

/* Struct Node */
struct emp_node {
    struct employee emp;
    struct list_head list;
};

int major;
struct class*  cdac_class  = NULL;
struct device* cdac_device = NULL;
struct cdev cdev;

LIST_HEAD(emp_list);
DEFINE_MUTEX(emp_mutex);


long cdac_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    struct emp_node *node;
    int count = 0;
    int ret = 0;

    switch(cmd) {
      
        case SEND_EMPLOYEE_DATA: {
            /* Case For Write the Employee Data */
            struct employee user_emp;
            struct emp_node *new_node;

            if (copy_from_user(&user_emp, (void __user *)arg, sizeof(struct employee)))
                return -EFAULT;

      
            if (user_emp.gender != 'm' && user_emp.gender != 'f')
                return -EINVAL;

       
            user_emp.name[sizeof(user_emp.name) - 1] = '\0';

            new_node = kmalloc(sizeof(struct emp_node), GFP_KERNEL);
            if (!new_node)
                return -ENOMEM;

            memcpy(&new_node->emp, &user_emp, sizeof(struct employee));
            INIT_LIST_HEAD(&new_node->list);

            mutex_lock(&emp_mutex);
            list_add_tail(&new_node->list, &emp_list);
            mutex_unlock(&emp_mutex);

            printk(KERN_INFO "cdac_dev: Added Employee: Name=%s, ID=%d, Gender=%c\n",
                user_emp.name, user_emp.id, user_emp.gender);
            break;
        }

        case GET_LIST_SIZE: {
        
            mutex_lock(&emp_mutex);
            list_for_each_entry(node, &emp_list, list)
            count++;
            mutex_unlock(&emp_mutex);

            if (copy_to_user((int __user *)arg, &count, sizeof(int)))
                return -EFAULT;
            break;
        }

        case PRINT_LIST: {
        
            mutex_lock(&emp_mutex);
             list_for_each_entry(node, &emp_list, list) {
             printk(KERN_INFO "cdac_dev: Employee: Name=%s, ID=%d, Gender=%c\n",
             node->emp.name, node->emp.id, node->emp.gender);
            }
            mutex_unlock(&emp_mutex);
            break;
        }

      
    }
    return ret;
}


struct file_operations fops = {
    .owner          = THIS_MODULE,
    .unlocked_ioctl = cdac_ioctl,
};


void cleanup_list(void)
{
    struct emp_node *node, *tmp;
    mutex_lock(&emp_mutex);
    list_for_each_entry_safe(node, tmp, &emp_list, list) {
        list_del(&node->list);
        kfree(node);
    }
    mutex_unlock(&emp_mutex);
}


int __init cdac_init(void)
{
    dev_t dev;
    int ret;

    mutex_init(&emp_mutex);

    ret = alloc_chrdev_region(&dev, 0, 1, DEVICE_NAME);
    if (ret < 0)
        return ret;
    major = MAJOR(dev);

    cdev_init(&cdev, &fops);
    cdev.owner = THIS_MODULE;
    ret = cdev_add(&cdev, dev, 1);
    if (ret)
        goto unregister;

    cdac_class = class_create(THIS_MODULE, CLASS_NAME);
    if (IS_ERR(cdac_class)) {
        ret = PTR_ERR(cdac_class);
        goto del_cdev;
    }

    cdac_device = device_create(cdac_class, NULL, dev, NULL, DEVICE_NAME);
    if (IS_ERR(cdac_device)) {
        ret = PTR_ERR(cdac_device);
        goto destroy_class;
    }

    printk(KERN_INFO "cdac_dev: Module loaded, device created. Waiting for user-space employee data.\n");
    return 0;

destroy_class:
    class_destroy(cdac_class);
del_cdev:
    cdev_del(&cdev);
unregister:
    unregister_chrdev_region(dev, 1);
    return ret;
}


void __exit cdac_exit(void)
{
    dev_t dev = MKDEV(major, 0);
    cleanup_list();
    device_destroy(cdac_class, dev);
    class_destroy(cdac_class);
    cdev_del(&cdev);
    unregister_chrdev_region(dev, 1);
    printk(KERN_INFO " !Thank You So Much! \n");
    printk(KERN_INFO "cdac_dev: Module unloaded.\n");
  
}

module_init(cdac_init);
module_exit(cdac_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("Kernel linked list - dynamic nodes!");

