#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <errno.h>

#define DEVICE "/dev/numdev"
#define IOCTL_SEND_INT _IOW('a', 1, unsigned int)

int main()
{
    int fd;
    unsigned int num;

    printf("Enter an unsigned integer 0-15: ");
    if (scanf("%u", &num) != 1) {
        fprintf(stderr, "Invalid input.\n");
        return 1;
    }

    fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    if (ioctl(fd, IOCTL_SEND_INT, &num) < 0) {
        if (errno == EINVAL)
            fprintf(stderr, "Undefined value: value must be <= 15\n");
        else
            perror("ioctl");
        close(fd);
        return 1;
    }

    printf("Sent %u to kernel module.\n", num);
    close(fd);
    return 0;
}

