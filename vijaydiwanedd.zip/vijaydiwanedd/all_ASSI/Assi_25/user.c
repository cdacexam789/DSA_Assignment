#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>


struct node {
    int data;
    struct node *next;
};



void display_menu() {
    printf("\nMenu:\n");
    printf("1. Load default parameters (1000 numbers between -100 and 100)\n");
    printf("2. Load custom parameters\n");
    printf("3. Display current random numbers\n");
    printf("4. Exit\n");
    printf("Enter your choice: ");
}

void append(struct node **head, int value) {
    struct node *new_node = malloc(sizeof(struct node));
    
    if (!new_node) {
        perror("malloc");
        exit(1);
    }
    new_node->data = value;
    new_node->next = NULL;
    
    if (*head == NULL) {
        *head = new_node;
    } else {
        struct node *temp = *head;
        while (temp->next)
            temp = temp->next;
        temp->next = new_node;
    }
}

void print_list(struct node *head) {

    int i = 1;
    
    while (head) {
        printf("%d: %d\n", i++, head->data);
        head = head->next;
    }
}

void free_list(struct node *head) {
    struct node *tmp;
    
    while (head) {
        tmp = head;
        head = head->next;
        free(tmp);
    }
}

void load_kernel_module(int n_rands, int rand_upper, int rand_lower) {
    char cmd[256];
    
    snprintf(cmd, sizeof(cmd), "sudo insmod random_number.ko n_rands=%d rand_upper=%d rand_lower=%d", 
             n_rands, rand_upper, rand_lower);
    printf("Loading kernel module: %s\n", cmd);
    system(cmd);
    sleep(1); 
}

void read_random_numbers(int n_rands, struct node **head) {
    int fd = open("/dev/rand", O_RDONLY);
    if (fd < 0) {
        perror("open");
        system("sudo rmmod randlist");
        exit(1);
    }

    int *buf = malloc(n_rands * sizeof(int));
    if (!buf) {
        perror("malloc");
        close(fd);
        system("sudo rmmod randlist");
        exit(1);
    }

    int bytes_read = read(fd, buf, n_rands * sizeof(int));
    int nums_read = bytes_read / sizeof(int);
    printf("Read %d random numbers from kernel module:\n", nums_read);

    for (int i = 0; i < nums_read; i++) {
        append(head, buf[i]);
    }

    free(buf);
    close(fd);
}



int main() {

    int choice;
    int n_rands = 1000;
    int rand_upper = 100;
    int rand_lower = -100;
    
    struct node *head = NULL;
    int module_loaded = 0;

    while (1) {
    
        display_menu();
        scanf("%d", &choice);
        
        switch (choice) {
        
            case 1: 
            
                n_rands = 1000;
                rand_upper = 100;
                rand_lower = -100;
                
                if (module_loaded) {
                    system("sudo rmmod randlist");
                }
                
                load_kernel_module(n_rands, rand_upper, rand_lower);
                module_loaded = 1;
                
              
                if (head) {
                    free_list(head);
                    head = NULL;
                }
                
                read_random_numbers(n_rands, &head);
                printf("Loaded default parameters\n");
                break;
                
            case 2: 
                printf("Enter number of random numbers: ");
                scanf("%d", &n_rands);
                printf("Enter upper limit: ");
                scanf("%d", &rand_upper);
                printf("Enter lower limit: ");
                scanf("%d", &rand_lower);
                
                if (module_loaded) {
                    system("sudo rmmod randlist");
                }
                load_kernel_module(n_rands, rand_upper, rand_lower);
                module_loaded = 1;
                
         
                if (head) {
                    free_list(head);
                    head = NULL;
                }
                
                read_random_numbers(n_rands, &head);
                printf("Loaded custom parameters\n");
                break;
                
            case 3: // Display numbers
                if (!head) {
                    printf("No random numbers loaded. Please load them first.\n");
                } else {
                    print_list(head);
                }
                break;
                
            case 4: // Exit
                if (module_loaded) {
                    system("sudo rmmod randlist");
                }
                if (head) {
                    free_list(head);
                }
               
                printf("Exiting...\n");
                return 0;
                
      
        }
    }

    return 0;
}
