#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/random.h>
#include <linux/slab.h>
#include <linux/list.h>
#include <linux/cdev.h>
#include <linux/device.h>

#define DEVICE_NAME "rand"
#define CLASS_NAME  "rand_class"

static int n_rands = 1000;
static int rand_upper = 100;
static int rand_lower = -100;

module_param(n_rands, int, S_IRUGO);
module_param(rand_upper, int, S_IRUGO);
module_param(rand_lower, int, S_IRUGO);

MODULE_PARM_DESC(n_rands, "Number of random numbers to generate");
MODULE_PARM_DESC(rand_upper, "Upper bound of random numbers");
MODULE_PARM_DESC(rand_lower, "Lower bound of random numbers");

struct rand_node {
    int value;
    struct list_head list;
};

static LIST_HEAD(rand_list);
static DEFINE_MUTEX(rand_list_mutex);

static int major;
static struct class* randlist_class = NULL;
static struct device* randlist_device = NULL;
static struct cdev randlist_cdev;

static int randlist_open(struct inode *inodep, struct file *filep) {
    return 0;
}

static int randlist_release(struct inode *inodep, struct file *filep) {
    return 0;
}

static ssize_t randlist_read(struct file *filep, char *buffer, size_t len, loff_t *offset) {
    struct rand_node *node;
    int value;
    ssize_t retval = 0;
    size_t bytes_copied = 0;

    mutex_lock(&rand_list_mutex);

    if (list_empty(&rand_list)) {
        mutex_unlock(&rand_list_mutex);
        return 0;
    }

    node = list_first_entry(&rand_list, struct rand_node, list);
    
    while (bytes_copied + sizeof(int) <= len && !list_is_last(&node->list, &rand_list)) {
        value = node->value;
        if (copy_to_user(buffer + bytes_copied, &value, sizeof(int))) {
            mutex_unlock(&rand_list_mutex);
            return -EFAULT;
        }
        bytes_copied += sizeof(int);
        node = list_next_entry(node, list);
    }

    *offset += bytes_copied;
    retval = bytes_copied;

    mutex_unlock(&rand_list_mutex);
    return retval;
}

static const struct file_operations fops = {
    .owner = THIS_MODULE,
    .open = randlist_open,
    .release = randlist_release,
    .read = randlist_read,
};

static void cleanup_rand_list(void) {
    struct rand_node *node, *tmp;
    int count = 0;

    mutex_lock(&rand_list_mutex);
    list_for_each_entry_safe(node, tmp, &rand_list, list) {
        list_del(&node->list);
        kfree(node);
        count++;
    }
    mutex_unlock(&rand_list_mutex);
    printk(KERN_INFO "randlist: Freed %d random nodes\n", count);
}

static int __init randlist_init(void) {
    int i, rand, mapped, range;
    struct rand_node *node;
    dev_t dev = 0;
    int ret;

    printk(KERN_INFO "randlist: Initializing with n_rands=%d, range=%d to %d\n",
           n_rands, rand_lower, rand_upper);

    range = rand_upper - rand_lower + 1;
    if (range <= 0 || n_rands <= 0) {
        printk(KERN_ERR "randlist: Invalid range (%d) or n_rands (%d)\n", range, n_rands);
        return -EINVAL;
    }

    cleanup_rand_list();


    for (i = 0; i < n_rands; i++) {
        node = kmalloc(sizeof(*node), GFP_KERNEL);
        if (!node) {
            printk(KERN_ERR "randlist: Memory allocation failed at %d\n", i);
            ret = -ENOMEM;
            goto fail;
        }

        get_random_bytes(&rand, sizeof(rand));
        mapped = ((unsigned int)rand % range) + rand_lower;
        node->value = mapped;
        
        mutex_lock(&rand_list_mutex);
        list_add_tail(&node->list, &rand_list);
        mutex_unlock(&rand_list_mutex);

        printk(KERN_DEBUG "randlist: Generated random number %d: %d\n", i+1, mapped);
    }

    ret = alloc_chrdev_region(&dev, 0, 1, DEVICE_NAME);
    if (ret < 0) {
        printk(KERN_ERR "randlist: Failed to allocate char device region\n");
        goto fail;
    }
    major = MAJOR(dev);

    cdev_init(&randlist_cdev, &fops);
    randlist_cdev.owner = THIS_MODULE;
    ret = cdev_add(&randlist_cdev, dev, 1);
    if (ret < 0) {
        printk(KERN_ERR "randlist: Failed to add cdev\n");
        goto fail_cdev;
    }

    randlist_class = class_create(THIS_MODULE, CLASS_NAME);
    if (IS_ERR(randlist_class)) {
        ret = PTR_ERR(randlist_class);
        printk(KERN_ERR "randlist: Failed to create class\n");
        goto fail_class;
    }


    randlist_device = device_create(randlist_class, NULL, dev, NULL, DEVICE_NAME);
    if (IS_ERR(randlist_device)) {
        ret = PTR_ERR(randlist_device);
        printk(KERN_ERR "randlist: Failed to create device\n");
        goto fail_device;
    }

    printk(KERN_INFO "randlist: Device created successfully\n");
    return 0;

fail_device:
    class_destroy(randlist_class);
fail_class:
    cdev_del(&randlist_cdev);
fail_cdev:
    unregister_chrdev_region(dev, 1);
fail:
    cleanup_rand_list();
    return ret;
}

static void __exit randlist_exit(void) {
    dev_t dev = MKDEV(major, 0);

    if (randlist_device)
        device_destroy(randlist_class, dev);
    if (randlist_class)
        class_destroy(randlist_class);
    cdev_del(&randlist_cdev);
    unregister_chrdev_region(dev, 1);

    cleanup_rand_list();

    printk(KERN_INFO "randlist: Module unloaded\n");
}

module_init(randlist_init);
module_exit(randlist_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("! Random Number !");
