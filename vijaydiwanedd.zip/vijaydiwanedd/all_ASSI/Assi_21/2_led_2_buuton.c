/* set up 2 LED  and 2 switches 4  seprate pins on bbb
configure GPIOS for each  LED  as output , switch as input 

write a LKM that accrepts switch press as an input IRQ

pressing switch1 should start  flashing LED1
pressing Switch2 should start flashing LED2 

time-period of LED1 flashing should be changeable by module parametre 
(uint)  FLASH_LED1 (defgault 1 second )

time perid of LED2  flashing  should be  changeable  by module parameter (unit) FLASH_LED2  (default 1 second )

verify all hardware works ensuring kernal stability.
change the FLASH _LEDx values and verify that LEDs flash interval changes accordingly */

//make sudo insmod your_module.ko FLASH_LED1=500 FLASH_LED2=2000


#define pr_fmt(fmt)	KBUILD_MODNAME ": " fmt

#include <linux/init.h>
#include <linux/module.h>
#include <linux/gpio.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/moduleparam.h>
#include <linux/delay.h>



static unsigned int gpioLED1    = 47;  
static unsigned int gpioLED2    = 48;  
static unsigned int gpioSW1     = 46;  
static unsigned int gpioSW2     = 26; 

static unsigned int irqSW1;
static unsigned int irqSW2;


static unsigned int FLASH_LED1 = 1000;
static unsigned int FLASH_LED2 = 1000;

module_param(FLASH_LED1, uint, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(FLASH_LED1, "LED1 flash interval in ms 1000");
module_param(FLASH_LED2, uint, S_IRUGO | S_IWUSR);
MODULE_PARM_DESC(FLASH_LED2, "LED2 flash interval in ms 1000");

static struct timer_list timerLED1;
static struct timer_list timerLED2;

static int led1_flashing = 0;
static int led2_flashing = 0;
static int led1_state = 0;
static int led2_state = 0;

static void led1_timer_func(struct timer_list *t)
{
    if (!led1_flashing) return;
    led1_state = !led1_state;
    gpio_set_value(gpioLED1, led1_state);
    mod_timer(&timerLED1, jiffies + msecs_to_jiffies(FLASH_LED1));
}

static void led2_timer_func(struct timer_list *t)
{
    if (!led2_flashing) return;
    led2_state = !led2_state;
    gpio_set_value(gpioLED2, led2_state);
    mod_timer(&timerLED2, jiffies + msecs_to_jiffies(FLASH_LED2));
}


static irqreturn_t sw1_irq_handler(int irq, void *dev_id)
{
    pr_info("Switch 1 pressed! LED1 flashing.\n");
    
    if (!led1_flashing) {
        led1_flashing = 1;
        led1_state = 0;
        gpio_set_value(gpioLED1, led1_state);
        mod_timer(&timerLED1, jiffies + msecs_to_jiffies(FLASH_LED1));
    }
    return IRQ_HANDLED;
}

static irqreturn_t sw2_irq_handler(int irq, void *dev_id)
{
    pr_info("Switch 2 pressed! LED2 flashing.\n");
    
    if (!led2_flashing) {
        led2_flashing = 1;
        led2_state = 0;
        gpio_set_value(gpioLED2, led2_state);
        mod_timer(&timerLED2, jiffies + msecs_to_jiffies(FLASH_LED2));
    }
    return IRQ_HANDLED;
}

static int __init my_init(void)
{
    int result = 0;

    pr_info("Initializing 2 LED, 2 Switch module\n");

    if (!gpio_is_valid(gpioLED1) || !gpio_is_valid(gpioLED2) ||
        !gpio_is_valid(gpioSW1)  || !gpio_is_valid(gpioSW2)) {
        pr_err("Invalid GPIO(s)!\n");
        return -ENODEV;
    }

    gpio_request(gpioLED1, "LED1");
    gpio_direction_output(gpioLED1, 0);
    gpio_export(gpioLED1, false);

    gpio_request(gpioLED2, "LED2");
    gpio_direction_output(gpioLED2, 0);
    gpio_export(gpioLED2, false);

    gpio_request(gpioSW1, "SW1");
    gpio_direction_input(gpioSW1);
    gpio_export(gpioSW1, false);

    gpio_request(gpioSW2, "SW2");
    gpio_direction_input(gpioSW2);
    gpio_export(gpioSW2, false);

    timer_setup(&timerLED1, led1_timer_func, 0);
    timer_setup(&timerLED2, led2_timer_func, 0);

    irqSW1 = gpio_to_irq(gpioSW1);
    irqSW2 = gpio_to_irq(gpioSW2);

    result = request_irq(irqSW1, sw1_irq_handler, IRQF_TRIGGER_RISING, "sw1_irq", NULL);
    if (result) {
        pr_err("Unable to request IRQ for SW1\n");
        goto fail_sw1;
    }

    result = request_irq(irqSW2, sw2_irq_handler, IRQF_TRIGGER_RISING, "sw2_irq", NULL);
    if (result) {
        pr_err("Unable to request IRQ for SW2\n");
        goto fail_sw2;
    }

    pr_info("Module loaded successfully\n");
    return 0;

fail_sw2:
    free_irq(irqSW1, NULL);
fail_sw1:
    gpio_unexport(gpioLED1); gpio_free(gpioLED1);
    gpio_unexport(gpioLED2); gpio_free(gpioLED2);
    gpio_unexport(gpioSW1);  gpio_free(gpioSW1);
    gpio_unexport(gpioSW2);  gpio_free(gpioSW2);
    return result;
}

static void __exit my_exit(void)
{
    del_timer_sync(&timerLED1);
    del_timer_sync(&timerLED2);

    free_irq(irqSW1, NULL);
    free_irq(irqSW2, NULL);

    gpio_set_value(gpioLED1, 0);
    gpio_set_value(gpioLED2, 0);

    gpio_unexport(gpioLED1); gpio_free(gpioLED1);
    gpio_unexport(gpioLED2); gpio_free(gpioLED2);
    gpio_unexport(gpioSW1);  gpio_free(gpioSW1);
    gpio_unexport(gpioSW2);  gpio_free(gpioSW2);

    pr_info("Module unloaded, LEDs and GPIOs cleaned up\n");
}

module_init(my_init);
module_exit(my_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("CDAC EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("2_LED_2_BUTTON               ");
