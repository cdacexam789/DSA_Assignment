
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>

#define MY_MAGIC 'a'
#define START_TIMER _IO(MY_MAGIC, 1)
#define STOP_TIMER _IO(MY_MAGIC, 2)

int main(int argc, char *argv[])
{
    int fd;
    char choice;
    
    fd = open("/dev/my_dev", O_RDWR);
    if (fd < 0) {
        perror("Failed to open device");
        return EXIT_FAILURE;
    }
    
    printf("Menu:\n");
    printf("1. Start timer\n");
    printf("2. Stop timer\n");
    printf("3. Exit\n");
    
    while (1) {
        printf("Enter choice: ");
        scanf(" %c", &choice);
        
        switch (choice) {
            case '1':
                if (ioctl(fd, START_TIMER)){
                    perror("START_TIMER failed");
                } else {
                    printf("Timer started\n");
                }
                break;
                
            case '2':
                if (ioctl(fd, STOP_TIMER)) {
                    perror("STOP_TIMER failed");
                } else {
                    printf("Timer stopped\n");
                }
                break;
                
            case '3':
                close(fd);
                return EXIT_SUCCESS;
                
            default:
                printf("Invalid choice\n");
        }
    }
    
    close(fd);
    return EXIT_SUCCESS;
}
