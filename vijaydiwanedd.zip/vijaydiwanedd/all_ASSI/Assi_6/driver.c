/*create an LMK to create a deveice "my_dev and a cleass "my_cls".
this device should support 2 IOCTLS:
1. START_TIMERE -device driver should start and internal kernel timer
2. STOP_TIMER - Device driver should stop the timer (only if it was started )

also create a user -spce application to test these IOCTLs.

you can use eithier regular or HR timer for this purpose.
time period for the periodic timer is 1 sec.
*/


#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/err.h>
#include <linux/device.h>
#include <linux/kdev_t.h>
#include <linux/cdev.h>
#include <linux/ioctl.h>
#include <linux/timer.h>
#include <linux/jiffies.h>

#define MY_CLASS_NAME "my_cls"
#define MY_DEV_NAME "my_dev"

#define MY_MAGIC 'a'
#define START_TIMER _IO(MY_MAGIC, 1)
#define STOP_TIMER _IO(MY_MAGIC, 2)

dev_t dev = 0;
static struct class *dev_class;
static struct device *cdevice;
static struct cdev my_cdev;
static struct timer_list my_timer;
static bool timer_running = false;

static void timer_callback(struct timer_list *t)
{
    pr_info("Timer callback called (%ld)\n", jiffies);
    
    // Reschedule the timer if still running
    if (timer_running) {
        mod_timer(&my_timer, jiffies + msecs_to_jiffies(1000));
    }
}

static int my_open(struct inode *inode, struct file *file)
{
    pr_info("Device opened\n");
    return 0;
}

static ssize_t my_read(struct file *file, char __user *buf, size_t len, loff_t *off)
{
    pr_info("Read operation\n");
    return 0;
}

static ssize_t my_write(struct file *file, const char __user *buf, size_t len, loff_t *off)
{
    pr_info("Write operation\n");
    return len;
}

static long my_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    switch(cmd) {
        case START_TIMER:
            if (!timer_running) {
                pr_info("Starting timer\n");
                timer_running = true;
                mod_timer(&my_timer, jiffies + msecs_to_jiffies(1000));
            } else {
                pr_info("Timer already running\n");
            }
            break;
            
        case STOP_TIMER:
            if (timer_running) {
                pr_info("Stopping timer\n");
                timer_running = false;
                del_timer(&my_timer);
            } else {
                pr_info("Timer not running\n");
            }
            break;
            
        default:
            pr_err("Unknown IOCTL command\n");
            return -ENOTTY;
    }
    return 0;
}

static int my_release(struct inode *inode, struct file *file)
{
    pr_info("Device closed\n");
    return 0;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .open = my_open,
    .read = my_read,
    .write = my_write,
    .unlocked_ioctl = my_ioctl,
    .release = my_release,
};

static int __init my_mod_init(void)
{
    int ret;
    
    pr_info("Module initialized\n");
    
    // Allocate device number
    ret = alloc_chrdev_region(&dev, 0, 1, MY_DEV_NAME);
    if (ret < 0) {
        pr_err("Device number allocation failed\n");
        return ret;
    }
    pr_info("Major:%d Minor:%d registered\n", MAJOR(dev), MINOR(dev));
    
    // Initialize cdev
    cdev_init(&my_cdev, &fops);
    
    // Add cdev to kernel
    ret = cdev_add(&my_cdev, dev, 1);
    if (ret < 0) {
        pr_err("Failed to add cdev\n");
        goto r_cdev;
    }
    
    // Create device class
    dev_class = class_create(THIS_MODULE, MY_CLASS_NAME);
    if (IS_ERR(dev_class)) {
        pr_err("Class creation failed\n");
        ret = PTR_ERR(dev_class);
        goto r_class;
    }
    
    // Create device
    cdevice = device_create(dev_class, NULL, dev, NULL, MY_DEV_NAME);
    if (IS_ERR(cdevice)) {
        pr_err("Device creation failed\n");
        ret = PTR_ERR(cdevice);
        goto r_device;
    }
    
    // Initialize timer
    timer_setup(&my_timer, timer_callback, 0);
    timer_running = false;
    
    pr_info("Device %s created successfully\n", MY_DEV_NAME);
    return 0;
    
r_device:
    class_destroy(dev_class);
r_class:
    cdev_del(&my_cdev);
r_cdev:
    unregister_chrdev_region(dev, 1);
    return ret;
}

static void __exit my_mod_exit(void)
{
    // Clean up timer
    if (timer_running) {
        del_timer(&my_timer);
    }
    
    // Remove device
    device_destroy(dev_class, dev);
    class_destroy(dev_class);
    cdev_del(&my_cdev);
    unregister_chrdev_region(dev, 1);
    
    pr_info("Module unloaded\n");
}

module_init(my_mod_init);
module_exit(my_mod_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("Module using exported symbols!");
