/* omplement an LKM  that creats a char device with an IOCTL SEND_SEND_INT
the user space application should  send an unsigned int via this IOCTL
the device driver should accept  the unsigned integer ,and print its decimal , binary,octal amd hexadecimal equivalent  in dmesg 
ex 
decimal :10, binary:0b1010, octal; 0o... and so on 

*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX_STR_LEN 50

void to_binary(unsigned int n, char out[]) {
    char temp[MAX_STR_LEN];

    if (n == 0) {
        strcpy(out, "0b0");
        return;
    }

    while (n > 0) {
        temp[j++] = (n & 1) ? '1' : '0';
        n >>= 1;
    }
    out[0] = '0';
    out[1] = 'b';
    for (i = 0; i < j; i++)
        out[2 + i] = temp[j - 1 - i];
    out[2 + j] = '\0';
}

void to_octal(unsigned int n, char out[]) {
    int i, j = 0;
    char temp[MAX_STR_LEN];

    if (n == 0) {
        strcpy(out, "0o0");
        return;
    }

    while (n > 0) {
        temp[j++] = '0' + (n & 7);
        n >>= 3;
    }
    out[0] = '0';
    out[1] = 'o';
    for (i = 0; i < j; i++)
        out[2 + i] = temp[j - 1 - i];
    out[2 + j] = '\0';
}

void to_hexadecimal(unsigned int n, char out[]) {
    int i, j = 0;
    char temp[MAX_STR_LEN];
    const char digits[] = "0123456789ABCDEF";

    if (n == 0) {
        strcpy(out, "0X0");
        return;
    }

    while (n > 0) {
        temp[j++] = digits[n & 0xF];
        n >>= 4;
    }
    out[0] = '0';
    out[1] = 'X';
    for (i = 0; i < j; i++)
        out[2 + i] = temp[j - 1 - i];
    out[2 + j] = '\0';
}

unsigned int to_decimal(char str[]) {
    int base = 10;
    int start = 0;
    unsigned int result = 0;
    int i;

    if (strlen(str) < 3 || str[0] != '0')
        return 0;

    if (str[1] == 'b' || str[1] == 'B') {
        base = 2;
        start = 2;
    } else if (str[1] == 'o' || str[1] == 'O') {
        base = 8;
        start = 2;
    } else if (str[1] == 'x' || str[1] == 'X') {
        base = 16;
        start = 2;
    } else {
        return 0;
    }

    for (i = start; str[i] != '\0'; i++) {
        char c = str[i];
        unsigned int value = 0;
        if (isdigit(c))
            value = c - '0';
        else if (base == 16 && c >= 'A' && c <= 'F')
            value = 10 + (c - 'A');
        else if (base == 16 && c >= 'a' && c <= 'f')
            value = 10 + (c - 'a');
        else
            return 0; // invalid char
        if (value >= (unsigned int)base)
            return 0; // invalid digit for base
        result = result * base + value;
    }
    return result;
}

int main() {
    unsigned int n1 = 10, n2 = 8, n3 = 16;
    char b[MAX_STR_LEN], o[MAX_STR_LEN], h[MAX_STR_LEN];

    to_binary(n1, b);
    to_octal(n2, o);
    to_hexadecimal(n3, h);

    printf("Binary of %u: %s\n", n1, b);
    printf("Octal of %u: %s\n", n2, o);
    printf("Hexadecimal of %u: %s\n", n3, h);

    printf("to_decimal(\"%s\") = %u\n", b, to_decimal(b));
    printf("to_decimal(\"%s\") = %u\n", o, to_decimal(o));
    printf("to_decimal(\"%s\") = %u\n", h, to_decimal(h));

    // Try with user input
    char input[MAX_STR_LEN];
    printf("Enter a number string (e.g., 0b1010, 0o10, 0X10): ");
    if (scanf("%49s", input) == 1) {
        printf("Decimal: %u\n", to_decimal(input));
    }

    return 0;
}

