/* Write user space c code that creates 100,000 random intergers, and check if each 
such integer is prime or not.
if the interger  is prime ,add it to a prime linked list.
Else add it to a non_prime_linked_list.

what is the percentage of number that are prime?

sort the prime_linked_list in descending order.

**********************************************************************************

convert the project  to use a kernel device driver.
the user space application will send the random integers to kernel using an IOCTL.
The LKM Should conduct a prime check,and add prime number to kernel linked list. you can non-prime number.
Also implement an IOCTL where the user-spce can get back all the prime number frome the kernel space. */



// prime_lkm.c
#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/cdev.h>

#define DEVICE_NAME "cdac_dev"
#define CLASS_NAME  "num_class"
#define IOCTL_SEND_NUM   _IOW('b', 1, int)
#define IOCTL_GET_PRIMES _IOR('b', 2, int *)

static int major;
static struct class*  prime_class  = NULL;
static struct device* prime_device = NULL;

struct prime_node {
    int val;
    struct prime_node *next;
};

static struct prime_node *prime_head = NULL;
static int prime_count = 0;

static int is_prime(int num) {
    int i;
    if (num <= 1) return 0;
    if (num == 2) return 1;
    if (num % 2 == 0) return 0;
    for (i = 3; i * i <= num; i += 2)
        if (num % i == 0) return 0;
    return 1;
}

static void add_prime(int num) {
    struct prime_node *new = kmalloc(sizeof(struct prime_node), GFP_KERNEL);
    if (!new) return;
    new->val = num;
    new->next = prime_head;
    prime_head = new;
    prime_count++;
    if (prime_count == 100000) {
        printk(KERN_INFO "cdac_dev: 100,000 prime numbers stored in kernel!\n");
    }
}

static long prime_ioctl(struct file *file, unsigned int cmd, unsigned long arg) {
    int num;
    struct prime_node *p;
    int *kbuf;
    int i;

    switch (cmd) {
        case IOCTL_SEND_NUM:
            if (copy_from_user(&num, (int __user *)arg, sizeof(int)))
                return -EFAULT;
            if (is_prime(num))
                add_prime(num);
            break;

        case IOCTL_GET_PRIMES:
            kbuf = kmalloc(sizeof(int) * prime_count, GFP_KERNEL);
            if (!kbuf) return -ENOMEM;
            p = prime_head;
            for (i = 0; i < prime_count && p; ++i) {
                kbuf[i] = p->val;
                p = p->next;
            }
            if (copy_to_user((int __user *)arg, kbuf, sizeof(int) * prime_count)) {
                kfree(kbuf);
                return -EFAULT;
            }
            kfree(kbuf);
            return prime_count;
    }
    return 0;
}

static int dev_open(struct inode *inodep, struct file *filep) { return 0; }
static int dev_release(struct inode *inodep, struct file *filep) { return 0; }

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = prime_ioctl,
    .open = dev_open,
    .release = dev_release,
};

static int __init prime_init(void) {
    major = register_chrdev(0, DEVICE_NAME, &fops);
    if (major < 0) {
        printk(KERN_ALERT "cdac_dev failed to register a major number\n");
        return major;
    }
    prime_class = class_create(THIS_MODULE, CLASS_NAME);
    if (IS_ERR(prime_class)) {
        unregister_chrdev(major, DEVICE_NAME);
        printk(KERN_ALERT "Failed to register device class\n");
        return PTR_ERR(prime_class);
    }
    prime_device = device_create(prime_class, NULL, MKDEV(major, 0), NULL, DEVICE_NAME);
    if (IS_ERR(prime_device)) {
        class_destroy(prime_class);
        unregister_chrdev(major, DEVICE_NAME);
        printk(KERN_ALERT "Failed to create the device\n");
        return PTR_ERR(prime_device);
    }
    printk(KERN_INFO "cdac_dev: device class created successfully\n");
    return 0;
}

static void __exit prime_exit(void) {
    struct prime_node *p = prime_head;
    struct prime_node *tmp;
    while (p) {
        tmp = p;
        p = p->next;
        kfree(tmp);
    }
    device_destroy(prime_class, MKDEV(major, 0));
    class_unregister(prime_class);
    class_destroy(prime_class);
    unregister_chrdev(major, DEVICE_NAME);
    printk(KERN_INFO "cdac_dev: Goodbye from the Kernel\n");
}

module_init(prime_init);
module_exit(prime_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("Directries and file entries in /sys (sysfs)");
