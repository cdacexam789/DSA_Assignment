#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define DEVICE_FILE "/dev/cdac_dev"
#define IOCTL_SEND_NUM   _IOW('b', 1, int)
#define IOCTL_GET_PRIMES _IOR('b', 2, int *)

#define NUMS 100000

struct node {
    int val;
    struct node *next;
};

void insert(struct node **head, int val) {
    struct node *new = malloc(sizeof(struct node));
    new->val = val;
    new->next = *head;
    *head = new;
}

int is_prime(int n) {
    if (n <= 1) return 0;
    if (n == 2) return 1;
    if (n % 2 == 0) return 0;
    for (int i = 3; i*i <= n; i += 2)
        if (n % i == 0) return 0;
    return 1;
}

struct node* merge(struct node* a, struct node* b) {
    if (!a) return b;
    if (!b) return a;
    struct node* result;
    if (a->val > b->val) {
        result = a;
        result->next = merge(a->next, b);
    } else {
        result = b;
        result->next = merge(a, b->next);
    }
    return result;
}

void split(struct node* source, struct node** front, struct node** back) {
    struct node* fast = source->next;
    struct node* slow = source;
    while (fast) {
        fast = fast->next;
        if (fast) {
            slow = slow->next;
            fast = fast->next;
        }
    }
    *front = source;
    *back = slow->next;
    slow->next = NULL;
}

void merge_sort(struct node** headRef) {
    struct node* head = *headRef;
    if (!head || !head->next) return;
    struct node *a, *b;
    split(head, &a, &b);
    merge_sort(&a);
    merge_sort(&b);
    *headRef = merge(a, b);
}

void free_list(struct node* head) {
    while (head) {
        struct node* tmp = head;
        head = head->next;
        free(tmp);
    }
}

int main() {
    struct node *prime = NULL, *non_prime = NULL;
    int prime_count = 0, generated = 0;
    int fd = -1;
    int running = 1;

    while (running) {
        int choice;
        printf("\nMenu:\n");
        printf("1. Generate 100,000 random numbers and check primes\n");
        printf("2. Sort prime list in descending order\n");
        printf("3. Send all numbers to kernel\n");
        printf("4. Retrieve all primes from kernel\n");
        printf("5. Show top 10 primes\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
        case 1:
            if (generated) {
                printf("Numbers already generated. Restart program to regenerate.\n");
                break;
            }
            srand(time(NULL));
            for (int i = 0; i < NUMS; ++i) {
                int num = rand();
                if (is_prime(num)) {
                    insert(&prime, num);
                    prime_count++;
                } else {
                    insert(&non_prime, num);
                }
            }
            printf("Generated %d numbers.\n", NUMS);
            printf("Total primes: %d\n", prime_count);
            printf("Percentage of primes: %.2f%%\n", (prime_count*100.0)/NUMS);
            generated = 1;
            break;
        case 2:
            if (!prime) {
                printf("Prime list is empty. Generate numbers first.\n");
                break;
            }
            merge_sort(&prime);
            printf("Prime list sorted in descending order.\n");
            break;
        case 3:
            if (!generated) {
                printf("Generate numbers first.\n");
                break;
            }
            fd = open(DEVICE_FILE, O_RDWR);
            if (fd < 0) {
                perror("open");
                break;
            }
            {
                struct node* p = prime;
                while (p) {
                    ioctl(fd, IOCTL_SEND_NUM, &p->val);
                    p = p->next;
                }
                p = non_prime;
                while (p) {
                    ioctl(fd, IOCTL_SEND_NUM, &p->val);
                    p = p->next;
                }
            }
            printf("All numbers sent to kernel.\n");
            close(fd);
            fd = -1;
            break;
        case 4:
            fd = open(DEVICE_FILE, O_RDWR);
            if (fd < 0) {
                perror("open");
                break;
            }
            {
                int *kernel_primes = malloc(sizeof(int) * NUMS);
                int ret = ioctl(fd, IOCTL_GET_PRIMES, kernel_primes);
                if (ret < 0) {
                    perror("ioctl get primes");
                } else {
                    printf("Kernel reported %d primes. First 10:\n", ret);
                    for (int i = 0; i < 10 && i < ret; ++i)
                        printf("%d ", kernel_primes[i]);
                    printf("\n");
                }
                free(kernel_primes);
            }
            close(fd);
            fd = -1;
            break;
        case 5:
            if (!prime) {
                printf("Prime list is empty. Generate numbers first.\n");
                break;
            }
            printf("Top 10 primes:\n");
            {
                struct node* p = prime;
                for (int i = 0; i < 10 && p; ++i, p = p->next)
                    printf("%d ", p->val);
                printf("\n");
            }
            break;
        case 6:
            running = 0;
            break;
        default:
            printf("Invalid choice.\n");
        }
    }
    free_list(prime);
    free_list(non_prime);
    return 0;
}

