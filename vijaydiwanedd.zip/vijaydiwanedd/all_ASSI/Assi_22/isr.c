

#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/workqueue.h>

extern struct workqueue_struct *my_work_queue;
extern struct work_struct my_work;

irq_handler_t button_handler(unsigned int irq, void *dev_id, struct pt_regs *regs)
{
    pr_info("In button press interrupt!\n");
    pr_info("Scheduling work...\n");
    queue_work(my_work_queue, &my_work);
    pr_info("Exiting interrupt handler\n");
    return (irq_handler_t)IRQ_HANDLED;
}

