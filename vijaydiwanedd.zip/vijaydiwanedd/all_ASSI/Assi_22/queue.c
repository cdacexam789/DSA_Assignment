
#include <linux/module.h>
#include <linux/workqueue.h>

unsigned int gpioButton = 46;
unsigned int irqNumber;
unsigned int numPresses = 0;

struct workqueue_struct *my_work_queue;
struct work_struct my_work;

void my_work_func(struct work_struct *work)
{
    numPresses++;
    pr_info("In %s: numPresses = %d\n", __func__, numPresses);
}

