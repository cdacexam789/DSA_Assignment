

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#define DEVICE_FILE "/dev/cdac_dev"

int main() {
    int fd;
    char buffer[100];
    ssize_t bytesRead;

  
    FILE *file = fopen("/etc/passwd", "r");
    if (!file) {
        perror("Failed to open /etc/passwd");
        return 1;
    }
    bytesRead = fread(buffer, 1, sizeof(buffer), file);
    fclose(file);


    fd = open(DEVICE_FILE, O_WRONLY);
    if (fd < 0) {
        perror("Failed to open device");
        return 1;
    }

    if (write(fd, buffer, bytesRead) < 0) {
        perror("Failed to write to device");
        close(fd);
        return 1;
    }

    printf("Wrote %zd bytes to the device\n", bytesRead);
    close(fd);
    return 0;
}

