
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

#define DEVICE "/dev/numdev"
#define IOCTL_SEND_INT _IOW('p', 1, unsigned int)

int main() {
    int fd;
    unsigned int num;

    fd = open(DEVICE, O_RDWR);
    
    if (fd < 0) {
        perror("open");
        return 1;
    }

    srand(time(NULL));
    
    while (1) {
        num = rand() % 16; 
        
        printf("Sending: %u\n", num);

        if (ioctl(fd, IOCTL_SEND_INT, &num) < 0) {
        
            perror("ioctl");
            close(fd);
            return 1;
        }
        sleep(1);
    }

    close(fd);
    return 0;
}

