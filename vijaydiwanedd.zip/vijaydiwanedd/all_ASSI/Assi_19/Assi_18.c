/*  write  a user space application to send a random unsigned integer to the kernal space
using an IOCTL

write an LKM  that accepts the integer from the user space , checks  wheater it is prime or non prime 

if it is  prime all 4 leds should glow 
if it is not LEDs should glow  

the user spaceapplication will send 1 integer  per second 

*/


#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/ioctl.h>
#include <linux/gpio.h>

#define DEVICE_NAME "numdev"

#define CLASS_NAME  "numdev_class"

#define IOCTL_SEND_INT _IOW('p', 1, unsigned int)

#define NUM_LEDS 4

static int led_gpios[NUM_LEDS] = {47, 48, 49, 60}; 

static int major;
static struct class *numdev_class = NULL;
static struct cdev numdev_cdev;

static int is_prime(unsigned int n) {

    unsigned int i; 

    if (n < 2)
        return 0; 

    for (i = 2; i * i <= n; i++) {
        if (n % i == 0)
            return 0; 
    }
    return 1; 
}


static long numdev_ioctl(struct file *file, unsigned int cmd, unsigned long arg) {
    unsigned int value;
    int i;

    if (cmd == IOCTL_SEND_INT) {
    
        if (copy_from_user(&value, (unsigned int __user *)arg, sizeof(unsigned int)))
        
            return -EFAULT;

        if (is_prime(value)) {
        
            for (i = 0; i < NUM_LEDS; i++)
            
                gpio_set_value(led_gpios[i], 1);
                 
            pr_info(KERN_INFO "numdev: %u is prime, all LEDs ON\n", value);
            
        } else {
        
            for (i = 0; i < NUM_LEDS; i++) {
            
                int bit = (value >> (NUM_LEDS - 1 - i)) & 0x1;
                
                gpio_set_value(led_gpios[i], bit);
            }
           pr_info(KERN_INFO "numdev: %u is not prime, all LEDs OFF \n", value);
        }
        return 0;
    }
    return -EINVAL;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = numdev_ioctl,
};

static int __init numdev_init(void) {
    dev_t dev;
    int ret, i;

    ret = alloc_chrdev_region(&dev, 0, 1, DEVICE_NAME);
    if (ret < 0) return ret;
    major = MAJOR(dev);

    cdev_init(&numdev_cdev, &fops);
    ret = cdev_add(&numdev_cdev, dev, 1);
    if (ret < 0) goto unregister_region;

    numdev_class = class_create(THIS_MODULE, CLASS_NAME);
    if (IS_ERR(numdev_class)) {
        ret = PTR_ERR(numdev_class);
        goto del_cdev;
    }

    device_create(numdev_class, NULL, dev, NULL, DEVICE_NAME);

    for (i = 0; i < NUM_LEDS; i++) {
        if (gpio_request(led_gpios[i], "led_gpio")) {
            pr_info(KERN_ERR "numdev: Failed to request GPIO %d\n", led_gpios[i]);
            while (--i >= 0) gpio_free(led_gpios[i]);
            goto destroy_device;
        }
        gpio_direction_output(led_gpios[i], 0);
    }

    pr_info(KERN_INFO "numdev: device created\n");
    return 0;

destroy_device:
    device_destroy(numdev_class, dev);
    class_destroy(numdev_class);
del_cdev:
    cdev_del(&numdev_cdev);
unregister_region:
    unregister_chrdev_region(dev, 1);
    return ret;
}

static void __exit numdev_exit(void) {
    int i;
    dev_t dev = MKDEV(major, 0);

    for (i = 0; i < NUM_LEDS; i++)
        gpio_free(led_gpios[i]);
    device_destroy(numdev_class, dev);
    class_destroy(numdev_class);
    cdev_del(&numdev_cdev);
    unregister_chrdev_region(dev, 1);
    pr_info(KERN_INFO "numdev: device removed\n");
}

module_init(numdev_init);
module_exit(numdev_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("Kernel linked list - dynamic nodes!");

