


int count_duli = 0;

typedef struct Employee {
    char name[11];
    int id;
    char gender;
    struct Employee *next;
} Employee;

