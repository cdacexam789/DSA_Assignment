//valgrind --leak-check=full ./a.out


//inline: Suggests to the compiler to insert the code directly at the call site, avoiding function call overhead.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "struct.h"


void generate_name(char *name, int length) {
    name[0] = 'A' + rand() % 26;
    for (int i = 1; i < length - 1; i++) {
        name[i] = 'a' + rand() % 26;
    }
    name[length - 1] = '\0';
}

char generate_gender() {
    return (rand() % 2 == 0) ? 'm' : 'f';
}

int is_duplicate_id(Employee *head, int id) {
    while (head != NULL) {
        if (head->id == id) {
            count_duli++;
            printf("Count: %d Duplicate ID is: %d \n", count_duli, id);
            return 1;
        }
        head = head->next;
    }
    return 0;
}

Employee* create_employee(Employee *head) {
    Employee *emp = (Employee*)malloc(sizeof(Employee));
    if (!emp) {
        printf("Memory allocation failed!\n");
        exit(1);
    }
    generate_name(emp->name, 11);

    int id;
    do {
        id = 1000 + rand() % 9000;
    } while (is_duplicate_id(head, id));
    emp->id = id;
    emp->gender = generate_gender();
    emp->next = NULL;
    return emp;
}

void add_employee_start(Employee **head) {
    Employee *emp = create_employee(*head);
    emp->next = *head;
    *head = emp;
}

void add_employee_end(Employee **head) {
    Employee *emp = create_employee(*head);

    if (*head == NULL) {
        *head = emp;
        return;
    }
    Employee *curr = *head;
    while (curr->next != NULL) {
        curr = curr->next;
    }
    curr->next = emp;
}

void print_employees(Employee *head) {
    int count = 0;
    while (head != NULL) {
        printf("%d. Name: %s\n   ID: %d\n   Gender: %c\n", ++count, head->name, head->id, head->gender);
        head = head->next;
    }
    printf("Total Employees: %d\n", count);
}

void delete_employee_start(Employee **head) {
    if (*head == NULL) return;
    Employee *temp = *head;
    *head = (*head)->next;
    free(temp);
}

void delete_employee_end(Employee **head) {
    if (*head == NULL) return;
    if ((*head)->next == NULL) {
        free(*head);
        *head = NULL;
        return;
    }
    Employee *curr = *head;
    while (curr->next->next != NULL) {
        curr = curr->next;
    }
    free(curr->next);
    curr->next = NULL;
}

void print_gender_counts(Employee *head) {
    int male_count = 0, female_count = 0;
    Employee *curr = head;

    while (curr != NULL) {
        if (curr->gender == 'm') {
            male_count++;
        }
        curr = curr->next;
    }

    curr = head;
    while (curr != NULL) {
        if (curr->gender == 'f') {
            female_count++;
        }
        curr = curr->next;
    }

    printf("\nTotal Male Employees: %d\n", male_count);
    printf("Total Female Employees: %d\n", female_count);
    printf("Total Employees: %d\n", male_count + female_count);
}

void save_to_files(Employee *head) {

    FILE *fall = fopen("all.txt", "w");
    FILE *fmale = fopen("male.txt", "w");
    FILE *ffemale = fopen("female.txt", "w");
    

    Employee *curr = head;
    char buffer[100];
    
    while (curr != NULL) {
        sprintf(buffer, "Name: %s, ID: %d, Gender: %c\n", curr->name, curr->id, curr->gender);
        fputs(buffer, fall);
        if (curr->gender == 'm') {
            fputs(buffer, fmale);
        } else if (curr->gender == 'f') {
            fputs(buffer, ffemale);
        }
        curr = curr->next;
    }

    fclose(fall);
    fclose(fmale);
    fclose(ffemale);
    printf("Data saved to all.txt, male.txt, and female.txt successfully.\n");
}

int main() {
    Employee *head = NULL;
    int choice, n, i;

    while (1) {
        printf("\n*********** Employee Linked List Menu ***********\n");
        printf("1. Add employee at START\n");
        printf("2. Add employee at END\n");
        printf("3. Delete employee from START\n");
        printf("4. Delete employee from END\n");
        printf("5. Print employee list\n");
        printf("6. Print The Gender\n");
        printf("7. Save all data to files\n");
        printf("8. Exit\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) break;

        switch (choice) {
            case 1:
                printf("How many employees to add at start? ");
                scanf("%d", &n);
                for (i = 0; i < n; i++) add_employee_start(&head);
                printf("%d employees added at start.\n", n);
                break;
            case 2:
                printf("How many employees to add at end? ");
                scanf("%d", &n);
                for (i = 0; i < n; i++) add_employee_end(&head);
                printf("%d employees added at end.\n", n);
                break;
            case 3:
                printf("How many employees to delete from start? ");
                scanf("%d", &n);
                for (i = 0; i < n; i++) delete_employee_start(&head);
                printf("%d employees deleted from start.\n", n);
                break;
            case 4:
                printf("How many employees to delete from end? ");
                scanf("%d", &n);
                for (i = 0; i < n; i++) delete_employee_end(&head);
                printf("%d employees deleted from end.\n", n);
                break;
            case 5:
                print_employees(head);
                break;
            case 6:
                print_gender_counts(head);
                break;
            case 7:
                save_to_files(head);
                break;
            case 8:
                while (head != NULL) delete_employee_start(&head);
                printf("Exiting program.................\n");
                return 0;
        }
    }
    return 0;
}

