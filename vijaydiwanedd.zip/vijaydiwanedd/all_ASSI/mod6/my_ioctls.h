#define MY_HW_READ 	_IOR('z', 123, unsigned int *)
#define MY_HW_WRITE	_IOW('z', 124, unsigned int *)
