/*cretae c code for a linked list each node should contain:

1.employee name 
2.Employee ID
3.Employee gender

the LL should support actions like 
1.aa node (at the start , or end ,or in the middle)
2. Delete node (from the strat,or end or in the middle )

add a function to pribnt the current state of the ll.
check the memor leakage using valgrid

valgrind --leak-check=full ./a.out

 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct Employee {
    char name[50];
    int id;
    char gender;
};


struct Node {
    struct Employee data;
    struct Node* next;
};


// Insert a beginning
void insertAtBeginning(struct Node** head) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    
    printf("Enter Employee Name: ");
    scanf("%s", newNode->data.name);
    printf("Enter Employee ID: ");
    scanf("%d", &newNode->data.id);
    printf("Enter Employee Gender (M/F): ");
    scanf(" %c", &newNode->data.gender);
    
    newNode->next = *head;
    *head = newNode;
   printf("*************************************************\n");
    printf("Employee added at the beginning.\n");
   printf("*************************************************\n");
}

// Insert end
void insertAtEnd(struct Node** head) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    
    printf("Enter Employee Name: ");
    scanf("%s", newNode->data.name);
    printf("Enter Employee ID: ");
    scanf("%d", &newNode->data.id);
    printf("Enter Employee Gender (M/F): ");
    scanf(" %c", &newNode->data.gender);
    
    newNode->next = NULL;

    if (*head == NULL) {
        *head = newNode;
        return;
    }

    struct Node* last = *head;
    while (last->next != NULL) {
        last = last->next;
    }

    last->next = newNode;
      printf("*************************************************\n");
    printf("Employee added at the end.\n");
      printf("*************************************************\n");
}

// Insert a new node after a specific ID
void insertAfter(struct Node** head) {
    int searchId;
      printf("*************************************************\n");
      printf("Enter Employee ID after which to insert: ");
      printf("*************************************************\n");
    scanf("%d", &searchId);

    struct Node* temp = *head;
    while (temp != NULL && temp->data.id != searchId) {
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Employee with ID %d not found.\n", searchId);
        return;
    }

    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    
    printf("Enter Employee Name: ");
    scanf("%s", newNode->data.name);
    printf("Enter Employee ID: ");
    scanf("%d", &newNode->data.id);
    printf("Enter Employee Gender (M/F): ");
    scanf(" %c", &newNode->data.gender);
    
    newNode->next = temp->next;
    temp->next = newNode;
      printf("*************************************************\n");
       printf("Employee added after ID %d.\n", searchId);
      printf("*************************************************\n");
}


void deleteNode(struct Node** head, int id) {
    if (*head == NULL) {
        printf("List is empty.\n");
        return;
    }

    struct Node* temp = *head;
    struct Node* prev = NULL;


    if (temp != NULL && temp->data.id == id) {
        *head = temp->next;
        free(temp);
        printf("*************************************************\n");
        printf("Employee with ID %d deleted.\n", id);
        printf("*************************************************\n");
        return;
    }

    while (temp != NULL && temp->data.id != id) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Employee with ID %d not found.\n", id);
        return;
    }

    prev->next = temp->next;
    free(temp);
    printf("Employee with ID %d deleted.\n", id);
}


// Delete beginning
void deleteFromBeginning(struct Node** head) {
    if (*head == NULL) {
        printf("List is empty.\n");
        return;
    }

    struct Node* temp = *head;
    *head = (*head)->next;
      printf("*************************************************\n");
    printf("Deleted employee with ID %d from beginning.\n", temp->data.id);
      printf("*************************************************\n");
    free(temp);
}



// Delete end
void deleteFromEnd(struct Node** head) {
    if (*head == NULL) {
        printf("List is empty.\n");
        return;
    }

    struct Node* temp = *head;
    struct Node* prev = NULL;

    if (temp->next == NULL) {
        printf("Deleted employee with ID %d from end.\n", temp->data.id);
        free(temp);
        *head = NULL;
        return;
    }

    while (temp->next != NULL) {
        prev = temp;
        temp = temp->next;
    }

    prev->next = NULL;
    printf("Deleted employee with ID %d from end.\n", temp->data.id);
    free(temp);
}


// Print the linked list
void printList(struct Node* node) {
    if (node == NULL) {
        printf("List is empty.\n");
        return;
    }

    printf("\nCurrent Employee List:\n");
    printf("*************************************************\n");
    printf("ID\tName\t\tGender\n");
      printf("*************************************************\n");
    
    while (node != NULL) {
        printf("%d\t%s\t\t%c\n", node->data.id, node->data.name, node->data.gender);
        node = node->next;
    }
      printf("*************************************************\n");
}




// Free all nodes memory leaks
void freeList(struct Node** head) {
    struct Node* current = *head;
    struct Node* next;

    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }

    *head = NULL;
}
       
     

int main() {

    struct Node* head = NULL;
    int choice, id;

    while (1) {
    
        printf("\nEmployee Linked List Operations:\n");
        
        printf("1. Insert at beginning\n");
        
        printf("2. Insert at end\n");
        
        printf("3. Insert in the middle ID\n");
        
        printf("4. Delete in the middle employee\n");
        
        printf("5. Delete from beginning\n");
        
        printf("6. Delete from end\n");
        
        printf("7. Display \n");
        
        printf("8. Exit\n");
        
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                insertAtBeginning(&head);
                break;
            case 2:
                insertAtEnd(&head);
                break;
            case 3:
                insertAfter(&head);
                break;
            case 4:
            
                printf("Enter Employee ID to delete: ");
                scanf("%d", &id);
                deleteNode(&head, id);
                break;
                
            case 5:
                deleteFromBeginning(&head);
                break;
            case 6:
                deleteFromEnd(&head);
                break;
            case 7:
                printList(head);
                break;
            case 8:
                freeList(&head);
                exit(0);
        }
    }

    return 0;
}











  
       
	
	
