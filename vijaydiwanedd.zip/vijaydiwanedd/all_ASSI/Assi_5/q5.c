/*
create a LKM   with support for moduele prams:
1.  a module param named "class_name" -string 
2.   a module param named "device_name" -string 
3.  module param named "num_devs"   -int
 
 when the user loads the module using insmod , like:
 $sudo insmod my_module.ko num_dev=5 class_name=my_cls device_name=my_dev
 
 the module should create the class"my                                                                                                                                                                                                                                                                              
 _cls" and 5  device named:
 /dev/my_dev01
 /dev/my_dev02
 
 test the module for multiple loads and uploads and verify kernal stability.
 implement a check that num_devs should not exceed 10.
 
 */
 
 //sudo insmod param_dev.ko num_devs=3 class_name=test_cls device_name=test_dev
 
 
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h> 
#include <linux/err.h>
#include <linux/device.h>
#include <linux/kdev_t.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/string.h>

#define MOD_NAME "param_dev"
#define MAX_DEVICES 10
#define KBUF_SIZE 1024


static char *class_name = "My_class";
static char *device_name = "My_dev";
static int num_devs = 1;

module_param(class_name, charp, 0644);
MODULE_PARM_DESC(class_name, "Class name for the devices");
module_param(device_name, charp, 0644);
MODULE_PARM_DESC(device_name, "Base name for the devices");
module_param(num_devs, int, 0644);
MODULE_PARM_DESC(num_devs, "Number of devices to create (1-10)");


static dev_t first_dev;
static struct class *dev_class;
static struct cdev cdevs[MAX_DEVICES];
static struct device *devices[MAX_DEVICES];
static char *kbufs[MAX_DEVICES];


static int dev_open(struct inode *inode, struct file *file)
{
    int minor = iminor(inode);
    pr_info("Device opened: minor %d\n", minor);
    return 0;
    
}

static int dev_release(struct inode *inode, struct file *file)
{
    int minor = iminor(inode);
    pr_info("Device released: minor %d\n", minor);
    return 0;
}

static ssize_t dev_read(struct file *file, char __user *buf, size_t len, loff_t *offset)
{
    int minor = iminor(file_inode(file));
    int bytes_to_copy;
    
    if (minor >= num_devs) {
        pr_err("Invalid minor number %d\n", minor);
        return -EINVAL;
    }

    bytes_to_copy = min(len, (size_t)(KBUF_SIZE - *offset));
    if (bytes_to_copy == 0) {
        pr_info("Read offset at end of device %d\n", minor);
        return 0;
    }

    if (copy_to_user(buf, kbufs[minor] + *offset, bytes_to_copy)) {
        pr_err("Failed to copy data to user for device %d\n", minor);
        return -EFAULT;
    }

    *offset += bytes_to_copy;
    pr_info("Read %zu bytes from device %d\n", len, minor);
    return bytes_to_copy;
}

static ssize_t dev_write(struct file *file, const char __user *buf, size_t len, loff_t *offset)
{
    int minor = iminor(file_inode(file));
    int bytes_to_copy;

    if (minor >= num_devs) {
        pr_err("Invalid minor number %d\n", minor);
        return -EINVAL;
    }

    bytes_to_copy = min(len, (size_t)(KBUF_SIZE - *offset));
    if (bytes_to_copy == 0) {
        pr_info("Write offset at end of device %d\n", minor);
        return -ENOSPC;
    }

    if (copy_from_user(kbufs[minor] + *offset, buf, bytes_to_copy)) {
        pr_err("Failed to copy data from user for device %d\n", minor);
        return -EFAULT;
    }

    *offset += bytes_to_copy;
    pr_info("Written %zu bytes to device %d\n", len, minor);
    return bytes_to_copy;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .open = dev_open,
    .release = dev_release,
    .read = dev_read,
    .write = dev_write,
};

static int __init dev_init(void)
{
    int i, ret;
    dev_t dev;
    char dev_name[32];

    pr_info("Initializing %s module\n", MOD_NAME);

   
    if (num_devs < 1 || num_devs > MAX_DEVICES) {
        pr_err("Invalid number of devices %d (must be 1-%d)\n", num_devs, MAX_DEVICES);
        return -EINVAL;
    }

    pr_info("Creating %d devices with class '%s' and base name '%s'\n",
            num_devs, class_name, device_name);


    for (i = 0; i < num_devs; i++) {
        kbufs[i] = kmalloc(KBUF_SIZE, GFP_KERNEL);
        if (!kbufs[i]) {
            pr_err("Failed to allocate kernel buffer for device %d\n", i);
            ret = -ENOMEM;
            goto err_kbuf;
        }
        memset(kbufs[i], 0, KBUF_SIZE);
    }


    ret = alloc_chrdev_region(&first_dev, 0, num_devs, MOD_NAME);
    if (ret < 0) {
        pr_err("Failed to allocate device numbers\n");
        goto err_kbuf;
    }
    pr_info("Allocated major number %d, minor %d-%d\n",
            MAJOR(first_dev), MINOR(first_dev), MINOR(first_dev) + num_devs - 1);

    
    dev_class = class_create(THIS_MODULE, class_name);
    if (IS_ERR(dev_class)) {
        pr_err("Failed to create device class\n");
        ret = PTR_ERR(dev_class);
        goto err_class;
    }

   
    for (i = 0; i < num_devs; i++) {
        cdev_init(&cdevs[i], &fops);
        cdevs[i].owner = THIS_MODULE;
        
        dev = MKDEV(MAJOR(first_dev), MINOR(first_dev) + i);
        ret = cdev_add(&cdevs[i], dev, 1);
        if (ret < 0) {
            pr_err("Failed to add cdev %d\n", i);
            goto err_cdev;
        }

     
        snprintf(dev_name, sizeof(dev_name), "%s%02d", device_name, i);
        devices[i] = device_create(dev_class, NULL, dev, NULL, dev_name);
        if (IS_ERR(devices[i])) {
            pr_err("Failed to create device %s\n", dev_name);
            ret = PTR_ERR(devices[i]);
            cdev_del(&cdevs[i]);
            goto err_cdev;
        }

        pr_info("Created device %s (%d:%d)\n", 
                dev_name, MAJOR(dev), MINOR(dev));
    }

    return 0;

err_cdev:
  
    for (i--; i >= 0; i--) {
    
        dev = MKDEV(MAJOR(first_dev), MINOR(first_dev) + i);
        device_destroy(dev_class, dev);
        cdev_del(&cdevs[i]);
    }
    class_destroy(dev_class);
err_class:
    unregister_chrdev_region(first_dev, num_devs);
err_kbuf:
    for (i = 0; i < num_devs; i++) {
        if (kbufs[i])
            kfree(kbufs[i]);
    }
    return ret;
}

static void __exit dev_exit(void)
{
    int i;
    dev_t dev;
    char dev_name[32];

    pr_info("Unloading %s module\n", MOD_NAME);


    for (i = 0; i < num_devs; i++) {
        if (devices[i]) {
            snprintf(dev_name, sizeof(dev_name), "%s%02d", device_name, i);
            pr_info("Removing device %s\n", dev_name);
            dev = MKDEV(MAJOR(first_dev), MINOR(first_dev) + i);
            device_destroy(dev_class, dev);
            cdev_del(&cdevs[i]);
        }
        if (kbufs[i]) {
            kfree(kbufs[i]);
        }
    }

 
    if (dev_class)
        class_destroy(dev_class);


    unregister_chrdev_region(first_dev, num_devs);

    pr_info("Module unloaded\n");
}

module_init(dev_init);
module_exit(dev_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("Module using exported symbols!");
