/* Fixed device node creation module */



#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/err.h>
#include <linux/device.h>
#include <linux/kdev_t.h>

#define MY_CLASS_NAME "my_class"
#define MY_DEV_NAME "my_device"
#define NUM_DEVS (5)

static dev_t dev = 0;
static struct class *dev_class;
static struct device *cdevice[NUM_DEVS];

static int __init my_mod_init(void)
{
    int ret, i;
    int major;
    char dev_name[16];

    pr_info("Hello world from mod33!\n");
    
    ret = alloc_chrdev_region(&dev, 0, NUM_DEVS, MY_DEV_NAME);
    if (ret < 0) {
        pr_err("Error in major:minor allotment!\n");
        return ret;
    }
    pr_info("major:minor range of %d devices %d:%d allotted!\n", 
           NUM_DEVS, MAJOR(dev), MINOR(dev));

    dev_class = class_create(THIS_MODULE, MY_CLASS_NAME);
    if (IS_ERR(dev_class)) {
        pr_err("Could not create device class %s\n", MY_CLASS_NAME);
        ret = PTR_ERR(dev_class);
        goto r_class;
    }

    major = MAJOR(dev);
    for (i = 0; i < NUM_DEVS; i++) {
        snprintf(dev_name, sizeof(dev_name), "%s%c", MY_DEV_NAME, 'A' + i);
        cdevice[i] = device_create(dev_class, NULL, MKDEV(major, i), NULL, dev_name);
        if (IS_ERR(cdevice[i])) {
            pr_err("Could not create device %s\n", dev_name);
            ret = PTR_ERR(cdevice[i]);
            goto r_devices;
        }
    }
    
    pr_info("%d devices %s under class %s created successfully\n", 
           NUM_DEVS, MY_DEV_NAME, MY_CLASS_NAME);
    return 0;

r_devices:
    /* Destroy all devices that were successfully created */
    while (--i >= 0) {
        device_destroy(dev_class, MKDEV(major, i));
    }
    class_destroy(dev_class);
r_class:
    unregister_chrdev_region(dev, NUM_DEVS);
    return ret;
}

static void __exit my_mod_exit(void)
{
    int i, major = MAJOR(dev);
    
    pr_info("Goodbye world from mod33!\n");
    
    for (i = 0; i < NUM_DEVS; i++) {
        device_destroy(dev_class, MKDEV(major, i));
    }
    
    class_destroy(dev_class);
    unregister_chrdev_region(dev, NUM_DEVS);
    pr_info("major:minor numbers freed up...\n");
}

module_init(my_mod_init);
module_exit(my_mod_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("Fixed device node creation module");
