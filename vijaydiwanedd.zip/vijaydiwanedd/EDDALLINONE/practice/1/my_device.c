#include <linux/module.h>
#include <linux/miscdevice.h>
#include <linux/fs.h>
#include <linux/timer.h>
#include <linux/uaccess.h>
#include <linux/ioctl.h>

#define MY_DEVICE_NAME "my_dev"
#define MY_IOCTL_START 0x1001
#define MY_IOCTL_STOP 0x1002

#define IOCTL_START_TIMER _IO(MY_IOCTL_START, 0)
#define IOCTL_STOP_TIMER _IO(MY_IOCTL_STOP, 0)

static struct timer_list my_timer;

static void timer_callback(struct timer_list *t)
{
    pr_info("Timer expired!\n");
    mod_timer(&my_timer, jiffies + HZ);
}

static long my_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    switch (cmd) {
        case IOCTL_START_TIMER:
            pr_info("Starting timer\n");
            mod_timer(&my_timer, jiffies + HZ);
            break;
        case IOCTL_STOP_TIMER:
            pr_info("Stopping timer\n");
            del_timer(&my_timer);
            break;
        default:
            return -ENOTTY;
    }
    return 0;
}

static int my_open(struct inode *inode, struct file *file)
{
    return 0;
}

static int my_release(struct inode *inode, struct file *file)
{
    return 0;
}

static const struct file_operations my_fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = my_ioctl,
    .open = my_open,
    .release = my_release,
};

static struct miscdevice my_misc_device = {
    .minor = MISC_DYNAMIC_MINOR,
    .name = MY_DEVICE_NAME,
    .fops = &my_fops,
    .mode = 0666,
};

static int __init my_init(void)
{
    int ret;
    timer_setup(&my_timer, timer_callback, 0);

    ret = misc_register(&my_misc_device);
    if (ret)
        return ret;

    pr_info("Device initialized\n");
    return 0;
}

static void __exit my_exit(void)
{
    del_timer_sync(&my_timer);
    misc_deregister(&my_misc_device);
    pr_info("Device removed\n");
}

module_init(my_init);
module_exit(my_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("Custom device with timer IOCTLs");

