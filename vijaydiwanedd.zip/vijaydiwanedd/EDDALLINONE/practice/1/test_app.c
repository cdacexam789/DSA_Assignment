#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h> // <-- Add this line

#define MY_IOCTL_START 0x1001
#define MY_IOCTL_STOP 0x1002

#define IOCTL_START_TIMER _IO(MY_IOCTL_START, 0)
#define IOCTL_STOP_TIMER _IO(MY_IOCTL_STOP, 0)

int main(int argc, char *argv[])
{
    int fd;

    if (argc != 2) {
        fprintf(stderr, "Usage: %s [start|stop]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    fd = open("/dev/my_dev", O_RDWR);
    if (fd < 0) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    if (!strcmp(argv[1], "start")) {
        ioctl(fd, IOCTL_START_TIMER);
        printf("Timer started\n");
    }
    else if (!strcmp(argv[1], "stop")) {
        ioctl(fd, IOCTL_STOP_TIMER);
        printf("Timer stopped\n");
    }
    else {
        fprintf(stderr, "Invalid command\n");
        close(fd);
        exit(EXIT_FAILURE);
    }

    close(fd);
    return 0;
}

