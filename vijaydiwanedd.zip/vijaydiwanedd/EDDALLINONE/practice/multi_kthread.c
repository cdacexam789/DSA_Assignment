#include <linux/module.h>
#include <linux/init.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/errno.h>
#include <linux/moduleparam.h>

#define MAX_THREADS 10

static int num_threads = 1;
module_param(num_threads, int, 0444);
MODULE_PARM_DESC(num_threads, "Number of kernel threads to spawn (1-10)");

static struct task_struct *kthreads[MAX_THREADS];

static int thread_fn(void *data)
{
    int id = *(int *)data;
    while (!kthread_should_stop()) {
        printk(KERN_INFO "multi_kthread: Thread %d is running.\n", id);
        ssleep(1);
    }
    printk(KERN_INFO "multi_kthread: Thread %d stopping.\n", id);
    return 0;
}

static int __init multi_kthread_init(void)
{
    int i;
    static int ids[MAX_THREADS];

    if (num_threads < 1 || num_threads > MAX_THREADS) {
        printk(KERN_ERR "multi_kthread: num_threads must be between 1 and %d\n", MAX_THREADS);
        return -EINVAL;
    }

    printk(KERN_INFO "multi_kthread: Starting %d threads.\n", num_threads);

    for (i = 0; i < num_threads; i++) {
        ids[i] = i;
        kthreads[i] = kthread_run(thread_fn, &ids[i], "multi_kthread_%d", i);
        if (IS_ERR(kthreads[i])) {
            printk(KERN_ERR "multi_kthread: Failed to create thread %d\n", i);
            // Cleanup already created threads
            while (--i >= 0)
                kthread_stop(kthreads[i]);
            return -ENOMEM;
        }
    }
    return 0;
}

static void __exit multi_kthread_exit(void)
{
    int i;
    printk(KERN_INFO "multi_kthread: Stopping threads.\n");
    for (i = 0; i < num_threads; i++) {
        if (kthreads[i])
            kthread_stop(kthreads[i]);
    }
    printk(KERN_INFO "multi_kthread: Module unloaded.\n");
}

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("LKM that spawns N kernel threads, each printing to dmesg once per second.");

module_init(multi_kthread_init);
module_exit(multi_kthread_exit);

