#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>

#define IOCTL_START_TIMER _IO('k', 0)
#define IOCTL_STOP_TIMER _IO('k', 1)

int main()
{
    int fd = open("/dev/my_dev", O_RDWR);
    if (fd < 0) {
        perror("Failed to open device");
        return 1;
    }

    printf("Starting timer...\n");
    ioctl(fd, IOCTL_START_TIMER);
    
    printf("Timer running for 5 seconds...\n");
    sleep(5);
    
    printf("Stopping timer...\n");
    ioctl(fd, IOCTL_STOP_TIMER);

    close(fd);
    return 0;
}

