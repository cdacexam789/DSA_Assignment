#include <linux/module.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/timer.h>
#include <linux/ioctl.h>
#include <linux/uaccess.h>

#define MY_CLASS "my_cls"
#define MY_DEVICE "my_dev"
#define IOC_MAGIC 'k'

#define IOCTL_START_TIMER _IO(IOC_MAGIC, 0)
#define IOCTL_STOP_TIMER _IO(IOC_MAGIC, 1)

static dev_t dev_num;
static struct class *my_class;
static struct cdev my_cdev;
static struct timer_list my_timer;
static bool timer_active = false;

static void timer_callback(struct timer_list *t)
{
    printk(KERN_INFO "Timer expired! Restarting...\n");
    if (timer_active)
        mod_timer(&my_timer, jiffies + msecs_to_jiffies(1000));
}

static long my_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    switch (cmd) {
    case IOCTL_START_TIMER:
        if (!timer_active) {
            printk(KERN_INFO "Starting kernel timer\n");
            timer_setup(&my_timer, timer_callback, 0);
            mod_timer(&my_timer, jiffies + msecs_to_jiffies(1000));
            timer_active = true;
        }
        break;
        
    case IOCTL_STOP_TIMER:
        if (timer_active) {
            printk(KERN_INFO "Stopping kernel timer\n");
            del_timer_sync(&my_timer);
            timer_active = false;
        }
        break;
        
    default:
        return -ENOTTY;
    }
    return 0;
}

static int my_open(struct inode *inode, struct file *file)
{
    return 0;
}

static int my_release(struct inode *inode, struct file *file)
{
    return 0;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = my_ioctl,
    .open = my_open,
    .release = my_release,
};

static int __init my_init(void)
{
    // Allocate device numbers
    if (alloc_chrdev_region(&dev_num, 0, 1, "my_timer") < 0)
        return -1;

    // Create character device
    cdev_init(&my_cdev, &fops);
    if (cdev_add(&my_cdev, dev_num, 1) < 0)
        goto err_cdev;

    // Create device class
    my_class = class_create(THIS_MODULE, MY_CLASS);
    if (IS_ERR(my_class))
        goto err_class;

    // Create device node
    if (IS_ERR(device_create(my_class, NULL, dev_num, NULL, MY_DEVICE)))
        goto err_dev;

    printk(KERN_INFO "Timer driver loaded\n");
    return 0;

err_dev:
    class_destroy(my_class);
err_class:
    cdev_del(&my_cdev);
err_cdev:
    unregister_chrdev_region(dev_num, 1);
    return -1;
}

static void __exit my_exit(void)
{
    device_destroy(my_class, dev_num);
    class_destroy(my_class);
    cdev_del(&my_cdev);
    unregister_chrdev_region(dev_num, 1);
    
    if (timer_active)
        del_timer_sync(&my_timer);
        
    printk(KERN_INFO "Timer driver unloaded\n");
}

module_init(my_init);
module_exit(my_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("desd");
MODULE_DESCRIPTION("IOCTL Timer Control Driver");

