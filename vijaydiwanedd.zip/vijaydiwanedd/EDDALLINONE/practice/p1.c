/*Create an LKM with support for creating a device (/dev/cdac_dev) and a kernel linked list and support for user-space interaction.
The user space application should create an Employee record filled with:
1. Employee name - string char[10]
2. Employee ID - int
3. Employee gender - char ('m'/'f')
and send it to the kernel device through an IOCTL SEND_EMPLOYEE_DATA.
The device driver should add the record so sent to an ever increasing kernel linked list.

Also implement 2 more IOCTLS:
1. GET_LIST_SIZE that should return size of the kernel linked list
2. PRINT_LIST that should print the contents of the kernel linked list in dmesg

Check for kernel stability.

Start with 10 employees and then increase it to 1000.
*/

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/list.h>
#include <linux/mutex.h>

#define DEVICE_NAME "cdac_dev"
#define CLASS_NAME  "cdac_class"

#define IOCTL_SEND_EMPLOYEE_DATA _IOW('a', 1, struct employee)
#define IOCTL_GET_LIST_SIZE      _IOR('a', 2, int)
#define IOCTL_PRINT_LIST         _IO('a', 3)

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Perplexity AI");
MODULE_DESCRIPTION("LKM with device, kernel linked list, and IOCTLs");

struct employee {
    char name[10];
    int id;
    char gender;
};

struct employee_node {
    struct employee emp;
    struct list_head list;
};

static int    majorNumber;
static struct class*  cdacClass  = NULL;
static struct device* cdacDevice = NULL;
static struct list_head emp_list;
static int list_size = 0;
static DEFINE_MUTEX(emp_mutex);

static long cdac_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    struct employee emp;
    struct employee_node *node, *tmp;
    int size;

    switch(cmd) {
        case IOCTL_SEND_EMPLOYEE_DATA:
            if (copy_from_user(&emp, (struct employee __user *)arg, sizeof(struct employee)))
                return -EFAULT;
            node = kmalloc(sizeof(struct employee_node), GFP_KERNEL);
            if (!node)
                return -ENOMEM;
            node->emp = emp;
            mutex_lock(&emp_mutex);
            list_add_tail(&node->list, &emp_list);
            list_size++;
            mutex_unlock(&emp_mutex);
            printk(KERN_INFO "cdac_dev: Added Employee: %s, ID: %d, Gender: %c\n", emp.name, emp.id, emp.gender);
            break;

        case IOCTL_GET_LIST_SIZE:
            mutex_lock(&emp_mutex);
            size = list_size;
            mutex_unlock(&emp_mutex);
            if (copy_to_user((int __user *)arg, &size, sizeof(int)))
                return -EFAULT;
            break;

        case IOCTL_PRINT_LIST:
            mutex_lock(&emp_mutex);
            printk(KERN_INFO "cdac_dev: Printing Employee List:\n");
            list_for_each_entry(node, &emp_list, list) {
                printk(KERN_INFO "Employee: %s, ID: %d, Gender: %c\n",
                    node->emp.name, node->emp.id, node->emp.gender);
            }
            mutex_unlock(&emp_mutex);
            break;

        default:
            return -EINVAL;
    }
    return 0;
}

static int cdac_open(struct inode *inodep, struct file *filep) {
    return 0;
}

static int cdac_release(struct inode *inodep, struct file *filep) {
    return 0;
}

static struct file_operations fops =
{
    .owner = THIS_MODULE,
    .unlocked_ioctl = cdac_ioctl,
    .open = cdac_open,
    .release = cdac_release,
};

static int __init cdac_init(void)
{
    INIT_LIST_HEAD(&emp_list);
    mutex_init(&emp_mutex);

    majorNumber = register_chrdev(0, DEVICE_NAME, &fops);
    if (majorNumber < 0) {
        printk(KERN_ALERT "cdac_dev: Failed to register major number\n");
        return majorNumber;
    }

    cdacClass = class_create(THIS_MODULE, CLASS_NAME);
    if (IS_ERR(cdacClass)) {
        unregister_chrdev(majorNumber, DEVICE_NAME);
        printk(KERN_ALERT "cdac_dev: Failed to register device class\n");
        return PTR_ERR(cdacClass);
    }

    cdacDevice = device_create(cdacClass, NULL, MKDEV(majorNumber, 0), NULL, DEVICE_NAME);
    if (IS_ERR(cdacDevice)) {
        class_destroy(cdacClass);
        unregister_chrdev(majorNumber, DEVICE_NAME);
        printk(KERN_ALERT "cdac_dev: Failed to create the device\n");
        return PTR_ERR(cdacDevice);
    }

    printk(KERN_INFO "cdac_dev: Device created successfully\n");
    return 0;
}

static void __exit cdac_exit(void)
{
    struct employee_node *node, *tmp;

    mutex_lock(&emp_mutex);
    list_for_each_entry_safe(node, tmp, &emp_list, list) {
        list_del(&node->list);
        kfree(node);
    }
    mutex_unlock(&emp_mutex);

    device_destroy(cdacClass, MKDEV(majorNumber, 0));
    class_unregister(cdacClass);
    class_destroy(cdacClass);
    unregister_chrdev(majorNumber, DEVICE_NAME);
    mutex_destroy(&emp_mutex);

    printk(KERN_INFO "cdac_dev: Module unloaded\n");
}

module_init(cdac_init);
module_exit(cdac_exit);

