#include <stdio.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>
#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define I2C_BUS "/dev/i2c-0"  // Typical i2c-stub bus
#define SLAVE_ADDR 0x24       // EEPROM I2C address
#define START_ADDR 0x0000     // Starting memory address

int main() {
    int fd;
    char buffer[256];
    const char *data = "Hello world!";
    size_t data_len = strlen(data);
    
    // Prepare address + payload
    buffer[0] = (START_ADDR >> 8) & 0xFF;  // High byte
    buffer[1] = START_ADDR & 0xFF;         // Low byte
    memcpy(&buffer[2], data, data_len);

    // Open I2C bus
    if ((fd = open(I2C_BUS, O_RDWR)) < 0) {
        perror("Open bus failed");
        return 1;
    }

    // Set slave address
    if (ioctl(fd, I2C_SLAVE, SLAVE_ADDR) < 0) {
        perror("Set slave address failed");
        close(fd);
        return 1;
    }

    // Write data with address
    if (write(fd, buffer, data_len + 2) != data_len + 2) {
        perror("Write failed");
        close(fd);
        return 1;
    }

    printf("Written '%s' to 0x%02X:%04X\n", data, SLAVE_ADDR, START_ADDR);
    close(fd);
    return 0;
}

