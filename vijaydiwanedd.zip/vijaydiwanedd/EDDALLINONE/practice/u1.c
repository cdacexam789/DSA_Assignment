#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define DEVICE_PATH "/dev/cdac_dev"

struct employee {
    char name[10];
    int id;
    char gender;
};

#define IOCTL_SEND_EMPLOYEE_DATA _IOW('a', 1, struct employee)
#define IOCTL_GET_LIST_SIZE      _IOR('a', 2, int)
#define IOCTL_PRINT_LIST         _IO('a', 3)

int main(int argc, char *argv[]) {
    int fd, i, list_size;
    struct employee emp;

    if (fd < 0) {
        perror("Failed to open device");
        return 1;
    }

    // Start with 10 employees, increase to 1000 for testing
    int num_employees = 10;
    if (argc > 1)
        num_employees = atoi(argv[1]);

    for (i = 0; i < num_employees; i++) {
        snprintf(emp.name, 10, "Emp%04d", i);
        emp.id = 1000 + i;
        emp.gender = (i % 2 == 0) ? 'm' : 'f';

        if (ioctl(fd, IOCTL_SEND_EMPLOYEE_DATA, &emp) < 0) {
            perror("ioctl SEND_EMPLOYEE_DATA failed");
            close(fd);
            return 1;
        }
    }

    if (ioctl(fd, IOCTL_GET_LIST_SIZE, &list_size) < 0) {
        perror("ioctl GET_LIST_SIZE failed");
        close(fd);
        return 1;
    }
    printf("Employee list size in kernel: %d\n", list_size);

    if (ioctl(fd, IOCTL_PRINT_LIST) < 0) {
        perror("ioctl PRINT_LIST failed");
        close(fd);
        return 1;
    }
    printf("Check dmesg for employee list output.\n");

    close(fd);
    return 0;
}

