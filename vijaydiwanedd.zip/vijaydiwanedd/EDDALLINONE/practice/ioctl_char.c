#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include <linux/ioctl.h>
#include <linux/slab.h>

#define DEVICE_NAME "ioctl_char"
#define CLASS_NAME "ioctl_char_class"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("Example LKM with IOCTL for unsigned int");

static int major;
static struct class *dev_class;
static struct cdev my_cdev;

#define MAGIC 'x'
#define IOCTL_SEND_INT _IOW(MAGIC, 1, unsigned int)

static int device_open(struct inode *inode, struct file *file) {
    pr_info("Device opened\n");
    return 0;
}

static int device_release(struct inode *inode, struct file *file) {
    pr_info("Device closed\n");
    return 0;
}

static long device_ioctl(struct file *file, unsigned int cmd, unsigned long arg) {
    unsigned int value;

    if (cmd == IOCTL_SEND_INT) {
        if (copy_from_user(&value, (unsigned int __user *)arg, sizeof(unsigned int))) {
            pr_err("Failed to copy from user\n");
            return -EFAULT;
        }

        pr_info("decimal: %u, binary: 0b%oB, octal: 0o%o, hexadecimal: 0x%x\n",
                value, value, value, value);
        // Note: %oB is not standard for binary; this is a placeholder.
        // For real binary output, see below.
    } else {
        pr_err("Unknown IOCTL command\n");
        return -ENOTTY;
    }
    return 0;
}

// Helper function to print binary (since %b is not standard in kernel)
static void print_binary(unsigned int value) {
    int i;
    pr_info("binary: 0b");
    for (i = 31; i >= 0; i--) {
        pr_cont("%d", (value >> i) & 1);
    }
    pr_cont("\n");
}

static long device_ioctl_enhanced(struct file *file, unsigned int cmd, unsigned long arg) {
    unsigned int value;

    if (cmd == IOCTL_SEND_INT) {
        if (copy_from_user(&value, (unsigned int __user *)arg, sizeof(unsigned int))) {
            pr_err("Failed to copy from user\n");
            return -EFAULT;
        }

        pr_info("decimal: %u\n", value);
        print_binary(value);
        pr_info("octal: 0o%o\n", value);
        pr_info("hexadecimal: 0x%x\n", value);
    } else {
        pr_err("Unknown IOCTL command\n");
        return -ENOTTY;
    }
    return 0;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .open = device_open,
    .release = device_release,
    .unlocked_ioctl = device_ioctl_enhanced,
};

static int __init ioctl_char_init(void) {
    dev_t dev;

    // Allocate device numbers
    if (alloc_chrdev_region(&dev, 0, 1, DEVICE_NAME) < 0) {
        pr_err("Failed to allocate chrdev region\n");
        return -1;
    }
    major = MAJOR(dev);

    // Create char device
    cdev_init(&my_cdev, &fops);
    if (cdev_add(&my_cdev, dev, 1) < 0) {
        unregister_chrdev_region(dev, 1);
        pr_err("Failed to add cdev\n");
        return -1;
    }

    // Create device class
    dev_class = class_create(THIS_MODULE, CLASS_NAME);
    if (IS_ERR(dev_class)) {
        cdev_del(&my_cdev);
        unregister_chrdev_region(dev, 1);
        pr_err("Failed to create class\n");
        return PTR_ERR(dev_class);
    }

    // Create device node
    if (IS_ERR(device_create(dev_class, NULL, dev, NULL, DEVICE_NAME))) {
        class_destroy(dev_class);
        cdev_del(&my_cdev);
        unregister_chrdev_region(dev, 1);
        pr_err("Failed to create device\n");
        return -1;
    }

    pr_info("ioctl_char module loaded with major number %d\n", major);
    return 0;
}

static void __exit ioctl_char_exit(void) {
    dev_t dev = MKDEV(major, 0);
    device_destroy(dev_class, dev);
    class_destroy(dev_class);
    cdev_del(&my_cdev);
    unregister_chrdev_region(dev, 1);
    pr_info("ioctl_char module unloaded\n");
}

module_init(ioctl_char_init);
module_exit(ioctl_char_exit);

