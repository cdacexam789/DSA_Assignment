#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define DEVICE "/dev/cdac_dev"

#define IOCTL_BASE          'W'
#define IOCTL_SEND_EMPLOYEE_DATA _IOW(IOCTL_BASE, 1, struct employee)
#define IOCTL_GET_LIST_SIZE      _IOR(IOCTL_BASE, 2, int)
#define IOCTL_PRINT_LIST         _IO(IOCTL_BASE, 3)

struct employee {
    char name[10];
    int id;
    char gender;
};

void send_employee(int fd, struct employee *emp) {
    if (ioctl(fd, IOCTL_SEND_EMPLOYEE_DATA, emp) == -1) {
        perror("ioctl SEND_EMPLOYEE_DATA failed");
    }
}

int main(int argc, char *argv[]) {
    int fd, i, n = 10, size;
    struct employee emp;

    if (argc > 1)
        n = atoi(argv[1]); // Number of employees (default 10)

    fd = open(DEVICE, O_RDWR);
    if (fd < 0) {
        perror("Cannot open device file");
        return 1;
    }

    // Add n employees
    for (i = 0; i < n; i++) {
        snprintf(emp.name, sizeof(emp.name), "Emp%04d", i+1);
        emp.id = 1000 + i;
        emp.gender = (i % 2 == 0) ? 'm' : 'f';
        send_employee(fd, &emp);
    }

    // Get list size
    if (ioctl(fd, IOCTL_GET_LIST_SIZE, &size) == -1) {
        perror("ioctl GET_LIST_SIZE failed");
    } else {
        printf("Employee list size: %d\n", size);
    }

    // Print list in kernel log
    if (ioctl(fd, IOCTL_PRINT_LIST) == -1) {
        perror("ioctl PRINT_LIST failed");
    } else {
        printf("Check 'dmesg' for the employee list output.\n");
    }

    close(fd);
    return 0;
}

