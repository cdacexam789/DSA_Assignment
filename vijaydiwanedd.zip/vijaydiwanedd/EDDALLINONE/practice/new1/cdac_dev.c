#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/slab.h>
#include <linux/list.h>

#define DEVICE_NAME "cdac_dev"
#define CLASS_NAME  "cdac_class"

#define IOCTL_BASE          'W'
#define IOCTL_SEND_EMPLOYEE_DATA _IOW(IOCTL_BASE, 1, struct employee)
#define IOCTL_GET_LIST_SIZE      _IOR(IOCTL_BASE, 2, int)
#define IOCTL_PRINT_LIST         _IO(IOCTL_BASE, 3)

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Perplexity AI");
MODULE_DESCRIPTION("LKM with kernel linked list and IOCTL user interaction");
MODULE_VERSION("1.0");

struct employee {
    char name[10];
    int id;
    char gender;
};

struct employee_node {
    struct employee emp;
    struct list_head list;
};

static int    majorNumber;
static struct class*  cdacClass  = NULL;
static struct device* cdacDevice = NULL;
static struct cdev cdev;

static LIST_HEAD(employee_list);
static int employee_count = 0;

static long cdac_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    struct employee emp;
    struct employee_node *node;  // 'tmp' removed, as it's not needed here
    int size;

    switch (cmd) {
        case IOCTL_SEND_EMPLOYEE_DATA:
            if (copy_from_user(&emp, (struct employee __user *)arg, sizeof(struct employee)))
                return -EFAULT;

            node = kmalloc(sizeof(struct employee_node), GFP_KERNEL);
            if (!node)
                return -ENOMEM;
            memcpy(&node->emp, &emp, sizeof(struct employee));
            INIT_LIST_HEAD(&node->list);
            list_add_tail(&node->list, &employee_list);
            employee_count++;
            printk(KERN_INFO "cdac_dev: Added Employee: Name=%s, ID=%d, Gender=%c\n",
                   emp.name, emp.id, emp.gender);
            break;

        case IOCTL_GET_LIST_SIZE:
            size = employee_count;
            if (copy_to_user((int __user *)arg, &size, sizeof(int)))
                return -EFAULT;
            break;

        case IOCTL_PRINT_LIST:
            list_for_each_entry(node, &employee_list, list) {
                printk(KERN_INFO "cdac_dev: Employee: Name=%s, ID=%d, Gender=%c\n",
                       node->emp.name, node->emp.id, node->emp.gender);
            }
            break;

        default:
            return -EINVAL;
    }
    return 0;
}

static int cdac_open(struct inode *inodep, struct file *filep) {
    return 0;
}

static int cdac_release(struct inode *inodep, struct file *filep) {
    return 0;
}

static struct file_operations fops = {
    .owner          = THIS_MODULE,
    .unlocked_ioctl = cdac_ioctl,
    .open           = cdac_open,
    .release        = cdac_release,
};

static int __init cdac_init(void) {
    dev_t dev;
    int ret;

    ret = alloc_chrdev_region(&dev, 0, 1, DEVICE_NAME);
    if (ret < 0) {
        printk(KERN_ALERT "cdac_dev: Failed to allocate major number\n");
        return ret;
    }
    majorNumber = MAJOR(dev);

    cdev_init(&cdev, &fops);
    cdev.owner = THIS_MODULE;
    ret = cdev_add(&cdev, dev, 1);
    if (ret < 0) {
        unregister_chrdev_region(dev, 1);
        return ret;
    }

    cdacClass = class_create(THIS_MODULE, CLASS_NAME);
    if (IS_ERR(cdacClass)) {
        cdev_del(&cdev);
        unregister_chrdev_region(dev, 1);
        return PTR_ERR(cdacClass);
    }

    cdacDevice = device_create(cdacClass, NULL, dev, NULL, DEVICE_NAME);
    if (IS_ERR(cdacDevice)) {
        class_destroy(cdacClass);
        cdev_del(&cdev);
        unregister_chrdev_region(dev, 1);
        return PTR_ERR(cdacDevice);
    }

    printk(KERN_INFO "cdac_dev: Device registered with major %d\n", majorNumber);
    return 0;
}

static void __exit cdac_exit(void) {
    struct employee_node *node, *tmp;
    device_destroy(cdacClass, MKDEV(majorNumber, 0));
    class_unregister(cdacClass);
    class_destroy(cdacClass);
    cdev_del(&cdev);
    unregister_chrdev_region(MKDEV(majorNumber, 0), 1);

    list_for_each_entry_safe(node, tmp, &employee_list, list) {
        list_del(&node->list);
        kfree(node);
    }
    printk(KERN_INFO "cdac_dev: Module unloaded and memory freed\n");
}

module_init(cdac_init);
module_exit(cdac_exit);

