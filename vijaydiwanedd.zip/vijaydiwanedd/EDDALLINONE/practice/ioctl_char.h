#ifndef IOCTL_CHAR_H
#define IOCTL_CHAR_H

#define MAGIC 'x'
#define IOCTL_SEND_INT _IOW(MAGIC, 1, unsigned int)

#endif

