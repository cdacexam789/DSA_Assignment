#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>
#include "ioctl_char.h"

int main() {
    int fd;
    unsigned int value;

    printf("Enter an unsigned integer: ");
    scanf("%u", &value);

    fd = open("/dev/ioctl_char", O_RDWR);
    if (fd < 0) {
        perror("Failed to open the device");
        return -1;
    }

    if (ioctl(fd, IOCTL_SEND_INT, &value) < 0) {
        perror("IOCTL failed");
        close(fd);
        return -1;
    }

    close(fd);
    return 0;
}

