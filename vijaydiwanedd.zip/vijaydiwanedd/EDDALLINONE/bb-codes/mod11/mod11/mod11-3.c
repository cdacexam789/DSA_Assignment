#include <linux/init.h>
#include <linux/module.h>
#include <linux/gpio.h>
#include <linux/interrupt.h>
#include <linux/timer.h>

#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

// Button related
static unsigned int gpioButton = 46; // P8_16
static unsigned int irqNumber;
static unsigned int numPresses = 0;

// LED related
static unsigned int gpioLed = 60; // P9_12
static struct timer_list flash_timer;
static int led_state = 0;
static int flashing = 0; // 0: off, 1: flashing

void timer_callback(struct timer_list *data)
{
    if (flashing)
    {
        led_state = !led_state;
        gpio_set_value(gpioLed, led_state);
        mod_timer(&flash_timer, jiffies + msecs_to_jiffies(1000));
    }
}

static irq_handler_t button_handler(unsigned int irq, void *dev_id, struct pt_regs *regs)
{
    pr_info("Button press interrupt!\n");
    numPresses++;

    if (numPresses % 2 == 1)
    {
        // First press: start flashing
        flashing = 1;
        timer_setup(&flash_timer, timer_callback, 0);
        mod_timer(&flash_timer, jiffies + msecs_to_jiffies(1000));
    }
    else
    {
        // Second press: stop flashing, turn off LED
        flashing = 0;
        del_timer_sync(&flash_timer);
        gpio_set_value(gpioLed, 0);
    }

    return (irq_handler_t)IRQ_HANDLED;
}

static int __init my_init(void)
{
    int result = 0;

    pr_info("Setting up IRQ for GPIO %d for button\n", gpioButton);

    if (!gpio_is_valid(gpioButton))
    {
        pr_err("Invalid GPIO for button!\n");
        return -ENODEV;
    }

    gpio_request(gpioButton, "sysfs");
    gpio_direction_input(gpioButton);
    irqNumber = gpio_to_irq(gpioButton);
    pr_info("GPIO %d mapped to IRQ number %d\n", gpioButton, irqNumber);

    gpio_export(gpioButton, false);

    // LED setup
    if (!gpio_is_valid(gpioLed))
    {
        pr_err("Invalid GPIO for LED!\n");
        gpio_free(gpioButton);
        return -ENODEV;
    }
    gpio_request(gpioLed, "led");
    gpio_direction_output(gpioLed, 0);

    result = request_irq(irqNumber,
                         (irq_handler_t)button_handler,
                         IRQF_TRIGGER_RISING,
                         "my_button_handler",
                         NULL);

    if (result < 0)
    {
        gpio_free(gpioButton);
        gpio_free(gpioLed);
    }

    return result;
}

static void __exit my_exit(void)
{
    flashing = 0;
    del_timer_sync(&flash_timer);
    gpio_set_value(gpioLed, 0);
    free_irq(irqNumber, NULL);
    gpio_unexport(gpioButton);
    gpio_free(gpioButton);
    gpio_free(gpioLed);
    pr_info("GPIOs freed up\n");
    pr_info("%d button presses were detected!\n", numPresses);
    pr_info("Good bye from %s!\n", KBUILD_MODNAME);
}

module_init(my_init);
module_exit(my_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("CDAC EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("A simple interrupt driver using GPIO button and LED timer");

