#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/device.h>
#include <linux/fs.h>

static char *class_name = "default_class";
static char *device_name = "default_dev";
static int num_devs = 1;

module_param(class_name, charp, 0000);
MODULE_PARM_DESC(class_name, "Class name for devices");

module_param(device_name, charp, 0000);
MODULE_PARM_DESC(device_name, "Base name for devices");

module_param(num_devs, int, 0000);
MODULE_PARM_DESC(num_devs, "Number of devices to create");

static struct class *my_class;
static dev_t dev_num;

static int __init my_module_init(void) {
    int ret, i;
    
    printk(KERN_INFO "Loading module: class=%s, device=%s, count=%d\n",
           class_name, device_name, num_devs);

    ret = alloc_chrdev_region(&dev_num, 0, num_devs, device_name);
    if (ret < 0) {
        printk(KERN_ALERT "Device region allocation failed\n");
        return ret;
    }

    my_class = class_create(THIS_MODULE, class_name);
    if (IS_ERR(my_class)) {
        unregister_chrdev_region(dev_num, num_devs);
        printk(KERN_ALERT "Class creation failed\n");
        return PTR_ERR(my_class);
    }

    for (i = 0; i < num_devs; i++) {
        device_create(my_class, NULL, 
                     MKDEV(MAJOR(dev_num), MINOR(dev_num) + i),
                     NULL, "%s%02d", device_name, i+1);
    }

    printk(KERN_INFO "Module loaded successfully\n");
    return 0;
}

static void __exit my_module_exit(void) {
    int i;
    
    for (i = 0; i < num_devs; i++) {
        device_destroy(my_class, 
                      MKDEV(MAJOR(dev_num), MINOR(dev_num) + i));
    }
    
    class_destroy(my_class);
    unregister_chrdev_region(dev_num, num_devs);
    printk(KERN_INFO "Module unloaded successfully\n");
}

module_init(my_module_init);
module_exit(my_module_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("Dynamic device creator LKM");

