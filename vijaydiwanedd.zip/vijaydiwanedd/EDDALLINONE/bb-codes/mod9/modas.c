#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/list.h>
#include <linux/slab.h>
#include <linux/moduleparam.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("A kernel module that builds a linked list with module params");
MODULE_VERSION("0.1");

// Module parameters
static unsigned int num_nodes = 10;
static int start_value = 0;
static int step_size = 2;

module_param(num_nodes, uint, 0444);
MODULE_PARM_DESC(num_nodes, "Number of nodes in the linked list");
module_param(start_value, int, 0444);
MODULE_PARM_DESC(start_value, "Start value for the first node");
module_param(step_size, int, 0444);
MODULE_PARM_DESC(step_size, "Step size between node values");

// Node structure
struct my_node {
    int data;
    struct list_head list;
};

// Head of the list
static LIST_HEAD(my_list_head);

static int __init lkm_list_init(void)
{
    unsigned int i;
    int value = start_value;
    struct my_node *node;

    printk(KERN_INFO "LinkedListLKM: Creating list with %u nodes, start=%d, step=%d\n",
           num_nodes, start_value, step_size);

    for (i = 0; i < num_nodes; i++) {
        node = kmalloc(sizeof(*node), GFP_KERNEL);
        if (!node) {
            printk(KERN_ERR "LinkedListLKM: Memory allocation failed\n");
            return -ENOMEM;
        }
        node->data = value;
        INIT_LIST_HEAD(&node->list);
        list_add_tail(&node->list, &my_list_head);
        value += step_size;
    }

    // Print the list
    i = 0;
    list_for_each_entry(node, &my_list_head, list) {
        printk(KERN_INFO "Node %u: %d\n", i++, node->data);
    }

    return 0;
}

static void __exit lkm_list_exit(void)
{
    struct my_node *node, *tmp;
    unsigned int i = 0;

    list_for_each_entry_safe(node, tmp, &my_list_head, list) {
        printk(KERN_INFO "Freeing node %u: %d\n", i++, node->data);
        list_del(&node->list);
        kfree(node);
    }
    printk(KERN_INFO "LinkedListLKM: Module unloaded, list deleted\n");
}

module_init(lkm_list_init);
module_exit(lkm_list_exit);

