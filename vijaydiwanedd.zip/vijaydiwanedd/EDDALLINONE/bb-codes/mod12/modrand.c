#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/random.h>

#define NUM_RANDOMS 1000

static int __init random_lkm_init(void)
{
    int i;
    int rand;

    printk(KERN_INFO "Random LKM: Generating 1000 random numbers between -100 and 100\n");

    for (i = 0; i < NUM_RANDOMS; i++) {
        get_random_bytes(&rand, sizeof(rand));
         rand = (rand % 201) - 100;   
        printk(KERN_INFO "Random[%d]: %d\n", i, rand);
    }

    return 0;
}

static void __exit random_lkm_exit(void)
{
    printk(KERN_INFO "Random LKM: Exiting\n");
}

module_init(random_lkm_init);
module_exit(random_lkm_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Vikas");
MODULE_DESCRIPTION("Kernel module to generate random numbers between -100 and 100");

