#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/slab.h>

// Extern shared variables from mod351.c
extern char *kbuf;
#define MY_KBUF_SZ (1024)

static int my_open(struct inode *inode, struct file *file)
{
    pr_info("My open function %s called\n", __func__);
    return 0;
}

static ssize_t my_read(struct file *file, char __user *buf, size_t len, loff_t *off)
{
    pr_info("My read function %s called\n", __func__);
    if (*off >= MY_KBUF_SZ)
        return 0;
    if (len > (MY_KBUF_SZ - *off))
        len = MY_KBUF_SZ - *off;
    if (copy_to_user(buf, kbuf + *off, len)) {
        pr_err("Error in data write to userspace!\n");
        return -EFAULT;
    }
    pr_info("Data written to userspace\n");
    *off += len;
    return len;
}

static ssize_t my_write(struct file *file, const char __user *buf, size_t len, loff_t *off)
{
    pr_info("My write function %s called\n", __func__);
    if (len > MY_KBUF_SZ)
        len = MY_KBUF_SZ;
    if (copy_from_user(kbuf, buf, len)) {
        pr_err("Error in data read from userspace!\n");
        return -EFAULT;
    }
    pr_info("Data read from userspace!\n");
    return len;
}

static int my_release(struct inode *inode, struct file *file)
{
    pr_info("My release function %s called\n", __func__);
    return 0;
}

struct file_operations fops = {
    .owner   = THIS_MODULE,
    .open    = my_open,
    .read    = my_read,
    .write   = my_write,
    .release = my_release,
};

