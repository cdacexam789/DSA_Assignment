// arithmetic.c
#include "ops.h"

float add(float a, float b)      { return a + b; }
float subtract(float a, float b) { return a - b; }
float multiply(float a, float b) { return a * b; }
float divide(float a, float b)   { return b != 0.0f ? a / b : 0.0f; }

