// ops.h
#ifndef OPS_H
#define OPS_H

struct ops {
    float (*unary_op)(float);
    float (*binary_op)(float, float);
};

// Arithmetic
float add(float, float);
float subtract(float, float);
float multiply(float, float);
float divide(float, float);

// Trigonometric
float sine(float);
float cosine(float);
float tangent(float);

#endif

