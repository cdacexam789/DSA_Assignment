// main.c
#include <stdio.h>
#include <math.h>
#include "ops.h"

int main() {
    struct ops calculator;

    float a, b, result;
    int choice;

    printf("Calculator Menu:\n");
    printf("1. Add\n2. Subtract\n3. Multiply\n4. Divide\n");
    printf("5. Sine\n6. Cosine\n7. Tangent\n");
    printf("Enter operation number: ");
    scanf("%d", &choice);

    if (choice >= 1 && choice <= 4) {
        printf("Enter two numbers: ");
        scanf("%f %f", &a, &b);
        calculator.unary_op = NULL;
        switch (choice) {
            case 1: calculator.binary_op = add; break;
            case 2: calculator.binary_op = subtract; break;
            case 3: calculator.binary_op = multiply; break;
            case 4: calculator.binary_op = divide; break;
        }
        result = calculator.binary_op(a, b);
        printf("Result: %.4f\n", result);
    } else if (choice >= 5 && choice <= 7) {
        printf("Enter angle in radians: ");
        scanf("%f", &a);
        calculator.binary_op = NULL;
        switch (choice) {
            case 5: calculator.unary_op = sine; break;
            case 6: calculator.unary_op = cosine; break;
            case 7: calculator.unary_op = tangent; break;
        }
        result = calculator.unary_op(a);
        printf("Result: %.4f\n", result);
    } else {
        printf("Invalid choice.\n");
    }

    return 0;
}

