// trigo.c
#include <math.h>
#include "ops.h"

float sine(float x)   { return sinf(x); }
float cosine(float x) { return cosf(x); }
float tangent(float x){ return tanf(x); }

