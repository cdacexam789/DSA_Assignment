#include <linux/module.h>
#include <linux/init.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/kdev_t.h>

#define DEVICE_COUNT 5

static dev_t dev_nums;
static struct class *my_class;

static const char *device_names[DEVICE_COUNT] = {
    "my_deviceA",
    "my_deviceB",
    "my_deviceC",
    "my_deviceD",
    "my_deviceE"
};

static struct device *my_devices[DEVICE_COUNT];

static int __init my_lkm_init(void)
{
    int ret, i;

    // Allocate a range of device numbers
    ret = alloc_chrdev_region(&dev_nums, 0, DEVICE_COUNT, "my_devices");
    if (ret < 0) {
        pr_err("Failed to allocate device numbers\n");
        return ret;
    }

    // Create device class
    my_class = class_create(THIS_MODULE, "my_class");
    if (IS_ERR(my_class)) {
        pr_err("Failed to create class\n");
        unregister_chrdev_region(dev_nums, DEVICE_COUNT);
        return PTR_ERR(my_class);
    }

    // Create devices with requested names
    for (i = 0; i < DEVICE_COUNT; i++) {
        my_devices[i] = device_create(
            my_class, NULL,
            MKDEV(MAJOR(dev_nums), MINOR(dev_nums) + i),
            NULL, device_names[i]
        );
        if (IS_ERR(my_devices[i])) {
            pr_err("Failed to create device %s\n", device_names[i]);
            // Cleanup previously created devices
            while (--i >= 0)
                device_destroy(my_class, MKDEV(MAJOR(dev_nums), MINOR(dev_nums) + i));
            class_destroy(my_class);
            unregister_chrdev_region(dev_nums, DEVICE_COUNT);
            return PTR_ERR(my_devices[i]);
        }
    }

    pr_info("my_lkm: Module loaded, devices created\n");
    return 0;
}

static void __exit my_lkm_exit(void)
{
    int i;
    for (i = 0; i < DEVICE_COUNT; i++)
        device_destroy(my_class, MKDEV(MAJOR(dev_nums), MINOR(dev_nums) + i));
    class_destroy(my_class);
    unregister_chrdev_region(dev_nums, DEVICE_COUNT);
    pr_info("my_lkm: Module unloaded, devices destroyed\n");
}

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("LKM that creates 5 devices with dynamic major/minor numbers");

module_init(my_lkm_init);
module_exit(my_lkm_exit);

