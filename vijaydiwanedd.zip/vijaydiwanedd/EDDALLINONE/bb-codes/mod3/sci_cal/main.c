#include <stdio.h>
#include "arithmetic.h"
#include "trigo.h"

int main() {
    struct ops arithmetic_ops;
    struct ops trig_ops;

    // Assign function pointers for arithmetic operations
    arithmetic_ops.binary_op = add;      // For addition
    arithmetic_ops.binary_op = subtract; // For subtraction
    arithmetic_ops.binary_op = multiply; // For multiplication
    arithmetic_ops.binary_op = divide;   // For division

    // Assign function pointers for trigonometric operations
    trig_ops.unary_op = sin_op; // For sine
    trig_ops.unary_op = cos_op; // For cosine
    trig_ops.unary_op = tan_op; // For tangent

    int choice;
    float a, b;

    printf("Select operation:\n");
    printf("1. Addition\n");
    printf("2. Subtraction\n");
    printf("3. Multiplication\n");
    printf("4. Division\n");
    printf("5. Sine\n");
    printf("6. Cosine\n");
    printf("7. Tangent\n");
    printf("Enter your choice (1-7): ");
    scanf("%d", &choice);

    if (choice >= 1 && choice <= 4) {
        printf("Enter two numbers: ");
        scanf("%f %f", &a, &b);
    } else if (choice >= 5 && choice <= 7) {
        printf("Enter one number: ");
        scanf("%f", &a);
    }

    switch (choice) {
        case 1:
            printf("Addition: %f\n", arithmetic_ops.binary_op(a, b));
            break;
        case 2:
            printf("Subtraction: %f\n", arithmetic_ops.binary_op(a, b));
            break;
        case 3:
            printf("Multiplication: %f\n", arithmetic_ops.binary_op(a, b));
            break;
        case 4:
            if (b != 0) {
                printf("Division: %f\n", arithmetic_ops.binary_op(a, b));
            } else {
                printf("Error: Division by zero.\n");
            }
            break;
        case 5:
            printf("Sine: %f\n", trig_ops.unary_op(a));
            break;
        case 6:
            printf("Cosine: %f\n", trig_ops.unary_op(a));
            break;
        case 7:
            printf("Tangent: %f\n", trig_ops.unary_op(a));
            break;
        default:
            printf("Invalid choice.\n");
            break;
    }

    return 0;
}

