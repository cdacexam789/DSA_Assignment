#include <math.h>
#include "trigo.h"

float sin_op(float x) {
    return sin(x);
}

float cos_op(float x) {
    return cos(x);
}

float tan_op(float x) {
    return tan(x);
}

