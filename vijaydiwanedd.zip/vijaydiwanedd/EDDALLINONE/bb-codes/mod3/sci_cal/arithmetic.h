#ifndef ARITHMETIC_H
#define ARITHMETIC_H

struct ops {
    float (*unary_op)(float);
    float (*binary_op)(float, float);
};

// Arithmetic operations
float add(float a, float b);
float subtract(float a, float b);
float multiply(float a, float b);
float divide(float a, float b);

#endif // ARITHMETIC_H

