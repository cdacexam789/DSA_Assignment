#include <stdio.h>
#include "arithmetic.h"
#include "trigo.h"

int main() {
    struct ops arithmetic_ops;
    struct ops trig_ops;

    // Assign function pointers for arithmetic operations
    arithmetic_ops.binary_op = add; // Example: can be changed to other operations
    arithmetic_ops.binary_op = subtract; // Example: can be changed to other operations
    arithmetic_ops.binary_op = multiply; // Example: can be changed to other operations
    arithmetic_ops.binary_op = divide; // Example: can be changed to other operations

    // Assign function pointers for trigonometric operations
    trig_ops.unary_op = sin_op; // Example: can be changed to other operations
    trig_ops.unary_op = cos_op; // Example: can be changed to other operations
    trig_ops.unary_op = tan_op; // Example: can be changed to other operations

    float a = 5.0, b = 3.0;
    printf("Addition: %f\n", arithmetic_ops.binary_op(a, b));
    printf("Subtraction: %f\n", arithmetic_ops.binary_op(a, b));
    printf("Multiplication: %f\n", arithmetic_ops.binary_op(a, b));
    printf("Division: %f\n", arithmetic_ops.binary_op(a, b));
    printf("Sine: %f\n", trig_ops.unary_op(a));
    printf("Cosine: %f\n", trig_ops.unary_op(a));
    printf("Tangent: %f\n", trig_ops.unary_op(a));

    return 0;
}

