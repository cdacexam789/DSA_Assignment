#ifndef TRIGO_H
#define TRIGO_H
/*
struct ops {
    float (*unary_op)(float);
    float (*binary_op)(float, float);
};*/

float sin_op(float x);
float cos_op(float x);
float tan_op(float x);

#endif // TRIGO_H

