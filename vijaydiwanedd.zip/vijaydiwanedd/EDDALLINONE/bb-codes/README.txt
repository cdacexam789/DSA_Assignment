mod1: basic driver
mod2: module params - w/ and w/o callback
mod3: char driver, major:minor, device node, cdev, fops, data Xchange
mod4: multi-file module
mod5: EXPORT_SYMBOL 
mod6: ioctl
mod7: kernel timers, HR timers
mod8: kthreads, completions, kthreads sharing, mutex, spinlock, rwlock, seqlock
mod9: kernel linked list
mod10: sysfs entry creation (dir, file)
mod11: GPIOs, IRQs
mod12: deferred work - tasklets, workqueues
mod13: i2c-client driver
XXXXX -- removed mod14: USB driver ---
mod15: SPI userspace driver

All code tested on BBB running kernel 5.10.168-ti-r72

