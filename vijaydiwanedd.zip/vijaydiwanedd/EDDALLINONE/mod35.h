#ifndef MOD35_H
#define MOD35_H

#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/uaccess.h>

// Shared variables
extern dev_t dev;
extern struct class *dev_class;
extern struct device *cdevice;
extern struct cdev my_cdev;
extern char *kbuf;

// Function declarations
int my_open(struct inode *inode, struct file *file);
int my_release(struct inode *inode, struct file *file);
ssize_t my_read(struct file *file, char __user *buf, size_t len, loff_t *off);
ssize_t my_write(struct file *file, const char __user *buf, size_t len, loff_t *off);


#endif

