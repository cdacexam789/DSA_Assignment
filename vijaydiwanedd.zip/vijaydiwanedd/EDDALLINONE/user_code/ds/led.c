#include <linux/module.h>
#include <linux/gpio.h>
#include <linux/interrupt.h>

#define LED_GPIO 49
#define SWITCH_GPIO 115

static int irq_number;

static irqreturn_t switch_isr(int irq, void *data) {
    int state = gpio_get_value(SWITCH_GPIO);
    gpio_set_value(LED_GPIO, state);
    return IRQ_HANDLED;
}

static int __init gpio_init(void) {
    // LED setup
    gpio_request(LED_GPIO, "led");
    gpio_direction_output(LED_GPIO, 0);
    
    // Switch setup
    gpio_request(SWITCH_GPIO, "switch");
    gpio_direction_input(SWITCH_GPIO);
    
    // Interrupt setup
    irq_number = gpio_to_irq(SWITCH_GPIO);
    request_irq(irq_number, switch_isr, IRQF_TRIGGER_RISING | IRQF_TRIGGER_FALLING, "switch_irq", NULL);
    
    return 0;
}

static void __exit gpio_exit(void) {
    free_irq(irq_number, NULL);
    gpio_set_value(LED_GPIO, 0);
    gpio_free(LED_GPIO);
    gpio_free(SWITCH_GPIO);
}

module_init(gpio_init);
module_exit(gpio_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");

