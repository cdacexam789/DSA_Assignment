#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/moduleparam.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Vikas");
MODULE_DESCRIPTION("LKM with three module parameters including a callback");

static int myinit = 100;
static int myintarray[5] = {0, 0, 0, 0, 0};
static int myintarray_len = 0;
static int myint_Callback = 200;

/* Custom setter function for myint_Callback parameter */
static int myint_set(const char *val, const struct kernel_param *kp)
{
    int ret;
    int new_val;

    ret = kstrtoint(val, 10, &new_val);
    if (ret < 0)
        return ret;

    /* Only take action if value has changed from default (200) */
    if (new_val != 200) {
        printk(KERN_INFO "myint_Callback parameter is changed from default value\n");
        printk(KERN_INFO "New value of myint_Callback: %d\n", new_val);
    }

    /* Set the value */
    *((int *)kp->arg) = new_val;

    return 0;
}

static int myint_get(char *buffer, const struct kernel_param *kp)
{
    return sprintf(buffer, "%d\n", *((int *)kp->arg));
}

/* Define custom param ops with set and get */
static const struct kernel_param_ops myint_ops = {
    .set = myint_set,
    .get = myint_get,
};

module_param(myinit, int, 0644);
MODULE_PARM_DESC(myinit, "An integer parameter with default=100");

module_param_array(myintarray, int, &myintarray_len, 0644);
MODULE_PARM_DESC(myintarray, "An array of integers with default=0");

module_param_cb(myint_Callback, &myint_ops, &myint_Callback, 0644);
MODULE_PARM_DESC(myint_Callback, "An integer parameter with callback support default=200");


static int __init lkm_param_init(void)
{
    printk(KERN_INFO "LKM Module with parameters loaded\n");
    printk(KERN_INFO "myinit = %d\n", myinit);

    printk(KERN_INFO "myintarray =");
    for (int i = 0; i < myintarray_len; i++)
        printk(KERN_CONT " %d", myintarray[i]);
    printk(KERN_CONT "\n");

    printk(KERN_INFO "myint_Callback = %d\n", myint_Callback);

    return 0;
}

static void __exit lkm_param_exit(void)
{
    printk(KERN_INFO "LKM Module with parameters unloaded\n");
}

module_init(lkm_param_init);
module_exit(lkm_param_exit);


