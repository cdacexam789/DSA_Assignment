/* user code*/
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define IOCTL_SEND_INT _IOW('a', 1, unsigned int)

int main() {
    int fd = open("/dev/led_ctl", O_RDWR);
    unsigned int value;
    
    printf("Enter 4-bit value (0-15): ");
    scanf("%u", &value);
    ioctl(fd, IOCTL_SEND_INT, &value);
    
    close(fd);
    return 0;
}

