#include <linux/module.h>
#include <linux/fs.h>
#include <linux/gpio.h>
#include <linux/ioctl.h>
#include <linux/uaccess.h>
#include <linux/device.h>

#define DEVICE_NAME "led_ctl"
#define MAGIC 'a'
#define IOCTL_SEND_INT _IOW(MAGIC, 1, unsigned int)

static int major;
static struct class *led_class;
static struct gpio leds[] = {
    {47, GPIOF_OUT_INIT_LOW, "LED0"},
    {48, GPIOF_OUT_INIT_LOW, "LED1"},
    {49, GPIOF_OUT_INIT_LOW, "LED2"},
    {60, GPIOF_OUT_INIT_LOW, "LED3"}
};

static long dev_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    unsigned int value;
    
    if (cmd == IOCTL_SEND_INT) {
        if (copy_from_user(&value, (unsigned int *)arg, sizeof(value)))
            return -EFAULT;
            
        gpio_set_value(leds[0].gpio, (value >> 3) & 0x1);
        gpio_set_value(leds[1].gpio, (value >> 2) & 0x1);
        gpio_set_value(leds[2].gpio, (value >> 1) & 0x1);
        gpio_set_value(leds[3].gpio, value & 0x1);
    }
    return 0;
}

static struct file_operations fops = {
    .unlocked_ioctl = dev_ioctl,
};

static int __init led_init(void)
{
    int i;
    for (i = 0; i < ARRAY_SIZE(leds); i++) {
        if (gpio_request(leds[i].gpio, leds[i].label)) {
            while (i-- > 0) gpio_free(leds[i].gpio);
            return -EBUSY;
        }
        gpio_direction_output(leds[i].gpio, 0);
    }
    
    major = register_chrdev(0, DEVICE_NAME, &fops);
    led_class = class_create(THIS_MODULE, DEVICE_NAME);
    device_create(led_class, NULL, MKDEV(major, 0), NULL, DEVICE_NAME);
    return 0;
}

static void __exit led_exit(void)
{
    int i;
    device_destroy(led_class, MKDEV(major, 0));
    class_destroy(led_class);
    unregister_chrdev(major, DEVICE_NAME);
    
    for (i = 0; i < ARRAY_SIZE(leds); i++) {
        gpio_set_value(leds[i].gpio, 0);
        gpio_free(leds[i].gpio);
    }
}

module_init(led_init);
module_exit(led_exit);
MODULE_LICENSE("GPL");

