/*
   Write C code that converts a given decimal number into the following number system:
1. binary
2. octal
3. hexadecimal

Implement funcitons with the following API:

char *to_binary(unsigned int);
char *to_octal(unsigned int);
char *to_hexadecimal(unsigned int);

Each function should return a string with the number counterpart thus:

to_binary(10) should return "0b1010"
to_octal(8) should return "0o10"
to_hexadecimal(16) should return "0x10"

Test your code for all numbers from 0 to 100.
*/

#include <stdio.h>
#include <stdlib.h>

char *to_binary(unsigned int num);
char *to_octal(unsigned int num);
char *to_hexadecimal(unsigned int num);

int main(void) {
    for (unsigned int num = 0; num <= 100; num++) {
        char *binary = to_binary(num);
        char *octal = to_octal(num);
        char *hexadecimal = to_hexadecimal(num);

        if (binary && octal && hexadecimal) {
            printf("Decimal: %3u -> Binary: %s, Octal: %s, Hexadecimal: %s\n",
                   num, binary, octal, hexadecimal);
        } else {
            printf("Error converting number %u\n", num);
        }

        free(binary);
        free(octal);
        free(hexadecimal);
    }
    return 0;
}

char *to_binary(unsigned int num) {
    char *str = malloc(35);
    if (!str) return NULL;

    str[0] = '0';
    str[1] = 'b';

    if (num == 0) {
        str[2] = '0';
        str[3] = '\0';
        return str;
    }

    char temp[33];
    int i = 0;
    while (num > 0) {
        temp[i++] = (num & 1) ? '1' : '0';
        num >>= 1;
    }

    for (int j = 0; j < i; j++) {
        str[2 + j] = temp[i - j - 1];
    }
    str[2 + i] = '\0';

    return str;
}

char *to_octal(unsigned int num) {
    char *str = malloc(14);
    if (!str) return NULL;

    str[0] = '0';
    str[1] = 'o';

    if (num == 0) {
        str[2] = '0';
        str[3] = '\0';
        return str;
    }

    char temp[12];
    int i = 0;
    while (num > 0) {
        temp[i++] = '0' + (num % 8);
        num /= 8;
    }

    for (int j = 0; j < i; j++) {
        str[2 + j] = temp[i - j - 1];
    }
    str[2 + i] = '\0';

    return str;
}

char *to_hexadecimal(unsigned int num) {
    char *str = malloc(11);
    if (!str) return NULL;

    str[0] = '0';
    str[1] = 'x';

    if (num == 0) {
        str[2] = '0';
        str[3] = '\0';
        return str;
    }

    char temp[9];
    int i = 0;
    while (num > 0) {
        unsigned int rem = num % 16;
        if (rem < 10)
            temp[i++] = '0' + rem;
        else
            temp[i++] = 'A' + (rem - 10);
        num /= 16;
    }

    for (int j = 0; j < i; j++) {
        str[2 + j] = temp[i - j - 1];
    }
    str[2 + i] = '\0';

    return str;
}

