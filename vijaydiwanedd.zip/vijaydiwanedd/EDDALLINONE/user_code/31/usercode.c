#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include "led_timer_ioctl.h"

int main() {
    int fd = open("/dev/led_timer", O_RDWR);
    if (fd < 0) {
        perror("open");
        exit(1);
    }
    ioctl(fd, START_TIMER_UP);
    sleep(10);
    ioctl(fd, STOP_TIMER);
    close(fd);
    return 0;
}

