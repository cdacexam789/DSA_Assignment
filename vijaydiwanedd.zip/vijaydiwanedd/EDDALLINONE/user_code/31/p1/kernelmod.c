#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/ioctl.h>
#include <linux/gpio.h>
#include <linux/delay.h>
#include <linux/printk.h>

#define DEVICE_NAME "prime_led"
#define IOCTL_SET_NUM _IOW('a', 1, unsigned int)

static int gpios[] = { 44, 26, 46, 65 }; // Example GPIOs, adjust as needed
static int is_gpio_exported = 0;
static int is_device_open = 0;

static int is_prime(unsigned int n) {
    int i;
    if (n <= 1) return 0;
    for (i = 2; i*i <= n; i++)
        if (n % i == 0) return 0;
    return 1;
}

static void set_leds(int state) {
    int i;
    for (i = 0; i < 4; i++) {
        gpio_set_value(gpios[i], state);
    }
}

static long device_ioctl(struct file *file, unsigned int cmd, unsigned long arg) {
    unsigned int num;
    if (copy_from_user(&num, (unsigned int *)arg, sizeof(num)))
        return -EFAULT;

    pr_info("Received: %u\n", num);
    if (is_prime(num)) {
        set_leds(1); // All LEDs ON
        pr_info("%u is prime\n", num);
    } else {
        set_leds(0); // All LEDs OFF
        pr_info("%u is not prime\n", num);
    }
    return 0;
}

static struct file_operations fops = {
    .unlocked_ioctl = device_ioctl,
};

static int __init prime_led_init(void) {
    int i, ret;
    for (i = 0; i < 4; i++) {
        if (!gpio_is_valid(gpios[i])) {
            pr_err("GPIO %d is invalid\n", gpios[i]);
            return -ENODEV;
        }
        ret = gpio_request(gpios[i], "LED");
        if (ret) {
            pr_err("GPIO %d request failed\n", gpios[i]);
            while (--i >= 0) gpio_free(gpios[i]);
            return ret;
        }
        ret = gpio_direction_output(gpios[i], 0);
        if (ret) {
            pr_err("GPIO %d direction failed\n", gpios[i]);
            gpio_free(gpios[i]);
            while (--i >= 0) gpio_free(gpios[i]);
            return ret;
        }
    }
    is_gpio_exported = 1;
    register_chrdev(0, DEVICE_NAME, &fops);
    pr_info("Prime LED module loaded\n");
    return 0;
}

static void __exit prime_led_exit(void) {
    int i;
    if (is_gpio_exported) {
        for (i = 0; i < 4; i++)
            gpio_free(gpios[i]);
    }
    unregister_chrdev(0, DEVICE_NAME);
    pr_info("Prime LED module unloaded\n");
}

module_init(prime_led_init);
module_exit(prime_led_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("Prime number LED controller");

