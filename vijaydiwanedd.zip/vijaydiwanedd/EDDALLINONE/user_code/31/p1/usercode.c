#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/ioctl.h>

#define DEVICE_PATH "/dev/prime_led"
#define IOCTL_SET_NUM _IOW('a', 1, unsigned int)

int main() {
    int fd;
    unsigned int num;
    srand(time(NULL));

    fd = open(DEVICE_PATH, O_RDWR);
    if (fd < 0) {
        perror("Failed to open device");
        return 1;
    }

    while (1) {
        num = rand() % 1000; // Limit to 1000 for testing
        printf("Sending: %u\n", num);
        if (ioctl(fd, IOCTL_SET_NUM, &num) < 0) {
            perror("IOCTL failed");
            break;
        }
        sleep(1);
    }

    close(fd);
    return 0;
}

