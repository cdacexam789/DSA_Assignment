#ifndef LED_TIMER_IOCTL_H
#define LED_TIMER_IOCTL_H

#include <linux/ioctl.h>

#define LED_TIMER_MAGIC 'k'

#define START_TIMER_UP     _IO(LED_TIMER_MAGIC, 0)
#define START_TIMER_DOWN   _IO(LED_TIMER_MAGIC, 1)
#define STOP_TIMER         _IO(LED_TIMER_MAGIC, 2)

#endif

