/*
   Implement an LKM that creates a char device with 3 IOCTLs:
1. START_TIMER_UP
2. START_TIMER_DOWN
3. STOP_TIMER

For this, connect a 4-LED ladder circuit to the board with the following connections:

MSB:    GPIO47 - HW pin P8_15
MSB-1:  GPIO48 - and so on.
MSB-2:  GPIO49
LSB:    GPIO60

START_TIMER_UP should start a kernel timer and display the count on the LEDs:
0000 -> 0001 -> 0010 -> .... -> 1111 -> 0000 -> ... and so on

START_TIMER_DOWN should start a kernel timer and display the count on the LEDs
in reverse:

1111 -> 1110 -> 1100 -> .... -> 0000 -> 1111 -> ... and so on.

Keep the kernel timer period to 1 second.
Verify your LKM for kernel stability.
 */

#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/timer.h>
#include <linux/gpio.h>
#include <linux/device.h>
#include <linux/cdev.h>
#include "led_timer_ioctl.h"

#define DEVICE_NAME "led_timer"
#define NUM_LEDS 4

static int gpios[NUM_LEDS] = { 47, 48, 49, 60 }; // Adjust for your board!
static int current_count = 0;
static bool direction = true; // true: up, false: down
static struct timer_list my_timer;
static dev_t dev;
static struct cdev cdev;
static struct class *led_class;

static void update_leds(uint8_t value) {
    int i;
    for (i = 0; i < NUM_LEDS; i++) {
        gpio_set_value(gpios[i], (value >> (NUM_LEDS - 1 - i)) & 0x1);
    }
}
/*
static void update_leds(uint8_t value) {
    gpio_set_value(gpios[0], (value >> 3) & 0x1);
    gpio_set_value(gpios[1], (value >> 2) & 0x1);
    gpio_set_value(gpios[2], (value >> 1) & 0x1);
    gpio_set_value(gpios[3], value & 0x1);
}
*/

static void timer_callback(struct timer_list *t) {
    if (direction)
        current_count = (current_count + 1) & 0xF;
    else
        current_count = (current_count - 1) & 0xF;
    update_leds(current_count);
    mod_timer(&my_timer, jiffies + msecs_to_jiffies(1000));
}

static void start_timer(void) {
    del_timer(&my_timer);
    timer_setup(&my_timer, timer_callback, 0);
    mod_timer(&my_timer, jiffies + msecs_to_jiffies(1000));
}

static void stop_timer(void) {
    del_timer_sync(&my_timer);
}

static long led_timer_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    switch (cmd) {
        case START_TIMER_UP:
            direction = true;
            start_timer();
            break;
        case START_TIMER_DOWN:
            direction = false;
            start_timer();
            break;
        case STOP_TIMER:
            stop_timer();
            break;
        default:
            return -ENOTTY;
    }
    return 0;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = led_timer_ioctl,
};

static int __init led_timer_init(void) {
    int i, ret;
    printk(KERN_INFO "led_timer: module loading\n");

    // Allocate device number
    if (alloc_chrdev_region(&dev, 0, 1, DEVICE_NAME) < 0) {
        printk(KERN_ERR "led_timer: can't allocate chrdev\n");
        return -1;
    }

    // Initialize cdev
    cdev_init(&cdev, &fops);
    if (cdev_add(&cdev, dev, 1) < 0) {
        printk(KERN_ERR "led_timer: can't add cdev\n");
        unregister_chrdev_region(dev, 1);
        return -1;
    }

    // Create device class
    led_class = class_create(THIS_MODULE, DEVICE_NAME);
    if (IS_ERR(led_class)) {
        printk(KERN_ERR "led_timer: failed to create class\n");
        cdev_del(&cdev);
        unregister_chrdev_region(dev, 1);
        return PTR_ERR(led_class);
    }

    // Create device node
    if (device_create(led_class, NULL, dev, NULL, DEVICE_NAME) == NULL) {
        printk(KERN_ERR "led_timer: failed to create device\n");
        class_destroy(led_class);
        cdev_del(&cdev);
        unregister_chrdev_region(dev, 1);
        return -1;
    }

    // Request and configure GPIOs
    for (i = 0; i < NUM_LEDS; i++) {
        if (!gpio_is_valid(gpios[i])) {
            printk(KERN_ERR "led_timer: invalid GPIO %d\n", gpios[i]);
            goto err_gpio;
        }
        ret = gpio_request(gpios[i], "led_timer");
        if (ret < 0) {
            printk(KERN_ERR "led_timer: can't request GPIO %d\n", gpios[i]);
            goto err_gpio;
        }
        ret = gpio_direction_output(gpios[i], 0);
        if (ret < 0) {
            printk(KERN_ERR "led_timer: can't set GPIO %d to output\n", gpios[i]);
            gpio_free(gpios[i]);
            goto err_gpio;
        }
    }

    printk(KERN_INFO "led_timer: module loaded\n");
    return 0;

err_gpio:
    while (--i >= 0)
        gpio_free(gpios[i]);
    device_destroy(led_class, dev);
    class_destroy(led_class);
    cdev_del(&cdev);
    unregister_chrdev_region(dev, 1);
    return -1;
}

static void __exit led_timer_exit(void) {
    int i;

    stop_timer();
    for (i = 0; i < NUM_LEDS; i++)
        gpio_free(gpios[i]);
    device_destroy(led_class, dev);
    class_destroy(led_class);
    cdev_del(&cdev);
    unregister_chrdev_region(dev, 1);
    printk(KERN_INFO "led_timer: module unloaded\n");
}

module_init(led_timer_init);
module_exit(led_timer_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("desd");
MODULE_DESCRIPTION("LED Timer with IOCTL Control");

