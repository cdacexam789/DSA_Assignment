/*
Number System Conversions

Write C codes that converts a given decimal number into its binary counterpart.
It should accept an unsigned int and return a string containing its binary counterpart.

Example:

input: 10
output: "1010"

Test your code for all numbers from 0 to 100.
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(void){
/*
	for(int i=0;i<100;i++){
		int temp=i;
		char binary[32];
		for (int j=31; j >= 0; j--) {
       			 binary[j] = (i & 1) ? '1' : '0';
      			 i >>= 1;
		}
		int index=0;
		while(temp>0){
			binary[index++] = (temp % 2 ==0) ? '0' : '1';
			temp /= 2;
		}
		binary[index] = '\0';

		int length = 32;
    		int z, j;
    		char tempc;
    		for (z = 0, j = length - 1; z < j; z++, j--) {
        	tempc = binary[z];
        	binary[z] = binary[j];
        	binary[j] = tempc;
    		}
		printf("%d = %s\n",i,binary);

	}
	return 0;*/

	 for (int num = 0; num < 100; num++) {  // Use separate variable 'num'
        int temp = num;                     // Preserve original value
        char binary[33];                    // 32 bits + null terminator
        int index = 0;

        // Handle special case for 0
        if (temp == 0) {
            binary[index++] = '0';
        }
        // Build binary string in reverse
        else {
            while (temp > 0) {
                binary[index++] = (temp % 2) ? '1' : '0';
                temp /= 2;
            }
        }
        binary[index] = '\0';  // Proper null termination

        // Reverse the string to get correct order
        for (int i = 0, j = index-1; i < j; i++, j--) {
            char tmp = binary[i];
            binary[i] = binary[j];
            binary[j] = tmp;
        }

        printf("%d = %s\n", num, binary);
    }
    return 0;
}
