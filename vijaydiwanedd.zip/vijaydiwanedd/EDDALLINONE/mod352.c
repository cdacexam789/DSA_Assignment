#include "mod35.h"

int my_open(struct inode *inode, struct file *file) {
    pr_info("Open operation\n");
    return 0;
}

int my_release(struct inode *inode, struct file *file) {
    pr_info("Release operation\n");
    return 0;
}

