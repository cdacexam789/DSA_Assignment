#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/device.h>
#include <linux/mutex.h>

#define DEVICE_NAME "simple_dev"
#define BUFFER_SIZE 100

static int major_num;
static char kernel_buffer[BUFFER_SIZE];
static DEFINE_MUTEX(buffer_lock);
static struct class *dev_class;
static struct device *dev;

static ssize_t dev_read(struct file *file, char __user *user_buf, 
                        size_t count, loff_t *pos)
{
    int bytes_to_copy;
    mutex_lock(&buffer_lock);
    bytes_to_copy = min(count, BUFFER_SIZE - (size_t)*pos);
    
    if (copy_to_user(user_buf, kernel_buffer + *pos, bytes_to_copy)) {
        mutex_unlock(&buffer_lock);
        return -EFAULT;
    }
    
    *pos += bytes_to_copy;
    mutex_unlock(&buffer_lock);
    return bytes_to_copy;
}

static ssize_t dev_write(struct file *file, const char __user *user_buf,
                         size_t count, loff_t *pos)
{
    int bytes_to_copy;
    mutex_lock(&buffer_lock);
    bytes_to_copy = min(count, BUFFER_SIZE - (size_t)*pos);

    if (copy_from_user(kernel_buffer + *pos, user_buf, bytes_to_copy)) {
        mutex_unlock(&buffer_lock);
        return -EFAULT;
    }

    printk(KERN_INFO "simple_dev: Received %d bytes: %.*s\n", 
           bytes_to_copy, bytes_to_copy, kernel_buffer);
    
    *pos += bytes_to_copy;
    mutex_unlock(&buffer_lock);
    return bytes_to_copy;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .read = dev_read,
    .write = dev_write,
};

static int __init dev_init(void)
{
    major_num = register_chrdev(0, DEVICE_NAME, &fops);
    if (major_num < 0) {
        printk(KERN_ALERT "Failed to register device: %d\n", major_num);
        return major_num;
    }
    
    dev_class = class_create(THIS_MODULE, DEVICE_NAME);
    dev = device_create(dev_class, NULL, MKDEV(major_num, 0), NULL, DEVICE_NAME);
    
    printk(KERN_INFO "simple_dev: Module loaded with major %d\n", major_num);
    return 0;
}

static void __exit dev_exit(void)
{
    device_destroy(dev_class, MKDEV(major_num, 0));
    class_destroy(dev_class);
    unregister_chrdev(major_num, DEVICE_NAME);
    printk(KERN_INFO "simple_dev: Module unloaded\n");
}

module_init(dev_init);
module_exit(dev_exit);
MODULE_LICENSE("GPL");

