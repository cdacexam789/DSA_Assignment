#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    int dev_fd, file_fd;
    char buffer[100];
    ssize_t bytes_read;

    if ((file_fd = open("/etc/passwd", O_RDONLY)) < 0) {
        perror("Failed to open /etc/passwd");
        exit(EXIT_FAILURE);
    }

    bytes_read = read(file_fd, buffer, sizeof(buffer));
    close(file_fd);

    if (bytes_read <= 0) {
        perror("Error reading file");
        exit(EXIT_FAILURE);
    }

    if ((dev_fd = open("/dev/simple_dev", O_WRONLY)) < 0) {
        perror("Failed to open device");
        exit(EXIT_FAILURE);
    }

    if (write(dev_fd, buffer, bytes_read) != bytes_read) {
        perror("Error writing to device");
        close(dev_fd);
        exit(EXIT_FAILURE);
    }

    close(dev_fd);
    return 0;
}

