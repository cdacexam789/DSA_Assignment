#include "mod35.h"

ssize_t my_read(struct file *file, char __user *buf, size_t len, loff_t *off) {
    if (copy_to_user(buf, kbuf + *off, len)) 
        return -EFAULT;
    
    *off += len;
    return len;
}

ssize_t my_write(struct file *file, const char __user *buf, size_t len, loff_t *off) {
    if (copy_from_user(kbuf, buf, len)) 
        return -EFAULT;
    
    return len;
}

