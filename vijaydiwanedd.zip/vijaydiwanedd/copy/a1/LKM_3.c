/* Create an LKM device with support for write and read from user space.
   Create a user space application to send 100 bytes of data from the file "/etc/passwd"
   into this device. Print the contents of this data in dmesg when you receive it in kernel space.
*/

#include <linux/module.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include <linux/slab.h>

#define DEVICE_NAME "cdac_dev"
#define CLASS_NAME  "cdac_class"
#define BUF_SIZE    100

static dev_t dev_num;
static struct cdev cdac_cdev;
static struct class *cdac_class;
static char kbuf[BUF_SIZE];
static size_t kbuf_len = 0;

static int cdac_open(struct inode *inode, struct file *file) {
    return 0;
}

static int cdac_release(struct inode *inode, struct file *file) {
    return 0;
}

static ssize_t cdac_read(struct file *file, char __user *buf, size_t len, loff_t *off) {
    size_t to_copy;

    if (*off >= kbuf_len)
        return 0;

    to_copy = min(len, kbuf_len - (size_t)*off);

    if (copy_to_user(buf, kbuf + *off, to_copy))
        return -EFAULT;

    *off += to_copy;
    return to_copy;
}

static ssize_t cdac_write(struct file *file, const char __user *buf, size_t len, loff_t *off) {
    size_t to_copy = min(len, (size_t)BUF_SIZE);

    if (copy_from_user(kbuf, buf, to_copy))
        return -EFAULT;

    // Safe null-termination
    if (to_copy < BUF_SIZE)
        kbuf[to_copy] = '\0';
    else
        kbuf[BUF_SIZE - 1] = '\0';

    kbuf_len = to_copy;
    pr_info("cdac_dev: Received data from user:\n%.*s\n", (int)to_copy, kbuf);

    return to_copy;
}

static struct file_operations cdac_fops = {
    .owner   = THIS_MODULE,
    .open    = cdac_open,
    .release = cdac_release,
    .read    = cdac_read,
    .write   = cdac_write,
};

static int __init cdac_init(void) {
    int ret;

    ret = alloc_chrdev_region(&dev_num, 0, 1, DEVICE_NAME);
    if (ret) {
        pr_err("cdac_dev: Failed to allocate chrdev region\n");
        return ret;
    }

    cdev_init(&cdac_cdev, &cdac_fops);

    ret = cdev_add(&cdac_cdev, dev_num, 1);
    if (ret) {
        unregister_chrdev_region(dev_num, 1);
        pr_err("cdac_dev: Failed to add cdev\n");
        return ret;
    }

    cdac_class = class_create(THIS_MODULE, CLASS_NAME);
    if (IS_ERR(cdac_class)) {
        cdev_del(&cdac_cdev);
        unregister_chrdev_region(dev_num, 1);
        pr_err("cdac_dev: Failed to create class\n");
        return PTR_ERR(cdac_class);
    }

    device_create(cdac_class, NULL, dev_num, NULL, DEVICE_NAME);

    pr_info("cdac_dev: Module loaded\n");
    return 0;
}

static void __exit cdac_exit(void) {
    device_destroy(cdac_class, dev_num);
    class_destroy(cdac_class);
    cdev_del(&cdac_cdev);
    unregister_chrdev_region(dev_num, 1);
    pr_info("cdac_dev: Module unloaded\n");
}

module_init(cdac_init);
module_exit(cdac_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("LKM that reads 100 bytes from user and prints in dmesg");
