/* Main module initialization and cleanup */
#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/err.h>
#include <linux/device.h>
#include <linux/kdev_t.h>
#include <linux/cdev.h>
#include <linux/slab.h>

#define MY_CLASS_NAME "cdac_clss"
#define MY_DEV_NAME "cdac_dev"
#define MY_KBUF_SZ (1024)

/* External declarations from fops.c */
extern dev_t dev;
extern struct class *dev_class;
extern struct device *cdevice;
extern struct cdev my_cdev;
extern char *kbuf;
extern struct file_operations fops;

static int __init my_mod_init(void)
{
    int ans;

    // Allocate kernel buffer
    kbuf = kmalloc(MY_KBUF_SZ, GFP_KERNEL);
    if (!kbuf) {
        pr_err("Cannot allocate kernel memory!\n");
        return -ENOMEM;
    }

    pr_info("Module initialization started\n");
    
    // Allocate device numbers
    ans = alloc_chrdev_region(&dev, 0, 1, MY_DEV_NAME);
    if (ans < 0) {
        pr_err("Device number allocation failed\n");
        goto r_kbuf;
    }
    pr_info("Major:Minor = %d:%d\n", MAJOR(dev), MINOR(dev));

    // Initialize and add character device
    cdev_init(&my_cdev, &fops);
    ans = cdev_add(&my_cdev, dev, 1);
    if (ans < 0) {
        pr_err("Character device addition failed\n");
        goto r_cdev;
    }

    // Create device class
    dev_class = class_create(THIS_MODULE, MY_CLASS_NAME);
    if (IS_ERR(dev_class)) {
        pr_err("Class creation failed\n");
        ans = PTR_ERR(dev_class);
        goto r_class;
    }

    // Create device node
    cdevice = device_create(dev_class, NULL, dev, NULL, MY_DEV_NAME);
    if (IS_ERR(cdevice)) {
        pr_err("Device creation failed\n");
        ans = PTR_ERR(cdevice);
        goto r_device;
    }

    pr_info("Device %s created successfully\n", MY_DEV_NAME);
    return 0;

/* Error handling */
r_device:
    class_destroy(dev_class);
r_class:
    cdev_del(&my_cdev);
r_cdev:
    unregister_chrdev_region(dev, 1);
r_kbuf:
    kfree(kbuf);
    return ans;
}

static void __exit my_mod_exit(void)
{
    device_destroy(dev_class, dev);  // Fixed typo: dev_cl5)ass -> dev_class
    class_destroy(dev_class);
    cdev_del(&my_cdev);
    unregister_chrdev_region(dev, 1);
    kfree(kbuf);
    pr_info("Module unloaded\n");
}

module_init(my_mod_init);
module_exit(my_mod_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("Module using exported symbols!");
