/* Character device file operations */
#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/cdev.h>  // <-- FIXED: Required for struct cdev

#define MY_KBUF_SZ (1024)

/* Shared variables with main.c */
dev_t dev;
struct class *dev_class;
struct device *cdevice;
struct cdev my_cdev;
char *kbuf;

/* File open */
static int my_open(struct inode *inode, struct file *file)
{
    pr_info("Device opened\n");
    return 0;
}

/* File read */
static ssize_t my_read(struct file *file, char __user *buf, size_t len, loff_t *off)
{
    size_t remaining = MY_KBUF_SZ - *off;
    size_t to_read = min(len, remaining);

    if (to_read == 0) {
        pr_info("Read position at end of buffer\n");
        return 0;
    }

    if (copy_to_user(buf, kbuf + *off, to_read)) {
        pr_err("Failed to copy to user\n");
        return -EFAULT;
    }

    *off += to_read;
    pr_info("Read %zu bytes\n", to_read);
    return to_read;
}

/* File write */
static ssize_t my_write(struct file *file, const char __user *buf, size_t len, loff_t *off)
{
    size_t remaining = MY_KBUF_SZ - *off;
    size_t to_write = min(len, remaining);

    if (to_write == 0) {
        pr_info("Write buffer full\n");
        return -ENOSPC;
    }

    if (copy_from_user(kbuf + *off, buf, to_write)) {
        pr_err("Failed to copy from user\n");
        return -EFAULT;
    }

    *off += to_write;
    pr_info("Wrote %zu bytes\n", to_write);
    return to_write;
}

/* File close */
static int my_release(struct inode *inode, struct file *file)
{
    pr_info("Device closed\n");
    return 0;
}

/* File operations structure */
struct file_operations fops = {
    .owner = THIS_MODULE,
    .open = my_open,
    .read = my_read,
    .write = my_write,
    .release = my_release,
};
