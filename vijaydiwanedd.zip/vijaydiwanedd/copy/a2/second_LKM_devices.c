/* Fixed device node creation module */

#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/err.h>
#include <linux/device.h>
#include <linux/kdev_t.h>

#define MY_CLASS_NAME "my_class"     // Name of the device class
#define MY_DEV_NAME   "my_device"    // Base name of each device node
#define NUM_DEVS      (5)            // Number of devices to create

static dev_t dev = 0;                       // Variable to hold the major and minor number
static struct class *dev_class;            // Pointer to the device class
static struct device *cdevice[NUM_DEVS];   // Array to store each created device

// Initialization function called when module is inserted
static int __init my_mod_init(void)
{
    int ret, i;
    int major;
    char dev_name[16]; // Buffer to hold generated device names like my_deviceA

    pr_info("Hello world from mod33!\n");

    // Allocate major and minor number range for NUM_DEVS devices
    ret = alloc_chrdev_region(&dev, 0, NUM_DEVS, MY_DEV_NAME);
    if (ret < 0) {
        pr_err("Error in major:minor allotment!\n");
        return ret;
    }

    pr_info("major:minor range of %d devices %d:%d allotted!\n", 
           NUM_DEVS, MAJOR(dev), MINOR(dev));

    // Create device class for grouping all the devices
    dev_class = class_create(THIS_MODULE, MY_CLASS_NAME);
    if (IS_ERR(dev_class)) {
        pr_err("Could not create device class %s\n", MY_CLASS_NAME);
        ret = PTR_ERR(dev_class);
        goto r_class;
    }

    major = MAJOR(dev);
    for (i = 0; i < NUM_DEVS; i++) {
        // Generate device name like my_deviceA, my_deviceB, ...
        snprintf(dev_name, sizeof(dev_name), "%s%c", MY_DEV_NAME, 'A' + i);
        
        // Create the actual device node under /dev
        cdevice[i] = device_create(dev_class, NULL, MKDEV(major, i), NULL, dev_name);
        if (IS_ERR(cdevice[i])) {
            pr_err("Could not create device %s\n", dev_name);
            ret = PTR_ERR(cdevice[i]);
            goto r_devices;
        }
    }

    pr_info("%d devices %s under class %s created successfully\n", 
           NUM_DEVS, MY_DEV_NAME, MY_CLASS_NAME);
    return 0;

// Error handling block: destroy any devices created so far
r_devices:
    while (--i >= 0) {
        device_destroy(dev_class, MKDEV(major, i));
    }
    class_destroy(dev_class);

// Error handling block: unregister the allocated major:minor range
r_class:
    unregister_chrdev_region(dev, NUM_DEVS);
    return ret;
}

// Exit function called when module is removed
static void __exit my_mod_exit(void)
{
    int i, major = MAJOR(dev);

    pr_info("Goodbye world from mod33!\n");

    // Destroy all created devices
    for (i = 0; i < NUM_DEVS; i++) {
        device_destroy(dev_class, MKDEV(major, i));
    }

    // Remove device class and unregister major:minor number
    class_destroy(dev_class);
    unregister_chrdev_region(dev, NUM_DEVS);
    pr_info("major:minor numbers freed up...\n");
}

module_init(my_mod_init);  // Macro to register init function
module_exit(my_mod_exit);  // Macro to register exit function

MODULE_LICENSE("GPL");  // Open source license
MODULE_AUTHOR("EDD <edd@cdac.gov.in>");
MODULE_DESCRIPTION("Fixed device node creation module");
